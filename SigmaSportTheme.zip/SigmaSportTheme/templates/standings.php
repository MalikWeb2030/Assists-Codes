<?php /* Template Name: standings */ ?>
<?php get_header(); ?>
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'home_ads_below_header_enable' => true,
'home_ads_below_header_code' => 'مساحة إعلانية',
'home_ads_footer_enable' => true,
'home_ads_footer_code' => 'مساحة إعلانية',
];
?>

<div class="container Flex">
<?php if ($settings['home_ads_below_header_enable'] && !empty($settings['home_ads_below_header_code'])) { ?>
<!-- Start Below Header Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_below_header_code']; ?>
</div>
<?php
}
?>
    
<main class="Content-Body">
<!-- Start Standings Section -->
<?php get_template_part('template-parts/standings-page'); ?>
</main>

<article class="BlogBox">
<?php get_template_part('template-parts/page-title');?>
<div class="PostBody" id="ContentBox">
<?php get_template_part('template-parts/page-content');?>
<footer class="PostFooter">
<?php get_template_part('template-parts/posts-share');?>
</footer>
</div>
</article>    
    
<?php if ($settings['home_ads_footer_enable'] && !empty($settings['home_ads_footer_code'])) { ?>
<!-- Start Footer Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_footer_code']; ?>
</div>
<?php
}
?>
</div>
<?php get_footer(); ?>