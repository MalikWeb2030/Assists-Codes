<?php /* Template Name: league */ ?>
<?php get_header(); ?>
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'section_5' => 'ترتيب الدوريات',
'leagues_list_toggle' => true,
'home_ads_below_header_enable' => true,
'home_ads_below_header_code' => 'مساحة إعلانية',
'home_ads_footer_enable' => true,
'home_ads_footer_code' => 'مساحة إعلانية',
];
?>

<div class="container">
<?php if ($settings['home_ads_below_header_enable'] && !empty($settings['home_ads_below_header_code'])) { ?>
<!-- Start Below Header Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_below_header_code']; ?>
</div>
<?php
}
?>
<main class="Site-Body">
<div class="Right-side">
<!-- Start Standings Section -->
<?php get_template_part('template-parts/league-page'); ?>
</div>
    
<div class="Left-side">
<div class="LeagueBox">
<?php if ($settings['leagues_list_toggle']) : ?>
<!-- Start Leagues List Section -->
<section class="MW-Box Leagues-List">
<header class="TitleBox">
<h2 class="Title"><?php echo esc_attr($settings['section_5']); ?></h2>
</header>
<?php get_template_part('template-parts/leagues-list'); ?>
</section>
<?php endif; ?>
</div>
</div>
</main>

<?php if ($settings['home_ads_footer_enable'] && !empty($settings['home_ads_footer_code'])) { ?>
<!-- Start Footer Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_footer_code']; ?>
</div>
<?php
}
?>
</div>
<?php get_footer(); ?>