<!-- Main Content Setup -->
<?php get_header(); ?>
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'section_1' => 'جدول مباريات اليوم',
'section_5' => 'ترتيب الدوريات',
'section_6' => 'نبذة عن موقعك',
'leagues_list_toggle' => true,
'home_ads_below_header_enable' => true,
'home_ads_below_header_code' => 'مساحة إعلانية',
'home_ads_matches_enable' => true,
'home_ads_matches_code' => 'مساحة إعلانية',
'home_ads_posts_enable' => true,
'home_ads_posts_code' => 'مساحة إعلانية',
'home_ads_news_posts_enable' => false,
'home_ads_news_posts_code' => 'مساحة إعلانية',
'home_ads_footer_enable' => true,
'home_ads_footer_code' => 'مساحة إعلانية',
];
$settings = wp_parse_args($options, $defaults);
// Get theme options
$options = get_option('mw_theme_options');
$timezone = isset($options['matches_timezone']) ? $options['matches_timezone'] : 'Africa/Cairo';
$delay_minutes = absint($options['change_days'] ?? 0);
// Define timezone to city name mapping
$timezone_labels = [
'Africa/Cairo' => 'القاهرة',
'Asia/Riyadh' => 'الرياض',
'Africa/Casablanca' => 'الدار البيضاء',
'Asia/Baghdad' => 'بغداد',
'Asia/Qatar' => 'الدوحة',
'Asia/Kuwait' => 'الكويت',
'Africa/Tripoli' => 'طرابلس',
'Asia/Beirut' => 'بيروت',
'Asia/Amman' => 'عمان',
'Asia/Dubai' => 'دبي',
'Asia/Muscat' => 'مسقط',
'Europe/Istanbul' => 'إسطنبول',
'UTC' => 'غرينتش',
'Europe/London' => 'لندن',
'Europe/Paris' => 'باريس',
'Europe/Berlin' => 'برلين',
'Europe/Madrid' => 'مدريد',
'Europe/Rome' => 'روما',
'Europe/Amsterdam' => 'أمستردام',
'Europe/Moscow' => 'موسكو',
];
// Get the display label for the timezone
$timezone_display = isset($timezone_labels[$timezone]) ? esc_html($timezone_labels[$timezone]) : 'غير معروف';
// تحديد المنطقة الزمنية وتطبيق التأخير المحدد لعبور المنتصف الليل
$timezone_obj = new DateTimeZone($timezone);
$current_time = new DateTime('now', $timezone_obj);
$current_hour = (int) $current_time->format('H'); // الساعة الحالية
$current_minute = (int) $current_time->format('i'); // الدقيقة الحالية
$current_minutes_since_midnight = $current_hour * 60 + $current_minute; // إجمالي الدقائق من منتصف الليل
// إذا كان الوقت أقل من التأخير (في الصباح المبكر بعد المنتصف الليل)، اعتبر اليوم السابق
$current_date = $current_time->format('Ymd');
if ($current_minutes_since_midnight < $delay_minutes) {
$current_time->modify('-1 day');
$current_date = $current_time->format('Ymd');
}
// Query for today's matches (مع التاريخ المعدل)
$today_args = [
'post_type' => 'matches',
'posts_per_page' => 100,
'meta_query' => [
'relation' => 'AND',
[
'key' => 'match_date',
'value' => $current_date,
'compare' => '=',
'type' => 'CHAR',
],
],
'orderby' => 'meta_value',
'meta_key' => 'match_time',
'order' => 'ASC',
];
$today_query = new WP_Query($today_args);
?>
<div class="container">
<?php if ($settings['home_ads_below_header_enable'] && !empty($settings['home_ads_below_header_code'])) { ?>
<!-- Start Below Header Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_below_header_code']; ?>
</div>
<?php } ?>
<main class="Site-Body">
<div class="Right-side">
<!-- Start Today Matches Section -->
<div class="TimeZoneName"><span>بتوقيت <?php echo esc_html($timezone_display); ?></span></div>
<section class="M-Table MW-Box">
<header class="TitleBox">
<h2 class="Title M"><?php echo esc_attr($settings['section_1']); ?></h2>
<ul class="nav-tabs">
<li class="Yes"><a href="<?php bloginfo("url") ?>/yesterday-matches/">مباريات الأمس</a></li>
<li class="Tod"><a href="<?php bloginfo("url") ?>/today-matches/">مباريات اليوم</a></li>
<li class="Tom"><a href="<?php bloginfo("url") ?>/tomorrow-matches/">مباريات الغد</a></li>
</ul>
</header>
<?php
$schedule_mode = get_option('mw_schedule_mode', 'manual');
if ($schedule_mode === 'auto') {
?>
<div class="MatchesFlex">
<?php if ($today_query->have_posts()) : ?>
<?php while ($today_query->have_posts()) : $today_query->the_post(); ?>
<?php get_template_part('template-parts/post-match-card'); ?>
<?php endwhile; ?>
<?php wp_reset_postdata(); ?>
<?php else : ?>
<div class="Matches-available"><span class="Not-available">لا يتوفر مباريات في الوقت الحالي!</span></div>
<?php endif; ?>
</div>
<?php
} else {
?>
<div class="MatchesFlex">
<?php
$manual_content = do_shortcode('[manual_today_matches delay="' . $delay_minutes . '"]');
echo $manual_content;
?>
</div>
<?php
}
?>
</section>
<?php get_template_part('custom-posts/news-posts1'); ?>
</div>
<div class="Left-side">
<div class="LeagueBox">
<?php if ($settings['leagues_list_toggle']) : ?>
<!-- Start Leagues List Section -->
<section class="Leagues-List MW-Box">
<header class="TitleBox">
<h2 class="Title"><?php echo esc_attr($settings['section_5']); ?></h2>
</header>
<?php get_template_part('template-parts/leagues-list'); ?>
</section>
<?php endif; ?>
</div>
</div>
</main>
<?php if ($settings['home_ads_matches_enable'] && !empty($settings['home_ads_matches_code'])) { ?>
<!-- Start Matches Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_matches_code']; ?>
</div>
<?php } ?>
<!-- Start Latest Posts Section -->
<?php get_template_part('template-parts/latest-posts'); ?>
<?php if ($settings['home_ads_posts_enable'] && !empty($settings['home_ads_posts_code'])) { ?>
<!-- Start Latest Posts Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_posts_code']; ?>
</div>
<?php } ?>
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'site_botdes' => esc_html__('ضع هنا وصف مختصر للفوتر', 'malik_web'),
'site_botdes_toggle' => true,
];
$settings = wp_parse_args($options, $defaults);
if (!empty($settings['site_botdes']) && $settings['site_botdes_toggle']) : ?>
<!-- Start Bottom Description Section -->
<section class="Site-Des MW-Box">
<header class="TitleBox">
<h2 class="Title"><?php echo esc_html($settings['section_6']); ?></h2>
</header>
<div class="MW-SiteDes">
<p>
<?php echo wp_kses_post($settings['site_botdes']); ?>
</p>
</div>
</section>
<?php endif; ?>
<?php if ($settings['home_ads_footer_enable'] && !empty($settings['home_ads_footer_code'])) { ?>
<!-- Start Footer Ad -->
<div class="MW-AD">
<?php echo $settings['home_ads_footer_code']; ?>
</div>
<?php } ?>
</div>
<?php get_footer(); ?>