<!-- Archive Page Structure -->
<?php get_header(); ?>
<div class="container">
<main class="MW-Box">
<header class="TitleBox">
<h2 class="Title"><?php echo get_the_archive_title(); ?></h2>
</header>
<div class="MW-Posts">
<?php
$posts_per_page = get_option('posts_per_page'); 
$args = array(
'post_type' => array('goals'),
'posts_per_page' => $posts_per_page,
'post_status' => 'publish',
'offset' => 0,
'ignore_sticky_posts' => true,
);
$cat_id = is_category() ? get_queried_object_id() : 0;
$tag_id = is_tag() ? get_queried_object_id() : 0;
if ($cat_id) $args['cat'] = $cat_id;
if ($tag_id) $args['tag_id'] = $tag_id;
$archive_query = new WP_Query($args);
if ($archive_query->have_posts()) :
?>
<div class="MW-Posts-Grid"
data-use-offset="true"
data-current-offset="<?php echo $posts_per_page; ?>"
data-posts-per-page="<?php echo $posts_per_page; ?>"
data-post-types="goals"
data-cat="<?php echo $cat_id; ?>"
data-tag="<?php echo $tag_id; ?>"
data-total-posts="<?php echo $archive_query->found_posts; ?>">
<?php
global $post_index;
$post_index = 1;
while ($archive_query->have_posts()) : $archive_query->the_post();
get_template_part('template-parts/goal-card');
$post_index++;
endwhile;
?>
</div>
<?php
$has_more = $archive_query->found_posts > $posts_per_page;
if ($has_more) :
?>
<div class="load-more-container">
<button class="load-more-btn" aria-label="تحميل المزيد من المقالات">تحميل المزيد</button>
</div>
<?php endif; ?>
<?php else : ?>
<div class="Articles-available">
<span class="Not-available">لا يتوفر مقالات في الوقت الحالي!</span>
</div>
<?php endif;
wp_reset_postdata();
?>
</div>
</main>
</div>
<?php get_footer(); ?>