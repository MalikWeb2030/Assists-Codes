<?php
if (!defined('ABSPATH')) exit;
$leagues = [572, 624, 623, 573, 167, 7674, 7, 11, 17, 35, 25, 552, 649, 557, 560, 549, 6822, 408, 78, 73, 57, 113, 554, 98, 72, 158, 5473, 5479, 564, 104, 7685, 5096, 6316, 167, 6196, 5930, 7016, 588, 5452, 5525, 5421, 645, 605];
$cache_key = 'mw_leagues_data_' . md5(implode(',', $leagues));
// كاش لمدة أسبوع (زي ما طلبت)
$leagues_data = get_transient($cache_key);
if (false === $leagues_data) {
$leagues_data = [];
$api_base = 'https://webws.365scores.com/web/standings/';
$params = [
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'live' => 'false',
'withSeasons' => 'true'
];
foreach ($leagues as $league_id) {
$url = add_query_arg(array_merge($params, ['competitions' => $league_id]), $api_base);
$response = wp_remote_get($url, ['timeout' => 10]); // نفس الطريقة الأصلية بتاعتك
if (is_wp_error($response)) continue;
$body = wp_remote_retrieve_body($response);
$data = json_decode($body, true);
if (empty($data['competitions'][0])) continue;
$comp = $data['competitions'][0];
// الطريقة الصح اللي شغالة 100%
$slug = (!empty($comp['nameForURL'])) 
? sanitize_title($comp['nameForURL']) . '-' . $comp['id']
: 'league-' . $comp['id'];
$leagues_data[] = [
'id'   => (int)$comp['id'],
'name' => sanitize_text_field($comp['name']),
'slug' => $slug
];
}
// كاش لمدة أسبوع كامل
set_transient($cache_key, $leagues_data, WEEK_IN_SECONDS);
}
$no_league = '/assets/uploads/none-league.png';
?>
<?php if (!empty($leagues_data)) : ?>
<section class="Leagues MW-Box">
<header class="TitleBox">
<h2 class="Title">ترتيب الفرق والهدافين</h2>  
</header>
<div class="Leagues-list">
<ul class="Mw-cards">
<?php foreach ($leagues_data as $league) : ?>
<li class="card">
<a href="/league/<?php echo esc_attr($league['slug']); ?>">
<span class="card-image">
<img
alt="<?php echo esc_attr($league['name']); ?>"
title="<?php echo esc_attr($league['name']); ?>"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="/assets/images/league-logo/<?php echo esc_attr($league['id']); ?>"
width="50"
height="50"
loading="lazy"
onerror="this.onerror=null; this.src='<?php echo esc_url($no_league); ?>';">
</span>
<span class="card-name">
<?php echo esc_html($league['name']); ?>
</span>
</a>
</li>
<?php endforeach; ?>
</ul>
</div>
</section>
<?php else : ?>
<div class="MW-Box notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>
<?php endif; ?>