<!-- Post Content Template -->
<div class="article-thumb">
<?php
if (has_post_thumbnail()) {
$thumbnail_id = get_post_thumbnail_id(get_the_ID());
$thumbnail_alt = esc_attr(get_post_meta($thumbnail_id, '_wp_attachment_image_alt', true) ?: get_the_title());
$thumbnail_title = esc_attr(get_the_title());
$thumbnail_srcset = wp_get_attachment_image_srcset($thumbnail_id, 'full');
$thumbnail_sizes = wp_get_attachment_image_sizes($thumbnail_id, 'full');
$thumbnail_metadata = wp_get_attachment_metadata($thumbnail_id);
$thumbnail_width = $thumbnail_metadata['width'] ?? '';
$thumbnail_height = $thumbnail_metadata['height'] ?? '';
echo wp_get_attachment_image($thumbnail_id, 'full', false, [
'class' => 'article-img',
'alt' => $thumbnail_alt,
'title' => $thumbnail_title,
'loading' => 'lazy',
'srcset' => $thumbnail_srcset,
'sizes' => $thumbnail_sizes,
'width' => $thumbnail_width,
'height' => $thumbnail_height,
]);
} else {
$default_image_url = get_template_directory_uri() . '/assets/uploads/default.png';
?>
<img src="<?php echo esc_url($default_image_url); ?>"
class="article-img"
alt="<?php echo esc_attr(get_the_title() ?: 'صورة افتراضية'); ?>"
title="<?php echo esc_attr(get_the_title() ?: 'صورة افتراضية'); ?>"
loading="lazy"
width="100%"
height="auto" />
<?php
}
?>
</div>
<?php
// جلب إعدادات الإعلانات
$options = get_option('mw_theme_options', []);
$defaults = [
'post_ads_toggle' => 1,
'ad_above_post_enable' => 1,
'ad_above_post_code' => 'مساحة إعلانية',
'ad_under_post_enable' => 1,
'ad_under_post_code' => 'مساحة إعلانية',
];
$settings = wp_parse_args($options, $defaults);
// عرض إعلان أول المقال إذا كان post_ads_toggle و ad_above_post_enable مفعلين
if (is_single() && !empty($settings['post_ads_toggle']) && !empty($settings['ad_above_post_enable']) && !empty($settings['ad_above_post_code'])) {
echo '<div class="Post-ads" aria-label="إعلان">' . $settings['ad_above_post_code'] . '</div>';
}
// عرض محتوى المقال
the_content();
// عرض إعلان آخر المقال إذا كان post_ads_toggle و ad_under_post_enable مفعلين
if (is_single() && !empty($settings['post_ads_toggle']) && !empty($settings['ad_under_post_enable']) && !empty($settings['ad_under_post_code'])) {
echo '<div class="Post-ads" aria-label="إعلان">' . $settings['ad_under_post_code'] . '</div>';
}
?>