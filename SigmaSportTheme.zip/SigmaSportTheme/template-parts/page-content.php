<!-- Page Content Template -->
<?php
// عرض محتوى الصفحة
the_content();
?>