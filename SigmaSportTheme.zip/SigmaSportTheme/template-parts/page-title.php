<!-- Page Title Template -->
<div class="postTimestamp">
<header class="PostTitle">
<h1 class="TopicTitle"><?php echo esc_html(get_the_title()); ?></h1>
</header>
</div>