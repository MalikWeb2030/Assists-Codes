<!-- Related Posts Template -->
<section class="PostSearch MW-Box">
<header class="TitleBox">
<h2 class="Title">مقالات ذات صلة</h2>
</header>
<div class="MW-Posts">
<?php
$related_posts = new WP_Query(array(
'post_type' => array('post', 'channels'),
'category__in' => wp_get_post_categories(get_the_ID()),
'posts_per_page' => 8,
'post__not_in' => array(get_the_ID()),
'post_status' => 'publish',
));
if ($related_posts->have_posts()) : ?>
<div class="MW-Posts-Grid">
<?php
while ($related_posts->have_posts()) :
$related_posts->the_post();
get_template_part('template-parts/post-card');
endwhile;
?>
</div>
<?php else : ?>
<div class="Articles-available">
<span class="Not-available">
لا يتوفر مقالات في الوقت الحالي !
</span>
</div>
<?php endif;
wp_reset_postdata();
?>
</div>
</section>