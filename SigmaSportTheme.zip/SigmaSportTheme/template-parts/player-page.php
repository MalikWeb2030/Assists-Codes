<?php
// template-parts/player-page.php - النسخة النهائية الاحترافية v15.1 Final Pro Clean Edition
$request_uri = $_SERVER['REQUEST_URI'] ?? '';
$uri_parts = explode('/', trim($request_uri, '/'));
$last_segment = end($uri_parts);
$player_id = 0;
if ($last_segment) {
$parts = explode('-', $last_segment);
$player_id = intval(end($parts));
}
if (!$player_id || $player_id <= 0) {
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
$cache_key = "player_entity_v15_1_{$player_id}_ar";
$cached = get_transient($cache_key);
if (false === $cached) {
$api_url = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'athletes' => $player_id,
'fullDetails' => 'true'
], 'https://webws.365scores.com/web/athletes/');
$response = wp_remote_get($api_url, ['timeout' => 20]);
if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
set_transient($cache_key, ['error' => true], HOUR_IN_SECONDS);
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
$body = wp_remote_retrieve_body($response);
$data = json_decode($body, true);
if (empty($data['athletes'][0])) {
set_transient($cache_key, ['error' => true], HOUR_IN_SECONDS);
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
set_transient($cache_key, $data, 30 * DAY_IN_SECONDS);
$p = $data['athletes'][0];
} else {
if (isset($cached['error'])) {
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
$data = $cached;
$p = $data['athletes'][0];
}
// دالة تنظيف آمنة (مخصصة للإحصائيات: تُرجع "-" بدل "غير معروف")
function val_stat($value) {
$value = trim($value ?? '');
if ($value === '' || $value === '-' || $value === null || $value === 'غير معروف') {
return '-';
}
return $value;
}
function val($value, $default = 'غير معروف') {
return (!empty($value) && $value !== '-' && $value !== null && trim($value) !== '') ? trim($value) : $default;
}
$is_coach = false;
$position = val($p['formationPosition']['name'] ?? '');
if (str_contains($position, 'مدرب') || empty($p['highlightStats']) || empty($p['playerDetails'])) {
$is_coach = true;
}
$name = val($p['name']);
if ($name === 'غير معروف' || str_contains($name, 'أهداف') || str_contains($name, 'متوقعة')) {
$name = val($p['shortName'], 'شخص غير معروف');
}
$nationality = val($p['nationalityName'], 'غير معروف');
$nationality_display = $nationality !== 'غير معروف' ? "الجنسية ($nationality)" : 'غير معروف';
$current_team = 'غير معروف';
if (!empty($p['clubId'])) {
$current_team_id = (int)$p['clubId'];
foreach ($data['competitors'] ?? [] as $comp) {
if ($comp['id'] == $current_team_id) {
$team_name = val($comp['name'] ?? $comp['shortName'] ?? '', 'غير معروف');
$current_team = $is_coach ? "مدرب ($team_name)" : "نادي ($team_name)";
break;
}
}
}
if ($current_team === 'غير معروف' && !empty($p['transfers'])) {
foreach ($p['transfers'] as $t) {
if (!empty($t['active'])) {
$team_name = val($t['competitorName'] ?? '', 'غير معروف');
$current_team = $is_coach ? "مدرب ($team_name)" : "نادي ($team_name)";
break;
}
}
}
$age = val($p['age'], '-');
$jersey = $is_coach ? '-' : val($p['playerDetails'][2]['value'] ?? '', '-');
$height = $is_coach ? '-' : val($p['playerDetails'][1]['value'] ?? '', '-');
$has_contract = false;
$contract_year = 'غير معروف';
if (!empty($p['contractUntil']) && preg_match('/(\d{4})/', $p['contractUntil'], $m)) {
$contract_year = $m[1];
$has_contract = true;
} elseif (!empty($p['transfers'][0]['contractUntil']) && preg_match('/(\d{4})/', $p['transfers'][0]['contractUntil'], $m)) {
$contract_year = $m[1];
$has_contract = true;
}
$base = get_template_directory_uri() . '/assets/';
$player_img = "/assets/images/player-img/{$player_id}";
$no_img = $base . 'uploads/none-player.png';
$no_team = $base . 'uploads/none-team.png';
// === إحصائيات الموسم (تظهر فقط إذا لعب مباراة واحدة على الأقل) ===
$show_stats_section = false;
$stats_title = '';
$stats_html = '';
$season_table = '';
if (!$is_coach && !empty($p['highlightStats'][0]['stats'])) {
$stats = $p['highlightStats'][0]['stats'];
$played_matches = 0;
foreach ($stats as $stat) {
if (isset($stat['type']) && $stat['type'] == 5) {
$val = val($stat['value'] ?? '');
if (preg_match('/(\d+)\/\d+/', $val, $m)) {
$played_matches = (int)$m[1];
} elseif (is_numeric($val)) {
$played_matches = (int)$val;
}
break;
}
}
if ($played_matches > 0) {
$show_stats_section = true;
$stats_title = val($p['highlightStats'][0]['name'], 'الموسم الحالي');
for ($i = 0; $i < min(6, count($stats)); $i++) {
$type = $stats[$i]['type'] ?? 'default';
$sname = val($stats[$i]['shortName'] ?? '');
$sval = val_stat($stats[$i]['value'] ?? '');
$stats_html .= "<div class=\"Stats\">
<span><img src=\"data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==\" data-src=\"{$base}uploads/{$type}.png\" onerror=\"this.src='{$base}uploads/none-stat.png'\" loading=\"lazy\"></span>
<span>{$sname}</span><span>{$sval}</span>
</div>";
}
for ($i = 6; $i < count($stats); $i += 2) {
$s1n = val($stats[$i]['shortName'] ?? '');
$s1v = val_stat($stats[$i]['value'] ?? '');
$s2n = isset($stats[$i + 1]) ? val($stats[$i + 1]['shortName'] ?? '') : '';
$s2v = isset($stats[$i + 1]) ? val_stat($stats[$i + 1]['value'] ?? '') : '-';
if ($s1n === 'غير معروف' && $s2n === 'غير معروف') continue;
$class = (($i - 6) % 4 == 0) ? 'even' : 'odd';
$season_table .= "<tr class=\"{$class}\"><th><span>{$s1n}</span><span>{$s1v}</span></th><th><span>{$s2n}</span><span>{$s2v}</span></th></tr>";
}
}
}
// === خريطة الفرق والدوريات ===
$teams_map = [];
$leagues_map = [];
foreach ($data['competitors'] ?? [] as $comp) {
if (!empty($comp['type']) && $comp['type'] == 1) {
$teams_map[$comp['id']] = [
'nameForURL' => $comp['nameForURL'] ?? preg_replace('/[^a-z0-9\-]/', '', strtolower(str_replace(' ', '-', $comp['name'] ?? ''))),
'mainCompId' => $comp['mainCompetitionId'] ?? 0
];
}
}
foreach ($data['competitions'] ?? [] as $league) {
$leagues_map[$league['id']] = $league['nameForURL'] ?? preg_replace('/[^a-z0-9\-]/', '', strtolower(str_replace(' ', '-', $league['name'] ?? '')));
}
// === الانتقالات ===
$has_real_transfers = false;
$transfers_list = '';
if (!empty($p['transfers'])) {
foreach ($p['transfers'] as $t) {
if (!empty($t['competitorId'])) {
$has_real_transfers = true;
break;
}
}
if ($has_real_transfers) {
foreach ($p['transfers'] as $t) {
$title = val($t['transferTitle'] ?? 'انتقال');
$date = !empty($t['date']) ? substr($t['date'], 0, 10) : 'غير معروف';
$price = val($t['price'] ?? 'غير معلن');
$active = !empty($t['active']) ? 'true' : 'false';
$team_id = $t['competitorId'] ?? 0;
$team_link = '#';
if ($team_id && isset($teams_map[$team_id])) {
$team_slug = $teams_map[$team_id]['nameForURL'];
$team_link = "/team/{$team_slug}-{$team_id}/";
}
$transfers_list .= "<li>
<span class=\"s-r\">
<span class=\"s-s\">".esc_html($title)."</span>
<span class=\"s-d\">".esc_html($date)."</span>
<span class=\"s-p\">".esc_html($price)."</span>
</span>
<span class=\"s-c\">
<span class=\"l-t\"></span>
<span class=\"l-c {$active}\"></span>
<span class=\"l-b\"></span>
</span>
<span class=\"s-l\">
<span class=\"s-img\">
<a href=\"".esc_url($team_link)."\">
<img src=\"data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==\"
data-src=\"/assets/images/team-logo/{$team_id}\"
onerror=\"this.src='{$no_team}'\" loading=\"lazy\">
</a>
</span>
</span>
</li>";
}
}
}
// === الألقاب ===
$has_real_trophies = false;
$trophies_table = '';
if (!empty($p['trophies']['categories'])) {
foreach ($p['trophies']['categories'] as $cat) {
foreach ($cat['trophies'] as $t) {
if (!empty($t['count']) && $t['count'] > 0) {
$has_real_trophies = true;
$tname = val($t['displayName'] ?? $t['name'] ?? 'لقب');
$count = $t['count'];
static $i = 0;
$class = ($i % 2 == 0) ? 'even' : 'odd';
$trophies_table .= "<tr class=\"{$class}\"><th>".esc_html($tname)."</th><th>{$count}</th></tr>";
$i++;
}
}
}
}
?>
<section class="MW-Box Player">
<header class="EntityHeader">
<div class="EntitySection">
<div class="EntityCover">
<div class="Cover" style="background-image: url('<?php echo esc_url($player_img); ?>')"></div>
</div>
<div class="EntityBanner">
<div class="EntityImg">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($player_img); ?>"
onerror="this.src='<?php echo esc_url($no_img); ?>'"
alt="<?php echo esc_attr($name); ?>" loading="lazy">
</div>
<div class="EntityInfo">
<h1 class="EntityTitle"><span class="EntityName"><?php echo $is_coach ? 'المدرب' : 'اللاعب'; ?> <?php echo esc_html($name); ?></span></h1>
<span class="EntityMeta">
<span class="MetaItem"><?php echo esc_html($nationality_display); ?></span>
<?php if ($current_team !== 'غير معروف'): ?>
<span class="MetaItem"><?php echo esc_html($current_team); ?></span>
<?php endif; ?>
</span>
</div>  
</div>
</div>
</header>
<div class="PlayerCard">
<div class="player-data">
<h5 class="player-h5">المعلومات الأساسية</h5>   
<table class="player-table">
<tbody>
<tr class="even"><th>الاسم</th><th><?php echo esc_html($name); ?></th></tr>
<?php if (!$is_coach): ?>
<tr class="odd"><th>المركز</th><th><?php echo esc_html($position); ?></th></tr>
<tr class="even"><th>رقم اللاعب</th><th><?php echo esc_html($jersey); ?></th></tr>
<tr class="even"><th>الطول</th><th><?php echo esc_html($height); ?> سم</th></tr>
<?php endif; ?>
<tr class="<?php echo $is_coach ? 'even' : 'odd'; ?>"><th>العمر</th><th><?php echo esc_html($age); ?> سنة</th></tr>
<?php if ($has_contract): ?>
<tr class="<?php echo $is_coach ? 'odd' : 'even'; ?>"><th>العقد ساري حتى</th><th><span class="ContractUntil"><?php echo esc_html($contract_year); ?></span></th></tr>
<?php endif; ?>
</tbody>
</table>
<?php if ($show_stats_section): ?>
<h5 class="player-h5">إحصائيات اللاعب في <?php echo esc_html($stats_title); ?></h5>
<div class="PlayerStatistics">
<div class="PlayerStats"><?php echo $stats_html; ?></div>
<?php if ($season_table): ?>
<table class="SeasonStatistics"><tbody><?php echo $season_table; ?></tbody></table>
<?php endif; ?>
</div>
<?php endif; ?>
<?php if ($has_real_transfers): ?>
<h5 class="player-h5">مسيرة الانتقالات</h5>
<ul class="player-transfers"><?php echo $transfers_list; ?></ul>
<?php endif; ?>
<?php if ($has_real_trophies): ?>
<h5 class="player-h5">قائمة الألقاب</h5>
<table class="player-table"><tbody><?php echo $trophies_table; ?></tbody></table>
<?php endif; ?>
</div>
</div>
</section>