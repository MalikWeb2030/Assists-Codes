<!-- Post Match Card Template -->
<?php
$match_details = get_match_details();
if (!$match_details) {
$match_details = [
'team_one_name' => 'غير معروف',
'team_one_image' => '',
'team_one_score' => 0,
'team_one_penalty_score' => 0,
'match_date' => '',
'match_time' => '',
'team_two_name' => 'غير معروف',
'team_two_image' => '',
'team_two_score' => 0,
'team_two_penalty_score' => 0,
'tournament_name' => 'غير معروف',
'commentator_name' => 'غير معروف',
'channel_name' => 'غير معروف',
'event_status' => 'Automatic',
'external_link' => '',
'match_stadium' => 'غير معروف',
'post_date' => current_time('mysql'),
'channel_post_permalink' => '',
];
}
// Get timezone and time format from theme settings
$options = get_option('mw_theme_options');
$timezone = isset($options['matches_timezone']) ? $options['matches_timezone'] : 'Africa/Cairo';
$time_format = isset($options['time_format']) ? $options['time_format'] : '24';
// Define default team image URL once
$default_team_image = get_template_directory_uri() . '/assets/uploads/none-club.png';
// استرجاع قيمة الـ toggle الجديد لفتح المباراة في نافذة جديدة
$open_match_new_tab = isset($options['open_match_new_tab']) && $options['open_match_new_tab'] === 1;
// Sanitize and prepare values
$team_one_name = esc_html($match_details['team_one_name'] ?? 'غير معروف');
$team_one_image = esc_url($match_details['team_one_image'] ?? $default_team_image);
$team_one_score = isset($match_details['team_one_score']) && $match_details['team_one_score'] !== '' ? esc_html($match_details['team_one_score']) : 0;
$team_one_penalty_score = isset($match_details['team_one_penalty_score']) && $match_details['team_one_penalty_score'] !== '' ? esc_html($match_details['team_one_penalty_score']) : 0;
$match_date = esc_html($match_details['match_date'] ?? 'غير معروف');
// Convert match_date from Ymd to Y-m-d
$match_date_display = ($match_date && $match_date !== 'غير معروف')
? DateTime::createFromFormat('Ymd', $match_date)->format('Y-m-d')
: 'غير معروف';
$match_time = esc_html($match_details['match_time'] ?? 'غير معروف');
// Convert match_time based on selected time format
$match_time_display = ($match_time && $match_time !== 'غير معروف')
? DateTime::createFromFormat('H:i:s', $match_time, new DateTimeZone($timezone))
: false;
if ($match_time_display) {
$match_time_display->setTimezone(new DateTimeZone($timezone));
$match_time_display = $time_format === '12'
? str_replace(['AM', 'PM'], ['ص', 'م'], $match_time_display->format('h:i A'))
: $match_time_display->format('H:i');
} else {
$match_time_display = 'غير معروف';
}
// Define timezone to city name mapping
$timezone_labels = [
'Africa/Cairo' => 'القاهرة',
'Asia/Riyadh' => 'الرياض',
'Africa/Casablanca' => 'الدار البيضاء',
'Asia/Baghdad' => 'بغداد',
'Asia/Qatar' => 'الدوحة',
'Asia/Kuwait' => 'الكويت',
'Africa/Tripoli' => 'طرابلس',
'Asia/Beirut' => 'بيروت',
'Asia/Amman' => 'عمان',
'Asia/Dubai' => 'دبي',
'Asia/Muscat' => 'مسقط',
'Europe/Istanbul' => 'إسطنبول',
'UTC' => 'غرينتش',
'Europe/London' => 'لندن',
'Europe/Paris' => 'باريس',
'Europe/Berlin' => 'برلين',
'Europe/Madrid' => 'مدريد',
'Europe/Rome' => 'روما',
'Europe/Amsterdam' => 'أمستردام',
'Europe/Moscow' => 'موسكو',
];
$timezone_display = isset($timezone_labels[$timezone])
? esc_html($timezone_labels[$timezone])
: 'غير معروف';
$team_two_name = esc_html($match_details['team_two_name'] ?? 'غير معروف');
$team_two_image = esc_url($match_details['team_two_image'] ?? $default_team_image);
$team_two_score = isset($match_details['team_two_score']) && $match_details['team_two_score'] !== '' ? esc_html($match_details['team_two_score']) : 0;
$team_two_penalty_score = isset($match_details['team_two_penalty_score']) && $match_details['team_two_penalty_score'] !== '' ? esc_html($match_details['team_two_penalty_score']) : 0;
$tournament_name = !empty($match_details['tournament_name']) ? esc_html($match_details['tournament_name']) : 'غير معروف';
$commentator_name = !empty($match_details['commentator_name']) ? esc_html($match_details['commentator_name']) : 'غير معروف';
$channel_name = !empty($match_details['channel_name']) ? esc_html($match_details['channel_name']) : 'غير معروف';
$event_status = esc_html($match_details['event_status'] ?? 'Automatic');
$external_link = esc_url($match_details['external_link'] ?? '');
$match_stadium = esc_html($match_details['match_stadium'] ?? 'غير معروف');
$post_date = esc_html($match_details['post_date'] ?? current_time('mysql'));
$channel_post_permalink = esc_url($match_details['channel_post_permalink'] ?? '');
// Translate event status
$status_labels = [
'Automatic' => '',
'Live' => 'جارية الآن',
'CommingSoon' => 'بعد قليل',
'NotStarted' => 'لم تبدأ بعد',
'Ended' => 'انتهت',
'Postponed' => 'تأجلت',
'Canceled' => 'ألغيت',
'EndedPenalty' => 'ركلات ترجيح',
];
$event_status_label = isset($status_labels[$event_status]) ? esc_html($status_labels[$event_status]) : 'غير معروف';
// Generate ISO 8601 datetime
$data_start = '';
if ($match_date !== 'غير معروف' && $match_time !== 'غير معروف') {
try {
$date_time = DateTime::createFromFormat('Ymd H:i:s', "$match_date $match_time", new DateTimeZone($timezone));
if ($date_time) {
$data_start = esc_attr($date_time->format('Y-m-d\TH:i:sP'));
}
} catch (Exception $e) {
$data_start = '';
}
}
// Determine the href value based on conditions
$href = get_permalink(); // Default to post permalink
if (!empty($channel_post_permalink)) {
$href = $channel_post_permalink; // Use channel post permalink if selected
} elseif (!empty($external_link)) {
$href = $external_link; // Use external link if no channel is selected
}
// تحديد target و rel بناءً على الـ toggle الجديد (مع دمج الشرط الحالي للأمان)
$target_attr = '';
$rel_attr = '';
if ($open_match_new_tab || (!empty($external_link) && empty($channel_post_permalink))) {
$target_attr = 'target="_blank"';
$rel_attr = 'rel="noopener noreferrer"';
}
?>
<article class="EventBox<?php echo $event_status !== 'Automatic' ? ' ' . esc_attr($event_status) : ''; ?>" role="article">
<a href="<?php echo esc_url($href); ?>"
id="EventLink"
title="<?php echo esc_attr(sprintf(__('تفاصيل مباراة %s ضد %s في %s', 'malik_web'), $team_one_name, $team_two_name, $tournament_name)); ?>"
aria-label="<?php echo esc_attr(sprintf(__('تفاصيل مباراة %s ضد %s في %s', 'malik_web'), $team_one_name, $team_two_name, $tournament_name)); ?>"
<?php echo $target_attr . ' ' . $rel_attr; ?>>
<div class="EventCover">
<div class="EventIcon" aria-hidden="true"></div>
</div>
</a>
<div class="EventTeams">
<div class="EventTeam Right">
<div class="EventTeamLogo">
<img
alt="<?php echo $team_one_name; ?>"
height="60"
width="60"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $team_one_image; ?>"
title="<?php echo $team_one_name; ?>"
loading="lazy">
<noscript>
<img src="<?php echo $team_one_image; ?>" alt="<?php echo $team_one_name; ?>" height="60" width="60" title="<?php echo $team_one_name; ?>" />
</noscript>
</div>
<div class="EventTeamName"><?php echo $team_one_name; ?></div>
</div>
<div class="EventCenter">
<div class="EventTiming<?php echo $event_status !== 'Automatic' ? ' ' . esc_attr($event_status) : ''; ?>">
<div id="EventHour"><?php echo esc_html($match_time_display); ?></div>
<div id="Score">
<div class="RightScore"><?php echo esc_html($team_one_score); ?></div> -
<div class="LeftScore"><?php echo esc_html($team_two_score); ?></div>
</div>
<?php if ($event_status === 'EndedPenalty' && $team_one_penalty_score !== 'غير معروف' && $team_two_penalty_score !== 'غير معروف'): ?>
<div id="PenaltyScore">
<div class="RightPenaltyScore"><?php echo esc_html($team_one_penalty_score); ?></div> -
Penalty -
<div class="LeftPenaltyScore"><?php echo esc_html($team_two_penalty_score); ?></div>
</div>
<?php endif; ?>
<?php if ($event_status === 'Automatic'): ?>
<span class="EventDate" data-start="<?php echo $data_start; ?>"></span>
<?php else: ?>
<span class="EventDate <?php echo esc_attr($event_status); ?>"><?php echo esc_html($event_status_label); ?></span>
<?php endif; ?>
</div>
</div>
<div class="EventTeam Left">
<div class="EventTeamLogo">
<img
alt="<?php echo $team_two_name; ?>"
height="60"
width="60"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $team_two_image; ?>"
title="<?php echo $team_two_name; ?>"
loading="lazy">
<noscript>
<img src="<?php echo $team_two_image; ?>" alt="<?php echo $team_two_name; ?>" height="60" width="60" title="<?php echo $team_two_name; ?>" />
</noscript>
</div>
<div class="EventTeamName"><?php echo $team_two_name; ?></div>
</div>
</div>
<ul class="EventFooter">
<li><?php echo $commentator_name; ?></li>
<li><?php echo $channel_name; ?></li>
<li><?php echo $tournament_name; ?></li>
</ul>
</article>