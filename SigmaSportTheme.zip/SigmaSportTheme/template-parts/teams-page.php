<?php
/**
* Template Part: Teams Page - روابط موحدة: /team/liverpool-108/
*/
if (!defined('ABSPATH')) {
exit;
}

// الدوريات المطلوبة بالترتيب المرغوب
$leagues = [7, 11, 17, 25, 35, 552, 649];
$cache_key = 'mw_teams_data_grouped_unified_' . md5(implode(',', $leagues));
$cache_expiration = HOUR_IN_SECONDS;

// دالة جلب البيانات + بناء slug موحد زي باقي الموقع
function mw_fetch_teams_data_grouped($leagues, $cache_key, $cache_expiration) {
$cached_data = get_transient($cache_key);
if ($cached_data !== false) {
return $cached_data;
}

$league_teams = [];
$api_base = 'https://webws.365scores.com/web/standings/';
$params = [
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'live' => 'false',
'withSeasons' => 'true'
];

foreach ($leagues as $league_id) {
$url = add_query_arg(array_merge($params, ['competitions' => $league_id]), $api_base);
$response = wp_remote_get($url, ['timeout' => 10, 'user-agent' => 'WordPress']);
if (is_wp_error($response)) {
continue;
}

$body = wp_remote_retrieve_body($response);
$data = json_decode($body, true);
if (json_last_error() !== JSON_ERROR_NONE || empty($data['standings'][0]['rows'])) {
continue;
}

// استخراج nameForURL للدوري فقط (من غير البلد)
$competition = $data['competitions'][0] ?? [];
$league_name_for_url = $competition['nameForURL'] ?? sanitize_title($competition['name'] ?? "league-{$league_id}");

// الـ slug النهائي: premier-league-7 ←← نفس نمط الموقع كله
$league_slug = $league_name_for_url . '-' . $league_id;

foreach ($data['standings'][0]['rows'] as $row) {
$team = $row['competitor'];
$team_id = (int)($team['id'] ?? 0);
if (!$team_id) continue;

$team_name_for_url = $team['nameForURL'] ?? sanitize_title($team['name'] ?? "team-{$team_id}");
$league_teams[$league_id][] = [
'id' => $team_id,
'name' => sanitize_text_field($team['name'] ?? ''),
'name_for_url' => $team_name_for_url,
'league_slug' => $league_slug, // premier-league-7
'team_slug' => $team_name_for_url . '-' . $team_id, // liverpool-108
];
}
}

set_transient($cache_key, $league_teams, $cache_expiration);
return $league_teams;
}

$league_teams = mw_fetch_teams_data_grouped($leagues, $cache_key, $cache_expiration);
$total_teams = 0;
foreach ($league_teams as $teams) {
$total_teams += count($teams);
}

$no_club = '/assets/uploads/none-club.png';
?>
<section class="MW-Box Teams">
<header class="TitleBox">
<h2 class="Title">أهم الأندية الأوروبية والعربية</h2>
</header>
<?php if ($total_teams > 0) : ?>
<div class="Teams-list">
<ul class="Mw-cards">  
<?php foreach ($leagues as $league_id) :
if (empty($league_teams[$league_id])) continue;
foreach ($league_teams[$league_id] as $team) : ?>
<li class="card">
<a href="/team/<?php echo esc_attr($team['team_slug']); ?>/">
<span class="card-image">
<img
alt="<?php echo esc_attr($team['name']); ?>"
title="<?php echo esc_attr($team['name']); ?>"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="/assets/images/team-logo/<?php echo esc_attr($team['id']); ?>"
width="50"
height="50"
loading="lazy"
onerror="this.onerror=null; this.src='<?php echo esc_url($no_club); ?>';">
</span>
<span class="card-name">
<?php echo esc_html($team['name']); ?>
</span>
</a>
</li>
<?php endforeach;
endforeach; ?>
</ul>
</div>
<?php else : ?>
<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>
<?php endif; ?>
</section>