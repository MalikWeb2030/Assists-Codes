<!-- Posts Tags Template -->
<div class="postTags" aria-label="<?php esc_attr_e('وسوم المقالة', 'text-domain'); ?>">
<span class="tagstitle"><?php esc_html_e('الوسوم', 'text-domain'); ?></span>
<ul class="TagsList" role="list">
<?php
$tags = get_the_terms(get_the_ID(), 'post_tag');
if (!empty($tags) && !is_wp_error($tags)) :
foreach ($tags as $tag) : ?>
<li role="listitem">
<a href="<?php echo esc_url(get_term_link($tag)); ?>"
class="tap"
rel="tag"
aria-label="<?php printf(__('وسم: %s', 'text-domain'), esc_attr($tag->name)); ?>">
<?php echo esc_html($tag->name); ?>
</a>
</li>
<?php endforeach;
else : ?>
<li role="listitem"><?php esc_html_e('لا توجد وسوم متاحة.', 'text-domain'); ?></li>
<?php endif; ?>
</ul>
</div>