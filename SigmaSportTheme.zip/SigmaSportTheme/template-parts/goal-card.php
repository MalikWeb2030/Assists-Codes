<!-- Post Card Template -->
<?php
// ضمن توفر المتغير الـ global للترقيم في كل استدعاء
global $post_index;
$post_num_class = (isset($post_index) && is_numeric($post_index) && $post_index > 0) ? esc_attr($post_index) : '0';
$placeholder_src = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';
$default_image_url = get_template_directory_uri() . '/assets/uploads/default.png';
$default_alt = esc_attr(get_the_title() ?: 'صورة افتراضية');
?>
<article class="Post-Item postnum<?php echo $post_num_class; ?>" role="article">
<div class="Post-Img">
<a class="thumb PLHolder" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>" rel="bookmark">
<?php if (has_post_thumbnail()) :
$thumbnail_id = get_post_thumbnail_id();
$thumbnail_url = wp_get_attachment_image_url($thumbnail_id, 'full');
$thumbnail_srcset = wp_get_attachment_image_srcset($thumbnail_id, 'full');
$thumbnail_sizes = wp_get_attachment_image_sizes($thumbnail_id, 'full') ?: '(max-width: 1200px) 100vw, 1200px';
?>
<img src="<?php echo $placeholder_src; ?>"
data-src="<?php echo esc_url($thumbnail_url); ?>"
<?php if ($thumbnail_srcset): ?>
data-srcset="<?php echo esc_attr($thumbnail_srcset); ?>"
data-sizes="<?php echo esc_attr($thumbnail_sizes); ?>"
<?php endif; ?>
class="post-thumb"
alt="<?php echo esc_attr(get_the_title()); ?>"
loading="lazy"
title="<?php echo esc_attr(get_the_title()); ?>"
width="100%"
height="140" />
<?php else : ?>
<img src="<?php echo $placeholder_src; ?>"
data-src="<?php echo esc_url($default_image_url); ?>"
class="post-thumb"
alt="<?php echo $default_alt; ?>"
loading="lazy"
title="<?php echo $default_alt; ?>"
width="100%"
height="140" />
<?php endif; ?>
<noscript>
<?php if (has_post_thumbnail()) :
echo wp_get_attachment_image($thumbnail_id, 'full', false, array(
'class' => 'post-thumb',
'alt' => esc_attr(get_the_title()),
'title' => esc_attr(get_the_title()),
'width' => '100%',
'height' => '140'
));
else : ?>
<img src="<?php echo esc_url($default_image_url); ?>" class="post-thumb" alt="<?php echo $default_alt; ?>" title="<?php echo $default_alt; ?>" width="100%" height="140" />
<?php endif; ?>
</noscript>
</a>
</div>
<div class="Post-Cont">
<h3 class="Post-Title">
<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>" rel="bookmark">
<?php the_title(); ?>
</a>
</h3>
</div>
</article>