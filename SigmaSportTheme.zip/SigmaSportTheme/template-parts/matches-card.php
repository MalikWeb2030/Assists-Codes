<?php
// Retrieve team IDs from ACF fields
$team_one_id = get_field('team_one', get_the_ID());
$team_two_id = get_field('team_two', get_the_ID());
// Initialize default values
$options = get_option('mw_theme_options', []);
$related_posts_background = !empty($options['related_posts_background']) ? esc_url($options['related_posts_background']) : get_template_directory_uri() . '/assets/uploads/stadium.jpg';
$default_team_image = get_template_directory_uri() . '/assets/uploads/none-club.png';
$team_one_name = 'غير معروف';
$team_one_image = $default_team_image;
$team_two_name = 'غير معروف';
$team_two_image = $default_team_image;
// Team One
if ($team_one_id && !is_wp_error($team_one_id)) {
$team_one_term = get_term($team_one_id, 'clubs');
if ($team_one_term && !is_wp_error($team_one_term)) {
$team_one_name = esc_html($team_one_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_one_id);
if ($image_id) {
$team_one_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_one_image;
}
}
}
// Team Two
if ($team_two_id && !is_wp_error($team_two_id)) {
$team_two_term = get_term($team_two_id, 'clubs');
if ($team_two_term && !is_wp_error($team_two_term)) {
$team_two_name = esc_html($team_two_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_two_id);
if ($image_id) {
$team_two_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_two_image;
}
}
}
?>
<article class="Post-Item" role="article">
<a class="thumb" href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>">
<div class="bg" style="background-image: url('<?php echo $related_posts_background; ?>');">
<div class="teams fx-cen">
<div class="team">
<div class="logo" style="background-image: url('<?php echo esc_url($team_one_image); ?>');" aria-label="<?php echo esc_attr($team_one_name); ?>"></div>
</div>
<div class="team vs">
<div class="txt">VS</div>
</div>
<div class="team">
<div class="logo" style="background-image: url('<?php echo esc_url($team_two_image); ?>');" aria-label="<?php echo esc_attr($team_two_name); ?>"></div>
</div>
</div>
</div>
</a>
<div class="Post-Cont">
<h3 class="Post-Title">
<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>"><?php echo esc_html(get_the_title()); ?></a>
</h3>
</div>
</article>