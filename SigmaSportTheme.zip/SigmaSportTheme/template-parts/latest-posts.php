<!-- Latest Posts Section -->
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'section_4' => 'آخر المقالات',
];
$settings = wp_parse_args($options, $defaults);
?>
<section class="MW-Box">
<header class="TitleBox">
<h2 class="Title"><?php echo esc_attr($settings['section_4']); ?></h2>
</header>
<div class="MW-Posts">
<?php
$posts_per_page = get_option('posts_per_page', 12); // ديناميكي: من WP settings
$args = array(
'post_type' => 'post',
'posts_per_page' => $posts_per_page,
'post_status' => 'publish',
'offset' => 0,
);
$query = new WP_Query($args);
if ($query->have_posts()) :
?>
<div class="MW-Posts-Grid"
data-use-offset="true"
data-current-offset="<?php echo $posts_per_page; ?>"
data-posts-per-page="<?php echo $posts_per_page; ?>"
data-post-types="post"
data-total-posts="<?php echo $query->found_posts; ?>">
<?php
global $post_index;
$post_index = 1;
while ($query->have_posts()) : $query->the_post();
get_template_part('template-parts/post-card');
$post_index++;
endwhile;
?>
</div>
<?php
$has_more = $query->found_posts > $posts_per_page;
if ($has_more) :
?>
<div class="load-more-container">
<button class="load-more-btn" aria-label="تحميل المزيد من المقالات">تحميل المزيد</button>
</div>
<?php endif; ?>
<?php else : ?>
<div class="Articles-available">
<span class="Not-available">لا يتوفر مقالات حاليًا!</span>
</div>
<?php endif;
wp_reset_postdata();
?>
</div>
</section>