<!-- Posts Share Template -->
<div class="share-links" aria-label="<?php esc_attr_e('روابط المشاركة', 'text-domain'); ?>">
<?php $current_url = esc_url(get_permalink()); $post_title = esc_html(get_the_title()); ?>
<ul class="ShareLinks" role="list" aria-label="<?php esc_attr_e('روابط المشاركة', 'text-domain'); ?>">
<li role="listitem">
<a aria-label="<?php esc_attr_e('مشاركة على فيسبوك', 'text-domain'); ?>" class="c Fb" data-text="<?php esc_attr_e('مشاركة', 'text-domain'); ?>" href="https://www.facebook.com/sharer.php?u=<?php echo $current_url; ?>" rel="noopener noreferrer" role="button" target="_blank">
<svg class="n-line" aria-hidden="true"><use href="#ic-facebook"></use></svg>
</a>
</li>
<li role="listitem">
<a aria-label="<?php esc_attr_e('مشاركة على واتساب', 'text-domain'); ?>" class="c Wa" data-text="<?php esc_attr_e('مشاركة', 'text-domain'); ?>" href="https://api.whatsapp.com/send?text=<?php echo urlencode($post_title . ' ' . $current_url); ?>" rel="noopener noreferrer" role="button" target="_blank">
<svg class="n-line" aria-hidden="true"><use href="#ic-whatsapp"></use></svg>
</a>
</li>
<li role="listitem">
<a aria-label="<?php esc_attr_e('مشاركة على تويتر', 'text-domain'); ?>" class="c Tw" data-text="<?php esc_attr_e('تغريدة', 'text-domain'); ?>" href="https://twitter.com/share?url=<?php echo $current_url; ?>&text=<?php echo urlencode($post_title); ?>" rel="noopener noreferrer" role="button" target="_blank">
<svg class="n-line" aria-hidden="true"><use href="#ic-twitter"></use></svg>
</a>
</li>
<li role="listitem">
<a aria-label="<?php esc_attr_e('مشاركة على تليجرام', 'text-domain'); ?>" class="c Te" data-text="<?php esc_attr_e('مشاركة', 'text-domain'); ?>" href="https://t.me/share/url?url=<?php echo $current_url; ?>" rel="noopener noreferrer" role="button" target="_blank">
<svg class="n-line" aria-hidden="true"><use href="#ic-telegram"></use></svg>
</a>
</li>
</ul>
</div>