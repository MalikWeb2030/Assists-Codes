<!-- Post Title Template -->
<div class="postTimestamp">
<nav class="breadcrumb" aria-label="مسار التنقل">
<a href="<?php echo esc_url(home_url('/')); ?>" title="<?php esc_attr_e('الرئيسية', 'textdomain'); ?>" aria-label="<?php esc_attr_e('الرئيسية', 'textdomain'); ?>">
<?php esc_html_e('الرئيسية', 'textdomain'); ?>
</a>
<em class="separator" aria-hidden="true">></em>
<?php
$cats = get_the_terms(get_the_ID(), 'category');
if (!empty($cats) && is_array($cats)) {
$first_cat = reset($cats);
echo '<a href="' . esc_url(get_term_link($first_cat)) . '" title="' . esc_attr($first_cat->name) . '" aria-label="' . esc_attr(sprintf(__('فئة: %s', 'textdomain'), $first_cat->name)) . '">' . esc_html($first_cat->name) . '</a>';
}
?>
<em class="separator" aria-hidden="true">></em>
<span aria-current="page"><?php the_title(); ?></span>
</nav>
<header class="PostTitle">
<h1 class="TopicTitle"><?php echo esc_html(get_the_title()); ?></h1>
</header>
<div class="PostMeta">
<div class="article-meta">
<?php
$author_name = trim(get_the_author_meta('display_name'));
if (!empty($author_name)) :
?>
<span class="article-author">
<a href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>" title="<?php esc_attr_e('مقالات المؤلف', 'textdomain'); ?>" aria-label="<?php printf(esc_attr__('مقالات %s', 'textdomain'), esc_attr($author_name)); ?>">
<?php echo esc_html($author_name); ?>
</a>
</span>
<span class="separator" aria-hidden="true"> &gt; </span>
<?php endif; ?>
<span class="article-time">
<time datetime="<?php echo esc_attr(get_the_date('c')); ?>">
<?php echo esc_html(get_the_date('l j F Y, g:i A')); ?>
</time>
</span>
<?php
$modified_time = get_the_modified_time('U');
$published_time = get_the_time('U');
if ($modified_time > $published_time) :
?>
<span class="separator" aria-hidden="true"> &gt; </span>
<span class="article-updated">
<time datetime="<?php echo esc_attr(get_the_modified_date('c')); ?>">
آخر تحديث <?php echo esc_html(get_the_modified_date('j F Y, g:i A')); ?>
</time>
</span>
<?php endif; ?>
</div>
</div>
</div>