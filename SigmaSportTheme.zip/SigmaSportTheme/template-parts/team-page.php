<?php
// template-parts/team-page.php
// استخراج معرف الفريق من الـ URL الجديد بدقة صارمة
$request_uri = $_SERVER['REQUEST_URI'];
$uri_parts = explode('/', trim($request_uri, '/'));
$last_segment = end($uri_parts); // مثل: al-hilal-riyadh-5457
if ($last_segment) {
$slug_parts = explode('-', $last_segment);
$team_id = intval(end($slug_parts)); // يأخذ الجزء الأخير الرقمي فقط
} else {
$team_id = 0;
}
if (!$team_id || $team_id <= 0) {
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
// كاش قوي ودقيق (شهر كامل + يشمل اللغة والتوقيت للدقة)
$cache_key = "squad_365_{$team_id}_ar";
$cached = get_transient($cache_key);
if (false === $cached) {
$api_url = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'competitors' => $team_id
], 'https://webws.365scores.com/web/squads/');
$response = wp_remote_get($api_url, [
'timeout' => 15,
'headers' => [
'User-Agent' => 'Mozilla/5.0 (compatible; WordPress Squad Fetcher)',
],
]);
if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
// محاولة كاش فارغ لتجنب الطلبات المتكررة في حالة الفشل (لمدة ساعة)
set_transient($cache_key, ['error' => true], HOUR_IN_SECONDS);
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
$body = wp_remote_retrieve_body($response);
$data = json_decode($body, true);
if (json_last_error() !== JSON_ERROR_NONE) {
$data = null;
}
if (!$data || empty($data['squads'][0])) {
set_transient($cache_key, ['error' => true], HOUR_IN_SECONDS);
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
// كاش شهر كامل (التشكيلات نادراً ما تتغير)
set_transient($cache_key, $data, 30 * DAY_IN_SECONDS);
} else {
$data = $cached;
// التحقق من خطأ الكاش
if (isset($data['error']) && $data['error']) {
echo '<div class="notice-error"><div class="Articles-available"><span class="Not-available">لا يتوفر بيانات حاليًا!</span></div></div>';
return;
}
}
$squad = $data['squads'][0];
$athletes = $squad['athletes'] ?? [];
$positions = $squad['positions'] ?? [];
$competitor = $data['competitors'][0] ?? null;
$team_name = $competitor['name'] ?? 'فريق غير معروف';
$team_slug = $competitor['nameForURL'] ?? ''; // اسم الفريق الإنجليزي للـ URL
$team_logo = "/assets/images/team-logo/{$team_id}";
$team_cover = $team_logo;
// استخراج اسم الدولة
$country_id = $competitor['countryId'] ?? 0;
$country_name = 'غير معروف';
if ($country_id && isset($data['countries'])) {
foreach ($data['countries'] as $country) {
if ($country['id'] == $country_id) {
$country_name = $country['name'] ?? 'غير معروف';
break;
}
}
}
// استخراج اسم الدوري الرئيسي و slug الخاص به
$main_comp_id = $competitor['mainCompetitionId'] ?? 0;
$league_name = 'غير معروف';
$league_slug = ''; // slug للدوري
if ($main_comp_id && isset($data['competitions'])) {
foreach ($data['competitions'] as $comp) {
if ($comp['id'] == $main_comp_id) {
$league_name = $comp['name'] ?? 'غير معروف';
$league_slug = $comp['nameForURL'] ?? ''; // اسم الدوري الإنجليزي للـ URL
break;
}
}
}
// مسار التيشرت مضمون 100% (باستخدام get_template_directory_uri)
$shirt_svg = get_template_directory_uri() . '/assets/uploads/Shirt.svg';
$no_player_img = '/assets/uploads/none-player.png';
$grouped = [];
foreach ($athletes as $p) {
$pos_id = $p['position']['id'] ?? (($p['position']['isStaff'] ?? false) ? 0 : 999);
$grouped[$pos_id][] = $p;
}
?>
<section class="MW-Box Team">
<header class="EntityHeader">
<div class="EntitySection">
<div class="EntityCover">
<div class="Cover" style="background-image: url('<?php echo esc_url($team_cover); ?>')"></div>
</div>
<div class="EntityBanner">
<div class="EntityImg">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($team_logo); ?>"
onerror="this.src='/assets/uploads/none-team.png'"
alt="<?php echo esc_attr($team_name); ?>"
loading="lazy"
width="50" height="50">
</div>
<div class="EntityInfo">
<h1 class="EntityTitle">
<span class="EntityName">تشكيلة <?php echo esc_html($team_name); ?></span>
</h1>
<span class="EntityMeta">
<span class="MetaItem">
<?php echo esc_html($country_name); ?>
</span>
</span>
</div>
</div>
</div>
</header>
<div class="TeamList">
<?php foreach ($positions as $pos):
$pos_id = $pos['id'];
$pos_title = $pos['title'] ?? $pos['name'];
$players = $grouped[$pos_id] ?? [];
if (empty($players)) continue;
$is_staff = ($pos_id == 0); // تحديد قسم الإدارة (staff)
?>
<div class="position"><?php echo esc_html($pos_title); ?></div>
<table class="team-members">
<thead>
<tr>
<th>#</th>
<th>الأسم</th>
<th>المركز</th>
<th>العمر</th>
<?php if (!$is_staff): ?><th>الرقم</th><?php endif; ?>
</tr>
</thead>
<tbody>
<?php foreach ($players as $index => $player):
$pid = $player['id'];
$name = $player['name'] ?? 'غير معروف';
$player_slug = $player['nameForURL'] ?? ''; // اسم اللاعب الإنجليزي للـ URL
$jersey_raw = $player['jerseyNum'] ?? '-';
$jersey = $jersey_raw;
if ($jersey !== '-' && is_numeric($jersey) && intval($jersey) > 0) {
// القيمة رقم موجب، اتركها كما هي
} else {
$jersey = '-';
}
$age = $player['age'] ?? '-';
$detail_pos = $player['formationPosition']['name'] ?? $player['position']['name'] ?? '-';
// تحديد مسار صورة اللاعب بناءً على مقارنة clubId أو nationalTeamId مع $team_id
$player_img = "/assets/images/player-img/{$pid}"; // افتراضي
$club_id = $player['clubId'] ?? 0;
$national_team_id = $player['nationalTeamId'] ?? 0;
if ($club_id == $team_id) {
$player_img = "/assets/images/player-img/{$pid}";
} elseif ($national_team_id == $team_id) {
$player_img = "/assets/images/national-player-img/{$pid}";  
}
// بناء رابط اللاعب الجديد
$player_link = "/player/{$player_slug}-{$pid}/";
?>
<tr>
<td>
<a href="<?php echo esc_url($player_link); ?>">
<img class="playerlogo"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($player_img); ?>"
onerror="this.src='<?php echo esc_url($no_player_img); ?>'"
alt="<?php echo esc_attr($name); ?>"
loading="lazy"
width="40" height="40">
</a>
</td>
<td><?php echo esc_html($name); ?></td>
<td><?php echo esc_html($detail_pos); ?></td>
<td><?php echo esc_html($age); ?></td>
<?php if (!$is_staff): ?>
<td class="PlayerNum"
style="background-image: url('<?php echo esc_url($shirt_svg); ?>');
background-repeat: no-repeat;
background-size: 60%;
background-position: center center;
font-size: 12px;">
<?php echo esc_html($jersey); ?>
</td>
<?php endif; ?>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php endforeach; ?>
</div>
</section>