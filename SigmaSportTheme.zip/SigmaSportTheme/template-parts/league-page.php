<?php
// template-parts/standings-page.php
defined('ABSPATH') || exit;
// Secure input validation and sanitization
$request_uri = $_SERVER['REQUEST_URI'];
$path = trim(parse_url($request_uri, PHP_URL_PATH), '/');
$path_parts = explode('/', $path);
$slug = end($path_parts);
$slug_parts = explode('-', $slug);
$league_id = absint(end($slug_parts));
if (!$league_id) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
$no_league = '/assets/uploads/none-league.png';
$no_club = '/assets/uploads/none-club.png';
$no_player_img = '/assets/uploads/none-player.png';
// Cache keys for standings and scorers (1 hour expiration)
$standings_cache_key = "standings_{$league_id}_ar";
$scorers_cache_key = "scorers_{$league_id}_ar";
$cache_expiration = HOUR_IN_SECONDS;
// Fetch standings data with cache
$standings_data = get_transient($standings_cache_key);  
if (false === $standings_data) {
$standings_api = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'competitions' => $league_id,
'live' => 'false',
'withSeasons' => 'true'
], 'https://webws.365scores.com/web/standings/');
$standings_response = wp_remote_get($standings_api, ['timeout' => 15]);
if (is_wp_error($standings_response) || wp_remote_retrieve_response_code($standings_response) !== 200) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
$standings_body = wp_remote_retrieve_body($standings_response);
$standings_data = json_decode($standings_body, true);
if (json_last_error() !== JSON_ERROR_NONE) {
$standings_data = null;
}
set_transient($standings_cache_key, $standings_data, $cache_expiration);
}
if (!$standings_data || empty($standings_data['standings'][0])) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
// Extract country name from API response
$competition = $standings_data['competitions'][0] ?? [];
$country_id = absint($competition['countryId'] ?? 0);
$countries = $standings_data['countries'] ?? [];
$country_name = '';
foreach ($countries as $country) {
if (absint($country['id'] ?? 0) == $country_id) {
$country_name = sanitize_text_field($country['name'] ?? '');
break;
}
}
$standings = $standings_data['standings'][0];
$rows = $standings['rows'] ?? [];
$destinations = $standings['destinations'] ?? [];
$groups = $standings['groups'] ?? [];
$league_name = sanitize_text_field($standings['displayName'] ?? 'البطولة');
$is_national = ($standings['competitorType'] ?? 1) == 2;
$season_display = $standings_data['competitions'][0]['seasons'][0]['name'] ?? '';
// Build league slug using nameForURL
$league_name_for_url = $competition['nameForURL'] ?? sanitize_title($league_name);
$league_slug = $league_name_for_url . '-' . $league_id;
// Build teams map for fast lookup with nameForURL (O(1) access) - from standings
$teams_map = [];
$competitors = $standings_data['competitors'] ?? [];
foreach ($competitors as $comp) {
$comp_id = absint($comp['id'] ?? 0);
if ($comp_id) {
$teams_map[$comp_id] = [
'name' => sanitize_text_field($comp['name'] ?? ''),
'nameForURL' => $comp['nameForURL'] ?? sanitize_title($comp['name'])
];
}
}
// Helper: Get team link - accepts either ID (uses map) or full competitor array
function get_team_link($team_input, $teams_map, $league_slug) {
if (is_array($team_input)) {
// If competitor array provided, use directly
$team_id = absint($team_input['id'] ?? 0);
$team_name_for_url = $team_input['nameForURL'] ?? sanitize_title($team_input['name'] ?? '');
} else {
// If ID provided, use map
$team_id = absint($team_input);
if (!isset($teams_map[$team_id])) return '#';
$team_name_for_url = $teams_map[$team_id]['nameForURL'];
}
if (!$team_id || !$team_name_for_url) return '#';
return esc_url("/team/{$team_name_for_url}-{$team_id}/");
}
// Helper: Get border style
function get_destination_border($dest_num, $destinations) {
foreach ($destinations as $d) {
if ($d['num'] == $dest_num) {
$thick = !empty($d['border']) ? '5px' : '4px';
return "border-right: {$thick} solid {$d['color']} !important;";
}
}
return '';
}
// Helper: Get opponent logo path and link
function get_opponent_info($next_match, $team_id, $no_club) {
if (!$next_match) return ['', ''];
$home = $next_match['homeCompetitor'] ?? [];
$away = $next_match['awayCompetitor'] ?? [];
$home_id = absint($home['id'] ?? 0);
$away_id = absint($away['id'] ?? 0);
$opp_id = ($home_id == $team_id) ? $away_id : $home_id;
$opp_array = ($home_id == $team_id) ? $away : $home;
$opp_logo = $opp_id ? "/assets/images/team-logo/{$opp_id}" : $no_club;
return [$opp_logo, $opp_array];
}
// Fetch scorers data with cache
$scorers_data = get_transient($scorers_cache_key);
if (false === $scorers_data) {
$scorers_api = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'competitions' => $league_id,
'competitors' => '',
'withSeasons' => 'true'
], 'https://webws.365scores.com/web/stats/');
$scorers_response = wp_remote_get($scorers_api, ['timeout' => 15]);
if (!is_wp_error($scorers_response) && wp_remote_retrieve_response_code($scorers_response) === 200) {
$scorers_body = wp_remote_retrieve_body($scorers_response);
$scorers_data = json_decode($scorers_body, true);
if (json_last_error() !== JSON_ERROR_NONE) {
$scorers_data = null;
}
} else {
$scorers_data = null;
}
set_transient($scorers_cache_key, $scorers_data, $cache_expiration);
}
// Helper: Get stat by ID
function get_scorers_stat($data, $stat_id) {
if (!$data || !isset($data['stats']['athletesStats'])) return null;
foreach ($data['stats']['athletesStats'] as $stat) {
if ($stat['id'] == $stat_id) {
return $stat;
}
}
return null;
}
$goals_stat = get_scorers_stat($scorers_data, 1); // Goals
$assists_stat = get_scorers_stat($scorers_data, 3); // Assists
$goals_assists_stat = get_scorers_stat($scorers_data, 5); // Goals + Assists
// Build competitors map for fast lookup (O(1) access) - merge with existing if needed, include type
$competitors_map = [];
if ($scorers_data && !empty($scorers_data['competitors'])) {
foreach ($scorers_data['competitors'] as $comp) {
$comp_id = absint($comp['id'] ?? 0);
if ($comp_id) {
$competitors_map[$comp_id] = [
'name' => sanitize_text_field($comp['name'] ?? ''),
'nameForURL' => $comp['nameForURL'] ?? sanitize_title($comp['name']),
'type' => absint($comp['type'] ?? 1) // 1 for club, 2 for national team
];
}
}
}
// Enhanced render for scorers table with position column and new player links
function render_scorers_table($stat_data, $competitors_map, $teams_map, $league_slug, $no_player_img, $no_club) {
if (!$stat_data || empty($stat_data['rows'])) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
?>
<thead>
<tr>
<th>#</th>
<th style="text-align: center;">اللاعب</th>
<th>الفريق</th>
<th class="goals">الأهداف</th> <!-- Dynamic title set in caller -->
</tr>
</thead>
<tbody>
<?php foreach ($stat_data['rows'] as $index => $row):
$player = $row['entity'];
$player_id = absint($player['id'] ?? 0);
$player_name = sanitize_text_field($player['name'] ?? 'غير معروف');
$player_name_for_url = $player['nameForURL'] ?? sanitize_title($player_name);
$team_id = absint($player['competitorId'] ?? 0);
$team_info = $competitors_map[$team_id] ?? ['name' => 'غير معروف', 'nameForURL' => '', 'type' => 1];
$team_name = sanitize_text_field($team_info['name']);
$team_name_for_url = $team_info['nameForURL'] ?? sanitize_title($team_name);
$team_type = absint($team_info['type']);
$team_logo_path = esc_url("/assets/images/team-logo/{$team_id}");
$player_img_path = esc_url( ($team_type == 2 ? "/assets/images/national-player-img/" : "/assets/images/player-img/") . "{$player_id}" );
$main_value = absint($row['stats'][0]['value'] ?? 0);
$row_class = $index % 2 === 0 ? 'even' : 'odd';
$position = $index + 1;
// Build player link: /player/{player_slug}-{player_id}/
$player_link = esc_url("/player/{$player_name_for_url}-{$player_id}/");
$team_link = get_team_link(['id' => $team_id, 'name' => $team_name, 'nameForURL' => $team_name_for_url], $teams_map, $league_slug);
?>
<tr class="<?php echo esc_attr($row_class); ?>">
<th><?php echo esc_html($position); ?></th>
<th>
<span class="player-info">
<a href="<?php echo $player_link; ?>">
<span class="player-img">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($player_img_path); ?>"
onerror="this.src='<?php echo esc_url($no_player_img); ?>'"
alt="<?php echo esc_attr($player_name); ?>"
title="<?php echo esc_attr($player_name); ?>"
loading="lazy"
width="40" height="40">
</span>
<span class="player-name"><?php echo esc_html($player_name); ?></span>
</a>
</span>
</th>
<th>
<span class="player-team-info">
<a href="<?php echo $team_link; ?>">
<span class="player-team-img">
<img class="player-team"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($team_logo_path); ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($team_name); ?>"
loading="lazy"
width="24" height="24">
</span>
<span class="player-team-name"><?php echo esc_html($team_name); ?></span>
</a>
</span>
</th>
<th class="goals"><?php echo esc_html($main_value); ?></th>
</tr>
<?php endforeach; ?>
</tbody>
<?php
}
// Fetch results data
$results_api = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'competitions' => $league_id,
'showOdds' => 'true',
'includeTopBettingOpportunity' => 1
], 'https://webws.365scores.com/web/games/results/');
$results_response = wp_remote_get($results_api, ['timeout' => 15]);
$results_games = [];
if (!is_wp_error($results_response) && wp_remote_retrieve_response_code($results_response) === 200) {
$results_body = wp_remote_retrieve_body($results_response);
$results_data = json_decode($results_body, true);
if (json_last_error() === JSON_ERROR_NONE) {
$results_games = $results_data['games'] ?? [];
}
}
// Group results by date (efficient with array_reduce)
function group_games_by_date($games, $is_fixture = false) {
return array_reduce($games, function($carry, $game) use ($is_fixture) {
$start_time = $game['startTime'] ?? '';
$date = date_i18n('Y-m-d', strtotime($start_time)); // WP i18n for locale
if (!isset($carry[$date])) {
$carry[$date] = [];
}
$carry[$date][] = $game;
return $carry;
}, []);
}
$grouped_results = group_games_by_date($results_games);
// Render results HTML helper with new team links
function render_results_html($grouped_games, $teams_map, $league_slug, $no_club) {
if (empty($grouped_games)) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
krsort($grouped_games); // Chronological order reversed
foreach ($grouped_games as $date => $date_games): ?>
<div class="Match-Date-Group">
<span class="Match-Date-Title"><?php echo esc_html($date); ?></span>
<?php foreach ($date_games as $game):
$home = $game['homeCompetitor'] ?? [];
$away = $game['awayCompetitor'] ?? [];
$home_id = absint($home['id'] ?? 0);
$away_id = absint($away['id'] ?? 0);
$home_name = sanitize_text_field($home['name'] ?? 'غير معروف');
$away_name = sanitize_text_field($away['name'] ?? 'غير معروف');
// Assume scores from API; fallback to 0 if not present (adjust based on actual API keys)
$home_score = absint($game['homeCompetitor']['score'] ?? $game['homeScore'] ?? 0);
$away_score = absint($game['awayCompetitor']['score'] ?? $game['awayScore'] ?? 0);
$round = sanitize_text_field($game['roundName'] ?? 'الجولة') . ' ' . absint($game['roundNum'] ?? '');
$home_logo = esc_url("/assets/images/team-logo/{$home_id}");
$away_logo = esc_url("/assets/images/team-logo/{$away_id}");
// Build links using map or array directly
$home_link = get_team_link($home, $teams_map, $league_slug);
$away_link = get_team_link($away, $teams_map, $league_slug);
?>
<div class="MALIK-WEB-Match">
<div class="Match-Teams">
<div class="Right-Team">
<a href="<?php echo $home_link; ?>">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $home_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($home_name); ?>"
loading="lazy"
width="30" height="30">
<span><?php echo esc_html($home_name); ?></span>
</a>
</div>
<div class="Match-Center">
<div class="Match-Goals"><?php echo esc_html("{$home_score} - {$away_score}"); ?></div>
<div class="Match-Round"><?php echo esc_html($round); ?></div>
</div>
<div class="Left-Team">
<a href="<?php echo $away_link; ?>">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $away_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($away_name); ?>"
loading="lazy"
width="30" height="30">
<span><?php echo esc_html($away_name); ?></span>
</a>
</div>
</div>
</div>
<?php endforeach; ?>
</div>
<?php endforeach;
}
// Fetch fixtures data
$fixtures_api = add_query_arg([
'appTypeId' => 5,
'langId' => 27,
'timezoneName' => 'Africa/Cairo',
'userCountryId' => 131,
'competitions' => $league_id,
'showOdds' => 'true',
'includeTopBettingOpportunity' => 1
], 'https://webws.365scores.com/web/games/fixtures/');
$fixtures_response = wp_remote_get($fixtures_api, ['timeout' => 15]);
$fixtures_games = [];
if (!is_wp_error($fixtures_response) && wp_remote_retrieve_response_code($fixtures_response) === 200) {
$fixtures_body = wp_remote_retrieve_body($fixtures_response);
$fixtures_data = json_decode($fixtures_body, true);
if (json_last_error() === JSON_ERROR_NONE) {
$fixtures_games = $fixtures_data['games'] ?? [];
}
}
$grouped_fixtures = group_games_by_date($fixtures_games);
// Render fixtures HTML helper with new team links and dynamic time via data attribute
function render_fixtures_html($grouped_games, $teams_map, $league_slug, $no_club) {
if (empty($grouped_games)) {
echo '<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>';
return;
}
ksort($grouped_games);
foreach ($grouped_games as $date => $date_games): ?>
<div class="Match-Date-Group">
<span class="Match-Date-Title"><?php echo esc_html($date); ?></span>
<?php foreach ($date_games as $game):
$home = $game['homeCompetitor'] ?? [];
$away = $game['awayCompetitor'] ?? [];
$home_id = absint($home['id'] ?? 0);
$away_id = absint($away['id'] ?? 0);
$home_name = sanitize_text_field($home['name'] ?? 'غير معروف');
$away_name = sanitize_text_field($away['name'] ?? 'غير معروف');
$start_time = $game['startTime'] ?? '';
$round = sanitize_text_field($game['roundName'] ?? 'الجولة') . ' ' . absint($game['roundNum'] ?? '');
$home_logo = esc_url("/assets/images/team-logo/{$home_id}");
$away_logo = esc_url("/assets/images/team-logo/{$away_id}");
// Build links using map or array directly
$home_link = get_team_link($home, $teams_map, $league_slug);
$away_link = get_team_link($away, $teams_map, $league_slug);
?>
<div class="MALIK-WEB-Match">
<div class="Match-Teams">
<div class="Right-Team">
<a href="<?php echo $home_link; ?>">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $home_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($home_name); ?>"
loading="lazy"
width="30" height="30">
<span><?php echo esc_html($home_name); ?></span>
</a>
</div>
<div class="Match-Center">
<div class="Match-Time" data-start-time="<?php echo esc_attr($start_time); ?>">جاري التحميل...</div>
<div class="Match-Round"><?php echo esc_html($round); ?></div>
</div>
<div class="Left-Team">
<a href="<?php echo $away_link; ?>">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $away_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($away_name); ?>"
loading="lazy"
width="30" height="30">
<span><?php echo esc_html($away_name); ?></span>
</a>
</div>
</div>
</div>
<?php endforeach; ?>
</div>
<?php endforeach;
}
?>
<section class="MW-Box Standing">
<header class="EntityHeader">
<div class="EntitySection">
<div class="EntityCover">
<div class="Cover" style="background-image: url(/assets/images/league-logo/<?php echo esc_attr($league_id); ?>)"></div>
</div>
<div class="EntityBanner">
<div class="EntityImg">
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="/assets/images/league-logo/<?php echo esc_attr($league_id); ?>"
onerror="this.src='<?php echo esc_url($no_league); ?>'"
alt="<?php echo esc_attr($league_name); ?>"
loading="lazy"
width="50" height="50">
</div>
<div class="EntityInfo">
<h1 class="EntityTitle">
<span class="EntityName">
جدول ترتيب <?php echo esc_html($league_name); ?>
<?php if (!empty($season_display)): ?>
<?php echo ' ' . esc_html($season_display); ?>
<?php endif; ?>
</span>
</h1>
<span class="EntityMeta">
<span class="MetaItem">
<?php echo esc_html($country_name ?: 'دولة غير محددة'); ?>
</span>
</span>
</div>
</div>
</div>
<div class="Buttons">
<button class="active" id="StandingsBtn"><span class="show">ترتيب الفرق</span><span class="hide">الترتيب</span></button>
<button id="ScorersBtn"><span class="show">ترتيب الهدافين</span><span class="hide">الهدافين</span></button>
<button id="ResultsMatchesBtn"><span class="show">نتائج المباريات</span><span class="hide">النتائج</span></button>
<button id="NextMatchesBtn"><span class="show">المباريات القادمة</span><span class="hide">القادمة</span></button>
<button id="TeamsBtn"><span class="show">الفرق المشاركة</span><span class="hide">الفرق</span></button>
</div>
</header>
<!-- Standings Tab -->
<div class="Standings">
<?php if (!empty($groups)): // Groups ?>
<?php foreach ($groups as $group):
$group_num = absint($group['num']);
$group_name = sanitize_text_field($group['name']);
$group_rows = array_filter($rows, fn($r) => absint($r['groupNum'] ?? 0) == $group_num);
if (empty($group_rows)) continue;
?>
<div class="standings-group">
<h5 class="group-name"><?php echo esc_html($group_name); ?></h5>
<table class="standings">
<thead>
<tr>
<th>#</th>
<th><?php echo $is_national ? 'المنتخب' : 'الفريق'; ?></th>
<th>لعب</th>
<th>فاز</th>
<th>تعادل</th>
<th>خسر</th>
<th>+/-</th>
<th>فارق</th>
<th>نقاط</th>
<th>القادمة</th>
</tr>
</thead>
<tbody>
<?php foreach ($group_rows as $i => $row):
$team = $row['competitor'] ?? [];
$border = get_destination_border(absint($row['destinationNum'] ?? 0), $destinations);
$row_class = $i % 2 === 0 ? 'even' : 'odd';
$team_id = absint($team['id'] ?? 0);
$team_name = sanitize_text_field($team['name'] ?? '');
$team_logo = esc_url("/assets/images/team-logo/{$team_id}");
list($opp_logo, $opp_array) = get_opponent_info($row['nextMatch'] ?? null, $team_id, $no_club);
$team_link = get_team_link($team, $teams_map, $league_slug);
?>
<tr class="<?php echo esc_attr($row_class); ?>">
<th class="destination" style="<?php echo esc_attr($border); ?>"><?php echo absint($row['position']); ?></th>
<th>
<span class="team">
<a href="<?php echo $team_link; ?>">
 <span class="s-team-img">   
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $team_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($team_name); ?>"
loading="lazy"
width="24" height="24">
</span>
<span class="s-team-name"><?php echo esc_html($team_name); ?></span>
</a>
</span>
</th>
<th><?php echo absint($row['gamePlayed']); ?></th>
<th class="won"><?php echo absint($row['gamesWon']); ?></th>
<th class="draw"><?php echo absint($row['gamesEven']); ?></th>
<th class="lost"><?php echo absint($row['gamesLost']); ?></th>
<th><?php echo absint($row['for']); ?> : <?php echo absint($row['against']); ?></th>
<th><?php echo esc_html($row['ratio']); ?></th>
<th><?php echo absint($row['points']); ?></th>
<th class="against">
<span class="s-team-img"> 
<?php if ($opp_logo): ?>
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($opp_logo); ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="منافس"
loading="lazy"
width="20" height="20">
<?php endif; ?>
</span>
</th>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php endforeach; ?>
<?php if ($destinations): ?>
<div class="keys">
<?php foreach ($destinations as $dest): ?>
<span class="key">
<span class="destinations-color" style="background:<?php echo esc_attr($dest['color']); ?>;<?php if (!empty($dest['border'])) echo 'border-right:5px solid ' . esc_attr($dest['color']); ?>"></span>
<span class="destinations-name"><?php echo esc_html($dest['guaranteedText'] ?? $dest['text'] ?? ''); ?></span>
</span>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php else: // Single league ?>
<table class="standings">
<thead>
<tr>
<th>#</th>
<th><?php echo $is_national ? 'المنتخب' : 'الفريق'; ?></th>
<th>لعب</th>
<th>فاز</th>
<th>تعادل</th>
<th>خسر</th>
<th>+/-</th>
<th>فارق</th>
<th>نقاط</th>
<th>القادمة</th>
</tr>
</thead>
<tbody>
<?php foreach ($rows as $i => $row):
$team = $row['competitor'] ?? [];
$border = get_destination_border(absint($row['destinationNum'] ?? 0), $destinations);
$row_class = $i % 2 === 0 ? 'even' : 'odd';
$team_id = absint($team['id'] ?? 0);
$team_name = sanitize_text_field($team['name'] ?? '');
$team_logo = esc_url("/assets/images/team-logo/{$team_id}");
list($opp_logo, $opp_array) = get_opponent_info($row['nextMatch'] ?? null, $team_id, $no_club);
$team_link = get_team_link($team, $teams_map, $league_slug);
?>
<tr class="<?php echo esc_attr($row_class); ?>">
<th class="destination" style="<?php echo esc_attr($border); ?>"><?php echo absint($row['position']); ?></th>
<th>
<span class="team">
<a href="<?php echo $team_link; ?>">
 <span class="s-team-img">  
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo $team_logo; ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="<?php echo esc_attr($team_name); ?>"
loading="lazy"
width="24" height="24">
</span>    
<span class="s-team-name"><?php echo esc_html($team_name); ?></span>
</a>
</span>
</th>
<th><?php echo absint($row['gamePlayed']); ?></th>
<th class="won"><?php echo absint($row['gamesWon']); ?></th>
<th class="draw"><?php echo absint($row['gamesEven']); ?></th>
<th class="lost"><?php echo absint($row['gamesLost']); ?></th>
<th><?php echo absint($row['for']); ?> : <?php echo absint($row['against']); ?></th>
<th><?php echo esc_html($row['ratio']); ?></th>
<th><?php echo absint($row['points']); ?></th>
<th class="against">
 <span class="s-team-img">  
<?php if ($opp_logo): ?>
<img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($opp_logo); ?>"
onerror="this.src='<?php echo esc_url($no_club); ?>'"
alt="منافس"
loading="lazy"
width="20" height="20">
<?php endif; ?>
</span>
</th>
</tr>
<?php endforeach; ?>
</tbody>
</table>
<?php if ($destinations): ?>
<div class="keys">
<?php foreach ($destinations as $dest): ?>
<span class="key">
<span class="destinations-color" style="background:<?php echo esc_attr($dest['color']); ?>;<?php if (!empty($dest['border'])) echo 'border-right:5px solid ' . esc_attr($dest['color']); ?>"></span>
<span class="destinations-name"><?php echo esc_html($dest['guaranteedText'] ?? $dest['text'] ?? ''); ?></span>
</span>
<?php endforeach; ?>
</div>
<?php endif; ?>
<?php endif; ?>
</div>
<!-- Scorers Tab -->
<div class="Scorers" style="display:none;">
<div class="Scorers-Tabs">
<div class="Scorers-Tab active" onclick="switchScorersTab('goals')" data-tab="goals">الأهداف</div>
<div class="Scorers-Tab" onclick="switchScorersTab('assists')" data-tab="assists">صناعة</div>
<div class="Scorers-Tab" onclick="switchScorersTab('goalsassists')" data-tab="goalsassists">أهداف + صناعة</div>
</div>
<!-- Goals Tab -->
<div class="Goals" style="display: block;">
<table class="players">
<?php render_scorers_table($goals_stat, $competitors_map, $teams_map, $league_slug, $no_player_img, $no_club); ?>
</table>
</div>
<!-- Assists Tab -->
<div class="Assists" style="display: none;">
<table class="players">
<?php render_scorers_table($assists_stat, $competitors_map, $teams_map, $league_slug, $no_player_img, $no_club); ?>
</table>
</div>
<!-- Goals + Assists Tab -->
<div class="Goalsassists" style="display: none;">
<table class="players">
<?php render_scorers_table($goals_assists_stat, $competitors_map, $teams_map, $league_slug, $no_player_img, $no_club); ?>
</table>
</div>
</div>
<!-- Results Tab -->
<div class="ResultsMatches" style="display:none;">
<?php render_results_html($grouped_results, $teams_map, $league_slug, $no_club); ?>
</div>
<!-- Fixtures Tab -->
<div class="NextMatches" style="display:none;">
<?php render_fixtures_html($grouped_fixtures, $teams_map, $league_slug, $no_club); ?>
</div>
<!-- Teams Tab - شبكة الفرق المشاركة (نسخة مبسطة وأنيقة جدًا) -->
<div class="Teams" style="display:none;">
<?php
// جمع كل الفرق من الترتيب (يدعم المجموعات والدوري العادي)
$all_teams = [];
if (!empty($groups)) {
foreach ($groups as $group) {
$group_num = absint($group['num']);
$group_rows = array_filter($rows, fn($r) => absint($r['groupNum'] ?? 0) == $group_num);
foreach ($group_rows as $row) {
if (!empty($row['competitor'])) $all_teams[] = $row['competitor'];
}
}
} else {
foreach ($rows as $row) {
if (!empty($row['competitor'])) $all_teams[] = $row['competitor'];
}
}
// إزالة التكرار مع الحفاظ على الترتيب
$unique_teams = [];
$seen = [];
foreach ($all_teams as $team) {
$id = $team['id'] ?? 0;
if ($id && !isset($seen[$id])) {
$seen[$id] = true;
$unique_teams[] = $team;
}
}
if (empty($unique_teams)): ?>
<div class="notice-error">
<div class="Articles-available">
<span class="Not-available">لا يتوفر بيانات حاليًا!</span>
</div>
</div>
<?php else: ?>
<ul class="Mw-cards">
<?php foreach ($unique_teams as $team):
$team_id = absint($team['id'] ?? 0);
$team_name = sanitize_text_field($team['name'] ?? 'غير معروف');
$logo_path = "/assets/images/team-logo/{$team_id}";
$team_link = get_team_link($team, $teams_map, $league_slug);
?>
<li class="card">
<a href="<?php echo $team_link; ?>">
<span class="card-image">
<img alt="<?php echo esc_attr($team_name); ?>"
title="<?php echo esc_attr($team_name); ?>"
src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw=="
data-src="<?php echo esc_url($logo_path); ?>"
width="50"
height="50"
loading="lazy"
onerror="this.onerror=null; this.src='<?php echo esc_url($no_club); ?>';">
</span>
<span class="card-name">
<?php echo esc_html($team_name); ?>
</span>
</a>
</li>
<?php endforeach; ?>
</ul>
<?php endif; ?>
</div>
</section>
<script>
document.addEventListener('DOMContentLoaded', () => {
// Tab switching for main buttons
document.querySelectorAll('.Buttons button').forEach(btn => {
btn.addEventListener('click', () => {
document.querySelectorAll('.Buttons button').forEach(b => b.classList.remove('active'));
btn.classList.add('active');
const target = btn.id.replace('Btn', '');
document.querySelectorAll('.Standing > div[class]').forEach(div => {
div.style.display = div.classList.contains(target) ? 'block' : 'none';
});
});
});
// Scorers sub-tabs
window.switchScorersTab = function(tab) {
document.querySelectorAll('.Scorers-Tabs .Scorers-Tab').forEach(t => t.classList.remove('active'));
document.querySelectorAll('.Scorers > div[class*="Goals"], .Scorers > div[class*="Assists"]').forEach(d => d.style.display = 'none');
document.querySelector(`.Scorers-Tab[data-tab="${tab}"]`).classList.add('active');
const targetDiv = document.querySelector(`.${tab.charAt(0).toUpperCase() + tab.slice(1)}`);
if (targetDiv) targetDiv.style.display = 'block';
};
// Dynamic time formatting for fixtures based on user local timezone
function formatArabicTime(dateStr) {
if (!dateStr) return 'غير محدد';
const date = new Date(dateStr);
if (isNaN(date.getTime())) return 'غير محدد';
const hour = date.getHours();
const period = hour >= 12 ? 'م' : 'ص';
const displayHour = hour % 12 || 12;
const minutes = date.getMinutes().toString().padStart(2, '0');
return `${displayHour}:${minutes} ${period}`;
}
document.querySelectorAll('.Match-Time[data-start-time]').forEach(el => {
const startTime = el.getAttribute('data-start-time');
el.textContent = formatArabicTime(startTime);
});
});
</script>