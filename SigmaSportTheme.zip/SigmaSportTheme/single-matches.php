<?php
get_header();
$match_details = get_match_details();
if (!$match_details) {
$match_details = [
'team_one_name' => 'غير معروف',
'team_one_image' => '',
'team_one_score' => 0,
'team_one_penalty_score' => 0,
'match_date' => '',
'match_time' => '',
'team_two_name' => 'غير معروف',
'team_two_image' => '',
'team_two_score' => 0,
'team_two_penalty_score' => 0,
'tournament_name' => 'غير معروف',
'commentator_name' => '',
'channel_name' => '',
'event_status' => 'Automatic',
'external_link' => '',
'match_stadium' => '',
'post_date' => current_time('mysql'),
];
}
// Get timezone and time format from theme settings
$options = get_option('mw_theme_options');
$timezone = isset($options['matches_timezone']) ? $options['matches_timezone'] : 'Africa/Cairo';
$time_format = isset($options['time_format']) ? $options['time_format'] : '24';
// Define default team image URL once
$default_team_image = get_template_directory_uri() . '/assets/uploads/none-club.png';
// Sanitize and prepare values
$team_one_name = esc_html($match_details['team_one_name'] ?? 'غير معروف');
$team_one_image = esc_url($match_details['team_one_image'] ?? $default_team_image);
$team_one_score = isset($match_details['team_one_score']) && $match_details['team_one_score'] !== '' ? esc_html($match_details['team_one_score']) : 0;
$team_one_penalty_score = isset($match_details['team_one_penalty_score']) && $match_details['team_one_penalty_score'] !== '' ? esc_html($match_details['team_one_penalty_score']) : 0;
$match_date = esc_html($match_details['match_date'] ?? 'غير معروف');
// Convert match_date from Ymd to Y-m-d
$match_date_display = ($match_date && $match_date !== 'غير معروف')
? DateTime::createFromFormat('Ymd', $match_date)->format('Y-m-d')
: 'غير معروف';
$match_time = esc_html($match_details['match_time'] ?? 'غير معروف');
// Convert match_time based on selected time format
$match_time_display = ($match_time && $match_time !== 'غير معروف')
? DateTime::createFromFormat('H:i:s', $match_time, new DateTimeZone($timezone))
: false;
if ($match_time_display) {
$match_time_display->setTimezone(new DateTimeZone($timezone));
$match_time_display = $time_format === '12'
? str_replace(['AM', 'PM'], ['ص', 'م'], $match_time_display->format('h:i A'))
: $match_time_display->format('H:i');
} else {
$match_time_display = 'غير معروف';
if ($match_time && $match_time !== 'غير معروف') {
try {
$dt = DateTime::createFromFormat('H:i', $match_time);
if (!$dt) {
$temp_time = str_replace(['ص', 'م'], ['AM', 'PM'], $match_time);
$dt = DateTime::createFromFormat('h:i A', $temp_time);
}
if ($dt) {
$dt->setTimezone(new DateTimeZone($timezone));
$match_time_display = $time_format === '12'
? str_replace(['AM', 'PM'], ['ص', 'م'], $dt->format('h:i A'))
: $dt->format('H:i');
} else {
if (preg_match('/(\d{1,2}):(\d{2})/', $match_time, $matches)) {
$hour = (int) $matches[1];
$min = (int) $matches[2];
$dt = new DateTime();
$dt->setTime($hour, $min, 0);
$dt->setTimezone(new DateTimeZone($timezone));
$match_time_display = $time_format === '12'
? str_replace(['AM', 'PM'], ['ص', 'م'], $dt->format('h:i A'))
: $dt->format('H:i');
}
}
} catch (Exception $e) {
$match_time_display = $match_time;
}
}
}
// Define timezone to city name mapping
$timezone_labels = [
'Africa/Cairo' => 'القاهرة',
'Asia/Riyadh' => 'الرياض',
'Africa/Casablanca' => 'الدار البيضاء',
'Asia/Baghdad' => 'بغداد',
'Asia/Qatar' => 'الدوحة',
'Asia/Kuwait' => 'الكويت',
'Africa/Tripoli' => 'طرابلس',
'Asia/Beirut' => 'بيروت',
'Asia/Amman' => 'عمان',
'Asia/Dubai' => 'دبي',
'Asia/Muscat' => 'مسقط',
'Europe/Istanbul' => 'إسطنبول',
'UTC' => 'غرينتش',
'Europe/London' => 'لندن',
'Europe/Paris' => 'باريس',
'Europe/Berlin' => 'برلين',
'Europe/Madrid' => 'مدريد',
'Europe/Rome' => 'روما',
'Europe/Amsterdam' => 'أمستردام',
'Europe/Moscow' => 'موسكو',
];
$timezone_display = isset($timezone_labels[$timezone])
? esc_html($timezone_labels[$timezone])
: 'غير معروف';
$team_two_name = esc_html($match_details['team_two_name'] ?? 'غير معروف');
$team_two_image = esc_url($match_details['team_two_image'] ?? $default_team_image);
$team_two_score = isset($match_details['team_two_score']) && $match_details['team_two_score'] !== '' ? esc_html($match_details['team_two_score']) : 0;
$team_two_penalty_score = isset($match_details['team_two_penalty_score']) && $match_details['team_two_penalty_score'] !== '' ? esc_html($match_details['team_two_penalty_score']) : 0;
$tournament_name = !empty($match_details['tournament_name']) ? esc_html($match_details['tournament_name']) : 'غير معروف';
$commentator_name = !empty($match_details['commentator_name']) ? esc_html($match_details['commentator_name']) : 'غير معروف';
$channel_name = !empty($match_details['channel_name']) ? esc_html($match_details['channel_name']) : 'غير معروف';
$event_status = esc_html($match_details['event_status'] ?? 'Automatic');
$external_link = esc_url($match_details['external_link'] ?? '');
$match_stadium = !empty($match_details['match_stadium']) ? esc_html($match_details['match_stadium']) : 'غير معروف';
$post_date = esc_html($match_details['post_date'] ?? current_time('mysql'));
// Translate event status
$status_labels = [
'Automatic' => '',
'Live' => 'جارية الآن',
'CommingSoon' => 'بعد قليل',
'NotStarted' => 'لم تبدأ بعد',
'Ended' => 'انتهت',
'Postponed' => 'تأجلت',
'Canceled' => 'ألغيت',
'EndedPenalty' => 'أنتهت بركلات ترجيح',
];
$event_status_label = isset($status_labels[$event_status]) ? esc_html($status_labels[$event_status]) : 'غير معروف';
// Generate ISO 8601 datetime
$data_start = '';
if ($match_date !== 'غير معروف' && $match_time !== 'غير معروف') {
try {
$date_time = DateTime::createFromFormat('Ymd H:i:s', "$match_date $match_time", new DateTimeZone($timezone));
if ($date_time) {
$data_start = esc_attr($date_time->format('Y-m-d\TH:i:sP'));
}
} catch (Exception $e) {
$data_start = '';
}
}
?>
<main class="container Flex">
<section class="MW-Match" aria-label="تفاصيل المباراة">
<div class="EventBox">
<?php if ($match_details): ?>
<div class="EventTeams">
<div class="EventTeam Right">
<div class="EventTeamLogo">
<?php
$team_one_image_id = $team_one_image ? attachment_url_to_postid($team_one_image) : 0;
if ($team_one_image_id && get_post_type($team_one_image_id) === 'attachment') {
echo wp_get_attachment_image(
$team_one_image_id,
'thumbnail',
false,
[
'alt' => esc_attr($team_one_name),
'title' => esc_attr($team_one_name),
'loading' => 'lazy',
'width' => 96,
'height' => 96,
'sizes' => '(max-width: 600px) 60px, 96px',
]
);
} else {
$team_one_hd_image = str_replace('.png', '-96x96.png', $team_one_image);
$team_one_srcset = esc_url($team_one_image) . ' 1x, ' . esc_url($team_one_hd_image) . ' 1.5x';
echo '<img
alt="' . esc_attr($team_one_name) . '"
height="96"
src="' . esc_url($team_one_image) . '"
srcset="' . $team_one_srcset . '"
onerror="this.onerror=null; this.src=\'' . esc_url($default_team_image) . '\';"
title="' . esc_attr($team_one_name) . '"
width="96"
loading="lazy"
sizes="(max-width: 600px) 60px, 96px">';
}
?>
</div>
<div class="EventTeamName"><?php echo esc_html($team_one_name); ?></div>
</div>
<div class="EventCenter">
<div class="EventTiming<?php echo $event_status !== 'Automatic' ? ' ' . esc_attr($event_status) : ''; ?>">
<div id="EventHour"><?php echo esc_html($match_time_display); ?></div>
<div id="Score">
<div class="RightScore"><?php echo esc_html($team_one_score); ?></div> - <div class="LeftScore"><?php echo esc_html($team_two_score); ?></div>
</div>
<?php if ($event_status === 'EndedPenalty' && $team_one_penalty_score !== 'غير معروف' && $team_two_penalty_score !== 'غير معروف'): ?>
<div id="PenaltyScore">
<div class="RightPenaltyScore"><?php echo esc_html($team_one_penalty_score); ?></div> - Penalty - <div class="LeftPenaltyScore"><?php echo esc_html($team_two_penalty_score); ?></div>
</div>
<?php endif; ?>
<?php if ($event_status === 'Automatic'): ?>
<span class="EventDate" data-start="<?php echo $data_start; ?>"></span>
<?php else: ?>
<span class="EventDate <?php echo esc_attr($event_status); ?>"><?php echo esc_html($event_status_label); ?></span>
<?php endif; ?>
</div>
</div>
<div class="EventTeam Left">
<div class="EventTeamLogo">
<?php
$team_two_image_id = $team_two_image ? attachment_url_to_postid($team_two_image) : 0;
if ($team_two_image_id && get_post_type($team_two_image_id) === 'attachment') {
echo wp_get_attachment_image(
$team_two_image_id,
'thumbnail',
false,
[
'alt' => esc_attr($team_two_name),
'title' => esc_attr($team_two_name),
'loading' => 'lazy',
'width' => 96,
'height' => 96,
'sizes' => '(max-width: 600px) 60px, 96px',
]
);
} else {
$team_two_hd_image = str_replace('.png', '-96x96.png', $team_two_image);
$team_two_srcset = esc_url($team_two_image) . ' 1x, ' . esc_url($team_two_hd_image) . ' 1.5x';
echo '<img
alt="' . esc_attr($team_two_name) . '"
height="96"
src="' . esc_url($team_two_image) . '"
srcset="' . $team_two_srcset . '"
onerror="this.onerror=null; this.src=\'' . esc_url($default_team_image) . '\';"
title="' . esc_attr($team_two_name) . '"
width="96"
loading="lazy"
sizes="(max-width: 600px) 60px, 96px">';
}
?>
</div>
<div class="EventTeamName"><?php echo esc_html($team_two_name); ?></div>
</div>
</div>
<?php endif; ?>
</div>
</section>
<article class="BlogBox" role="article">
<header class="postTimestamp">
<div class="PostTitle">
<h1 class="TopicTitle"><?php echo esc_html(get_the_title()); ?></h1>
</div>
</header>
<main class="PostBody" id="ContentBox">
<div class="match-wrap">
<?php
// جلب إعدادات الإعلانات
$options = get_option('mw_theme_options', []);
$defaults = [
'post_ads_toggle' => 1,
'ad_above_post_enable' => 1,
'ad_above_post_code' => 'مساحة إعلانية',
'ad_under_post_enable' => 1,
'ad_under_post_code' => 'مساحة إعلانية',
];
$settings = wp_parse_args($options, $defaults);
// جلب الإعدادات والتوافر للتبويبات
$tab_live_content = get_option('ds_tab_live_content', 'المحتوى + البث | Live Stream');
$tab_lineup = get_option('ds_tab_lineup', 'التشكيلة | Lineup');
$tab_events = get_option('ds_tab_events', 'أحداث المباراة | Match Events');
$has_lineup = get_post_meta(get_the_ID(), '_has_lineup', true);
$has_events = get_post_meta(get_the_ID(), '_has_events', true);
// عرض الإعلان الأول (قبل التبويبات، إذا مفعل)
if (is_single() && !empty($settings['post_ads_toggle']) && !empty($settings['ad_above_post_enable']) && !empty($settings['ad_above_post_code'])) {
echo '<div class="Post-ads" aria-label="إعلان">' . $settings['ad_above_post_code'] . '</div>';
}
// جلب السيرفرات والموقع
$servers = get_post_meta(get_the_ID(), '_video_servers', true);
$position = get_post_meta(get_the_ID(), '_video_servers_position', true);
// تحديد ما إذا كان يجب عرض التبويبات (إذا كان هناك lineup أو events)
$show_tabs = $has_lineup || $has_events;
if ($show_tabs): ?>
<!-- تبويبات المحتوى -->
<div class="tabs-container">
<div class="tabs-nav">
<!-- تبويب المحتوى الرئيسي (يحتوي على the_content ومشغلات) -->
<button class="tab-btn is-active" data-tab="live-content"><?php echo esc_html($tab_live_content); ?></button>
<?php if ($has_lineup): ?>
<button class="tab-btn" data-tab="lineup"><?php echo esc_html($tab_lineup); ?></button>
<?php endif; ?>
<?php if ($has_events): ?>
<button class="tab-btn" data-tab="events"><?php echo esc_html($tab_events); ?></button>
<?php endif; ?>
</div>
<div class="tabs-content">
<!-- التبويب الرئيسي: يحتوي على المحتوى الأساسي + إعلانات + مشغلات -->
<div id="live-content" class="tab-panel active">
<?php
// عرض المشغل إذا كان 'before' (داخل التبويب الرئيسي)
if ($servers && is_array($servers) && $position == 'before') {
echo '<section class="MW-Player" aria-label="مشغل البث المباشر">
<nav class="MW-Servers" aria-label="قائمة السيرفرات">
<ul class="MW-Links" role="list">';
foreach ($servers as $index => $server) :
$name = !empty($server['name']) ? esc_html($server['name']) : 'سيرفر ' . ($index + 1);
$url = !empty($server['url']) ? esc_url($server['url']) : '#';
echo '<li class="serv" role="listitem">
<a href="' . $url . '" class="tap' . ($index === 0 ? ' active' : '') . '" aria-label="' . esc_attr(sprintf(__('اختيار سيرفر %s', 'textdomain'), $name)) . '">
' . $name . '
</a>
</li>';
endforeach;
echo '</ul>
</nav>
<div class="MW-Video">
<div class="MW-buttons">
<a class="button refresh" href="#" onclick="refreshIframe(event)" role="button" aria-label="تحديث الإطار">تحديث</a>
</div>
<iframe allowfullscreen frameborder="0" height="500px" scrolling="no"
src="' . esc_url($servers[0]['url']) . '" width="100%" aria-label="مشغل الفيديو الرئيسي"></iframe>
</div>
<div class="MW-Note">
<span>تنبيه: في حالة توقف البث قم باختيار سيرفر آخر وسوف يتم تحديث السيرفرات بأسرع ما يمكن ..</span>
</div>
</section>';
}
// عرض المحتوى الأساسي (the_content) داخل التبويب
the_content();
// عرض المشغل إذا كان 'after'
if ($servers && is_array($servers) && $position == 'after') {
echo '<section class="MW-Player" aria-label="مشغل البث المباشر">
<nav class="MW-Servers" aria-label="قائمة السيرفرات">
<ul class="MW-Links" role="list">';
foreach ($servers as $index => $server) :
$name = !empty($server['name']) ? esc_html($server['name']) : 'سيرفر ' . ($index + 1);
$url = !empty($server['url']) ? esc_url($server['url']) : '#';
echo '<li class="serv" role="listitem">
<a href="' . $url . '" class="tap' . ($index === 0 ? ' active' : '') . '" aria-label="' . esc_attr(sprintf(__('اختيار سيرفر %s', 'textdomain'), $name)) . '">
' . $name . '
</a>
</li>';
endforeach;
echo '</ul>
</nav>
<div class="MW-Video">
<div class="MW-buttons">
<a class="button refresh" href="#" onclick="refreshIframe(event)" role="button" aria-label="تحديث الإطار">تحديث</a>
</div>
<iframe allowfullscreen frameborder="0" height="500px" scrolling="no"
src="' . esc_url($servers[0]['url']) . '" width="100%" aria-label="مشغل الفيديو الرئيسي"></iframe>
</div>
<div class="MW-Note">
<span>تنبيه: في حالة توقف البث قم باختيار سيرفر آخر وسوف يتم تحديث السيرفرات بأسرع ما يمكن ..</span>
</div>
</section>';
}
// عرض الإعلان الثاني داخل التبويب (بعد المحتوى)
if (is_single() && !empty($settings['post_ads_toggle']) && !empty($settings['ad_under_post_enable']) && !empty($settings['ad_under_post_code'])) {
echo '<div class="Post-ads" aria-label="إعلان">' . $settings['ad_under_post_code'] . '</div>';
}
?>
</div>
<?php if ($has_lineup): ?>
<div id="lineup" class="tab-panel">
<?php echo ds_get_formation_html(get_the_ID()); ?>
</div>
<?php endif; ?>
<?php if ($has_events): ?>
<div id="events" class="tab-panel">
<?php echo ds_get_match_events_html(get_the_ID()); ?>
</div>
<?php endif; ?>
</div>
</div>
<?php else: ?>
<!-- عرض المحتوى الرئيسي مباشرة بدون تبويبات -->
<?php
// عرض المشغل إذا كان 'before'
if ($servers && is_array($servers) && $position == 'before') {
echo '<section class="MW-Player" aria-label="مشغل البث المباشر">
<nav class="MW-Servers" aria-label="قائمة السيرفرات">
<ul class="MW-Links" role="list">';
foreach ($servers as $index => $server) :
$name = !empty($server['name']) ? esc_html($server['name']) : 'سيرفر ' . ($index + 1);
$url = !empty($server['url']) ? esc_url($server['url']) : '#';
echo '<li class="serv" role="listitem">
<a href="' . $url . '" class="tap' . ($index === 0 ? ' active' : '') . '" aria-label="' . esc_attr(sprintf(__('اختيار سيرفر %s', 'textdomain'), $name)) . '">
' . $name . '
</a>
</li>';
endforeach;
echo '</ul>
</nav>
<div class="MW-Video">
<div class="MW-buttons">
<a class="button refresh" href="#" onclick="refreshIframe(event)" role="button" aria-label="تحديث الإطار">تحديث</a>
</div>
<iframe allowfullscreen frameborder="0" height="500px" scrolling="no"
src="' . esc_url($servers[0]['url']) . '" width="100%" aria-label="مشغل الفيديو الرئيسي"></iframe>
</div>
<div class="MW-Note">
<span>تنبيه: في حالة توقف البث قم باختيار سيرفر آخر وسوف يتم تحديث السيرفرات بأسرع ما يمكن ..</span>
</div>
</section>';
}
// عرض المحتوى الأساسي (the_content)
the_content();
// عرض المشغل إذا كان 'after'
if ($servers && is_array($servers) && $position == 'after') {
echo '<section class="MW-Player" aria-label="مشغل البث المباشر">
<nav class="MW-Servers" aria-label="قائمة السيرفرات">
<ul class="MW-Links" role="list">';
foreach ($servers as $index => $server) :
$name = !empty($server['name']) ? esc_html($server['name']) : 'سيرفر ' . ($index + 1);
$url = !empty($server['url']) ? esc_url($server['url']) : '#';
echo '<li class="serv" role="listitem">
<a href="' . $url . '" class="tap' . ($index === 0 ? ' active' : '') . '" aria-label="' . esc_attr(sprintf(__('اختيار سيرفر %s', 'textdomain'), $name)) . '">
' . $name . '
</a>
</li>';
endforeach;
echo '</ul>
</nav>
<div class="MW-Video">
<div class="MW-buttons">
<a class="button refresh" href="#" onclick="refreshIframe(event)" role="button" aria-label="تحديث الإطار">تحديث</a>
</div>
<iframe allowfullscreen frameborder="0" height="500px" scrolling="no"
src="' . esc_url($servers[0]['url']) . '" width="100%" aria-label="مشغل الفيديو الرئيسي"></iframe>
</div>
<div class="MW-Note">
<span>تنبيه: في حالة توقف البث قم باختيار سيرفر آخر وسوف يتم تحديث السيرفرات بأسرع ما يمكن ..</span>
</div>
</section>';
}
// عرض الإعلان الثاني
if (is_single() && !empty($settings['post_ads_toggle']) && !empty($settings['ad_under_post_enable']) && !empty($settings['ad_under_post_code'])) {
echo '<div class="Post-ads" aria-label="إعلان">' . $settings['ad_under_post_code'] . '</div>';
}
?>
<?php endif; ?>
</div> <!-- نهاية match-wrap -->
<!-- بطاقة المباراة (دائمة الظهور، خارج التبويبات) -->
<h4>بطاقة مباراة <?php echo esc_html($team_one_name); ?> VS <?php echo esc_html($team_two_name); ?></h4>
<table id="match-info" role="table" aria-label="بطاقة مباراة <?php echo esc_attr($team_one_name); ?> ضد <?php echo esc_attr($team_two_name); ?>" style="width: 100%; border-collapse: collapse; direction: rtl;">
<tbody>
<tr>
<th scope="row">البطولة</th>
<td><?php echo esc_html($tournament_name); ?></td>
</tr>
<tr>
<th scope="row">تاريخ المباراة</th>
<td><?php echo esc_html($match_date_display); ?></td>
</tr>
<tr>
<th scope="row">توقيت المباراة</th>
<td><?php echo esc_html($match_time_display); ?> بتوقيت : <?php echo esc_html($timezone_display); ?></td>
</tr>
<tr>
<th scope="row">القناة الناقلة</th>
<td><?php echo esc_html($channel_name); ?></td>
</tr>
<tr>
<th scope="row">معلق المباراة</th>
<td><?php echo esc_html($commentator_name); ?></td>
</tr>
<tr>
<th scope="row">نتيجة المباراة</th>
<td>
<?php echo esc_html($team_one_name); ?> <?php echo esc_html($team_one_score); ?> - <?php echo esc_html($team_two_score); ?> <?php echo esc_html($team_two_name); ?>
<?php if ($event_status === 'EndedPenalty' && is_numeric($team_one_penalty_score) && is_numeric($team_two_penalty_score)): ?>
<small style="color: #d00;">أنتهت بركلات ترجيح : (<?php echo esc_html($team_one_name); ?> <?php echo esc_html($team_one_penalty_score); ?> - <?php echo esc_html($team_two_penalty_score); ?> <?php echo esc_html($team_two_name); ?>)</small>
<?php endif; ?>
</td>
</tr>
<tr>
<th scope="row">ملعب المباراة</th>
<td><?php echo esc_html($match_stadium); ?></td>
</tr>
</tbody>
</table>
<!-- إعلانات إضافية (دائمة، بعد بطاقة المباراة) -->
<?php
$defaults_ads = [
'post_ads_toggle' => 1,
'ad_under_post_h2_1_enable' => 1, 'ad_under_post_h2_1_code' => 'مساحة إعلانية',
'ad_under_post_h2_2_enable' => 1, 'ad_under_post_h2_2_code' => 'مساحة إعلانية',
'ad_under_post_h2_3_enable' => 1, 'ad_under_post_h2_3_code' => 'مساحة إعلانية',
'ad_under_post_h2_4_enable' => 1, 'ad_under_post_h2_4_code' => 'مساحة إعلانية',
'ad_under_post_h3_1_enable' => 1, 'ad_under_post_h3_1_code' => 'مساحة إعلانية',
'ad_under_post_h3_2_enable' => 1, 'ad_under_post_h3_2_code' => 'مساحة إعلانية',
'ad_under_post_h3_3_enable' => 1, 'ad_under_post_h3_3_code' => 'مساحة إعلانية',
'ad_under_post_h3_4_enable' => 1, 'ad_under_post_h3_4_code' => 'مساحة إعلانية',
'ad_under_post_p1_enable' => 1, 'ad_under_post_p1_code' => 'مساحة إعلانية',
'ad_under_post_p2_enable' => 1, 'ad_under_post_p2_code' => 'مساحة إعلانية',
'ad_under_post_p3_enable' => 1, 'ad_under_post_p3_code' => 'مساحة إعلانية',
'ad_under_post_p4_enable' => 1, 'ad_under_post_p4_code' => 'مساحة إعلانية',
];
$settings_ads = wp_parse_args($options, $defaults_ads);
$ads = [
'postad1' => ['enable' => 'ad_under_post_h2_1_enable', 'code' => 'ad_under_post_h2_1_code'],
'postad2' => ['enable' => 'ad_under_post_h2_2_enable', 'code' => 'ad_under_post_h2_2_code'],
'postad3' => ['enable' => 'ad_under_post_h2_3_enable', 'code' => 'ad_under_post_h2_3_code'],
'postad4' => ['enable' => 'ad_under_post_h2_4_enable', 'code' => 'ad_under_post_h2_4_code'],
'postad5' => ['enable' => 'ad_under_post_h3_1_enable', 'code' => 'ad_under_post_h3_1_code'],
'postad6' => ['enable' => 'ad_under_post_h3_2_enable', 'code' => 'ad_under_post_h3_2_code'],
'postad7' => ['enable' => 'ad_under_post_h3_3_enable', 'code' => 'ad_under_post_h3_3_code'],
'postad8' => ['enable' => 'ad_under_post_h3_4_enable', 'code' => 'ad_under_post_h3_4_code'],
'postad9' => ['enable' => 'ad_under_post_p1_enable', 'code' => 'ad_under_post_p1_code'],
'postad10' => ['enable' => 'ad_under_post_p2_enable', 'code' => 'ad_under_post_p2_code'],
'postad11' => ['enable' => 'ad_under_post_p3_enable', 'code' => 'ad_under_post_p3_code'],
'postad12' => ['enable' => 'ad_under_post_p4_enable', 'code' => 'ad_under_post_p4_code'],
];
if (is_single() && !empty($settings_ads['post_ads_toggle'])) {
foreach ($ads as $id => $ad) {
if (!empty($settings_ads[$ad['enable']]) && !empty($settings_ads[$ad['code']])) {
echo '<div class="Post-ads" id="' . esc_attr($id) . '" aria-label="إعلان">' . $settings_ads[$ad['code']] . '</div>';
}
}
}
?>
<footer class="PostFooter">
<?php get_template_part('template-parts/posts-share'); ?>
</footer>
</main>
</article>
<?php
// قسم المباريات ذات الصلة (دائم)
$show_related_posts = isset($options['related_posts_toggle']) ? (int) $options['related_posts_toggle'] : 1;
$related_posts_background = !empty($options['related_posts_background']) ? esc_url($options['related_posts_background']) : get_template_directory_uri() . '/assets/uploads/stadium.jpg';
if ($show_related_posts) {
$related_args = array(
'post_type' => 'matches',
'posts_per_page' => 8,
'post__not_in' => array(get_the_ID()),
'orderby' => 'date',
'order' => 'DESC',
'post_status' => 'publish',
);
$related_query = new WP_Query($related_args);
?>
<section class="PostSearch MW-Box" aria-label="أحدث المباريات ذات الصلة">
<header class="TitleBox">
<h2 class="Title"><?php _e('أحدث المباريات', 'malik_web'); ?></h2>
</header>
<div class="MW-Posts">
<?php if ($related_query->have_posts()) : ?>
<div class="MW-Posts-Grid">
<?php while ($related_query->have_posts()) : $related_query->the_post(); ?>
<?php
$team_one_id = get_field('team_one', get_the_ID());
$team_two_id = get_field('team_two', get_the_ID());
$team_one_name = 'غير معروف';
$team_one_image = $default_team_image;
$team_two_name = 'غير معروف';
$team_two_image = $default_team_image;
if ($team_one_id && !is_wp_error($team_one_id)) {
$team_one_term = get_term($team_one_id, 'clubs');
if ($team_one_term && !is_wp_error($team_one_term)) {
$team_one_name = esc_html($team_one_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_one_id);
if ($image_id) {
$team_one_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_one_image;
}
}
}
if ($team_two_id && !is_wp_error($team_two_id)) {
$team_two_term = get_term($team_two_id, 'clubs');
if ($team_two_term && !is_wp_error($team_two_term)) {
$team_two_name = esc_html($team_two_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_two_id);
if ($image_id) {
$team_two_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_two_image;
}
}
}
?>
<article class="Post-Item" role="article">
<a class="thumb" href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>">
<div class="bg" style="background-image: url('<?php echo $related_posts_background; ?>');">
<div class="teams fx-cen">
<div class="team">
<div class="logo" style="background-image: url('<?php echo esc_url($team_one_image); ?>');" aria-label="<?php echo esc_attr($team_one_name); ?>"></div>
</div>
<div class="team vs">
<div class="txt">VS</div>
</div>
<div class="team">
<div class="logo lazy loaded" style="background-image: url('<?php echo esc_url($team_two_image); ?>');" aria-label="<?php echo esc_attr($team_two_name); ?>"></div>
</div>
</div>
</div>
</a>
<div class="Post-Cont">
<h3 class="Post-Title">
<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>"><?php echo esc_html(get_the_title()); ?></a>
</h3>
</div>
</article>
<?php endwhile; ?>
</div>
<?php else : ?>
<div class="Articles-available">
<span class="Not-available">
<?php _e('لا يتوفر مباريات في الوقت الحالي !', 'malik_web'); ?>
</span>
</div>
<?php endif; ?>
</div>
</section>
<?php
wp_reset_postdata();
}
?>
</main>
<script>
document.addEventListener('DOMContentLoaded', function () {
<?php if ($show_tabs): ?>
// إدارة التبويبات (بناءً على الكود القديم)
const tabs = document.querySelectorAll('.tab-btn');
const contents = document.querySelectorAll('.tab-panel');
tabs.forEach(tab => {
tab.addEventListener('click', function (e) {
e.preventDefault();
tabs.forEach(t => t.classList.remove('is-active'));
contents.forEach(c => c.classList.remove('active'));
this.classList.add('is-active');
const targetContent = document.getElementById(this.dataset.tab);
if (targetContent) {
targetContent.classList.add('active');
}
});
// دعم الكيبورد
tab.addEventListener('keydown', function (e) {
if (e.key === 'Enter' || e.key === ' ') {
e.preventDefault();
tab.click();
}
});
});
<?php endif; ?>
// إدارة أزرار التشكيلة داخل التبويب (إذا كانت موجودة)
const homeTeamBtn = document.getElementById('HomeTeamBtn');
const awayTeamBtn = document.getElementById('AwayTeamBtn');
const homeTeamDiv = document.querySelector('.HomeTeam');
const awayTeamDiv = document.querySelector('.AwayTeam');
if (homeTeamBtn && awayTeamBtn && homeTeamDiv && awayTeamDiv) {
homeTeamBtn.addEventListener('click', function (e) {
e.preventDefault();
homeTeamDiv.style.display = 'block';
awayTeamDiv.style.display = 'none';
homeTeamBtn.classList.add('active');
awayTeamBtn.classList.remove('active');
});
awayTeamBtn.addEventListener('click', function (e) {
e.preventDefault();
homeTeamDiv.style.display = 'none';
awayTeamDiv.style.display = 'block';
awayTeamBtn.classList.add('active');
homeTeamBtn.classList.remove('active');
});
[homeTeamBtn, awayTeamBtn].forEach(btn => {
btn.addEventListener('keydown', function (e) {
if (e.key === 'Enter' || e.key === ' ') {
e.preventDefault();
btn.click();
}
});
});
}
});
</script>

<style>
.tabs-nav{display:flex;flex-wrap:wrap;justify-content:center;gap:var(--Main-Gap);margin-bottom:var(--Main-Margin)}.tab-btn{padding:8px;background:linear-gradient(145deg,#f1f1f1,#e0e0e0);border:none;border-radius:8px;cursor:pointer;font-size:16px;font-weight:500;color:#333;transition:all 0.3s ease;position:relative;overflow:hidden;box-shadow:0 2px 4px rgba(0,0,0,0.1);flex:1}.tab-btn:hover{background:linear-gradient(145deg,<?php echo esc_attr(get_option('ds_active_button_bg_start','#007bff'));?>,<?php echo esc_attr(get_option('ds_active_button_bg_end','#0056b3'));?>);color:#fff;transform:translateY(-2px);box-shadow:0 4px 8px rgba(0,0,0,0.15)}.tab-btn.is-active{background:linear-gradient(145deg,<?php echo esc_attr(get_option('ds_active_button_bg_start','#007bff'));?>,<?php echo esc_attr(get_option('ds_active_button_bg_end','#0056b3'));?>);color:#fff;box-shadow:0 4px 8px rgba(0,123,255,0.3);transform:translateY(-2px)}.tab-panel{display:none}.tab-panel.active{display:block}.container.Flex{max-width:1000px}.EventBox{display:flex;flex-direction:column;align-items:center;justify-content:center;border-radius:var(--Main-Border-Radius);background:url("<?php echo get_template_directory_uri();?>/assets/uploads/match-card-banner.jpg");background-size:100% 100%;background-repeat:no-repeat;overflow:hidden}.EventTeams{display:flex;width:var(--Full-width);background-color:var(--Main-RGB-BG);color:var(--White-Color);align-items:center;justify-content:center;flex-direction:row;padding:var(--Main-Padding) 0;overflow:hidden}ul.EventFooter{display:none}.EventTeams > div{display:flex;flex-direction:column;width:33.3333%;overflow:hidden}.EventTeam > div{display:flex;flex-direction:column;align-items:center;justify-content:center;padding:0}.EventTeamLogo{width:80px;height:80px;margin:auto}.EventTeamLogo img{max-width:70px!important;max-height:70px!important;width:auto;height:auto!important;position:relative;border:0!important;padding:0!important;margin:0 auto}.EventTiming{display:flex;flex-direction:column;align-items:center;justify-content:center}#Score{display:flex;width:50px;height:25px;align-items:center;justify-content:space-between;flex-wrap:nowrap;font-size:var(--Font-Size-5);font-family:arial}.EventDate{display:flex;position:relative;margin-top:var(--Margin-3);font-size:var(--Font-Size-2);border-radius:var(--Main-Border-Radius);border:2px solid #474747;background-color:var(--Main-RGB-BG);width:max-content;padding:0 var(--Padding-4);line-height:30px;align-items:center;flex-direction:row;justify-content:center}.EventTiming .EventDate.Live:before{display:inline-block;background:var(--Gray-Color);content:"";width:10px;height:10px;margin-left:8px;border-radius:var(--Border-Radius-4);background-color:var(--Red-Color);animation:pulse .4s infinite}@keyframes pulse{0%{transform:scale(1);opacity:1}50%{transform:scale(1.2);opacity:0.6}100%{transform:scale(1);opacity:1}}#PenaltyScore{display:flex;width:90px;height:25px;align-items:center;justify-content:space-between;flex-wrap:nowrap;font-size:14px;font-family:arial}.EventTiming.CommingSoon div#Score,.EventTiming.Live div#EventHour,.EventTiming.NotStarted div#Score,.EventTiming.Ended div#EventHour,.EventTiming.Postponed div#EventHour,.EventTiming.Postponed div#Score,.EventTiming.Canceled div#EventHour,.EventTiming.Canceled div#Score,.EventTiming.EndedPenalty div#EventHour{display:none}.EventDate.Canceled,.EventDate.Postponed{margin-top:0!important}.MW-Player{margin-bottom:15px}.MW-Servers{display:block;position:relative;overflow:hidden}.MW-Links{display:flex;clear:both;position:relative;overflow:hidden;width:var(--Full-width);padding:0;margin:0}.MW-Links li{margin:0 0 0 5px;position:relative;float:right;z-index:3;flex:1}.MW-Links li:last-of-type{margin-left:0!important}.MW-Links li a.tap{text-align:center;background-color:var(--Main-Color);color:var(--White-Color)!important;font-size:var(--Font-Size-2);width:var(--Full-width);height:40px;line-height:40px;cursor:pointer;border:0;border-radius:var(--Main-Border-Radius);overflow:hidden;display:block;transition:var(--Tran-1)}.MW-Servers ul.MW-Links li a.tap.active,.MW-Servers ul.MW-Links li a.tap:focus{background-color:#474747}.MW-Video{position:relative;width:100%;height:auto;background:#000;margin:10px 0;border-radius:8px;overflow:hidden}.MW-Note{background:var(--Main-Color);border-radius:revert;text-align:center;color:var(--White-Color);width:var(--Full-width);border-radius:var(--Main-Border-Radius);line-height:40px;height:40px;margin:0}.MW-Video iframe{margin-bottom:0!important}.MW-buttons{position:absolute;z-index:999;top:12px;left:auto;right:12px}.MW-buttons .button{display:block;cursor:pointer;position:absolute;background-color:var(--Main-Color);font-size:14px;text-align:center;line-height:30px;color:#ffffff;padding:0 8px;border-radius:8px;position:relative;float:right;z-index:9}.MW-buttons .refresh:after,.MW-buttons .refresh:before{content:"";position:absolute;left:50%;top:50%;transform:translateX(-50%) translateY(-50%);width:55px;height:35px;line-height:30px;display:block}.MW-buttons .refresh:before{z-index:0;background-color:var(--Main-Color);animation:pulse-border 1.5s ease-out infinite;border-radius:8px}.MW-buttons .refresh:after{z-index:1;border-radius:8px;transition:all .2s}@keyframes pulse-border{0%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1);opacity:1}100%{transform:translateX(-50%) translateY(-50%) translateZ(0) scale(1.5);opacity:0}}.SecTitle{display:block;font-size:18px;font-weight:bold;text-align:center;margin-bottom:12px;background:linear-gradient(to right,#4267b2,#71b6ef,#71b6ef,#4267b2);color:#fff;padding:6px 18px;border-radius:12px}.SquadsButtons{display:flex;flex-direction:row;align-items:center;justify-content:center;margin-bottom:15px;border-radius:12px}.SquadsButtonsCo{display:flex;position:relative;width:50%;border-radius:12px;flex-direction:row;overflow:hidden}.SquadsButtons button{display:block;cursor:pointer;width:50%;background-color:#0e1019;border:inherit;-webkit-transition:all .3s;transition:all .3s;font-family:inherit;position:relative;font-size:14px;color:#fff;text-shadow:2px 2px 4px rgba(0,0,0,0.45);padding:8px 12px;height:40px;line-height:15px;overflow:hidden}.SquadsButtons button.active{background-color:#39dbbf}.Dividing{display:flex;position:relative;align-items:center;justify-content:center;flex-direction:row;margin-bottom:12px;overflow:hidden}.Dividing span{display:block;background-color:#0e1019;color:#fff;border-radius:8px;font-size:14px;padding:0 12px;z-index:8}.TeamSquad{display:flex;flex-direction:column;justify-content:center;position:relative;overflow:hidden}.StartSquad{display:flex;background-image:url(<?php echo get_template_directory_uri();?>/assets/uploads/football-field.webp);background-repeat:no-repeat;background-size:cover;background-position:center center;flex-direction:column;position:relative;height:490px;width:100%;max-width:800px;align-items:center;overflow:hidden;padding:15px 0;margin:auto;margin-bottom:15px;justify-content:space-around;z-index:1}.TeamLine{display:flex;align-items:center;justify-content:center;flex-wrap:nowrap;flex-direction:row}.Player{display:flex;position:relative;width:70px;height:60px;margin:0 15px;flex-direction:column;align-items:center;justify-content:center}.Player svg{width:50px;height:40px}.HomeTeam .Player svg{color:#409fe1!important}.AwayTeam .Player svg{color:#e84c3d!important}.PLogo{display:flex;width:70px;height:70px;text-align:center;align-items:center;justify-content:center}.PLogo img{display:table;width:100%;height:auto;max-width:60px;max-height:60px}.PName{display:block;position:relative;text-align:center;color:#fff;font-size:10px;height:20px;line-height:20px;overflow:hidden}.PNumber{display:flex;position:absolute;font-size:12px;width:20px;height:20px;border-radius:50%;text-align:center;justify-content:center;color:#fff;top:15px;flex-direction:column;align-items:center}.SubSquad{position:relative;display:grid;grid-gap:12px;grid-template-columns:repeat(3,1fr);margin-bottom:12px}.SubPlayer{display:flex;background-color:#e4eeff;border:1px solid #d1e7ff;padding:6px 18px;border-radius:12px;flex-direction:row;align-items:center;overflow:hidden;justify-content:space-between}.SubPlayerCo{display:flex;position:relative;flex-direction:row;justify-content:center;overflow:hidden;align-items:center}.SubLogo{display:inline-block;position:relative;width:40px;height:40px;margin-left:15px;overflow:hidden}.SubLogo img{display:table;width:100%;height:auto;max-width:40px;max-height:40px;margin:auto}.PlayerDetails{display:flex;flex-direction:column;align-items:flex-start;justify-content:center}.SubNumber{display:block;width:30px;text-align:center;margin-left:12px}.SubNumber span{display:flex;align-items:center;justify-content:center;font-size:14px}.SubName{display:block;text-align:center;font-size:16px;line-height:25px}.SubPosition{display:block;line-height:25px;color:#718ba1;font-size:12px}.InjuryDetails{display:block;line-height:25px;font-size:11px}.LeagueCo{display:flex;width:100%;background-color:#e4eeff;border:1px solid #d1e7ff;border-radius:12px;margin-bottom:12px;padding:12px;flex-direction:row;align-items:center;overflow:hidden;justify-content:center}span.LeagueCoLogo{display:flex;position:relative;flex-direction:column;align-items:center;justify-content:center;background-color:#fff;border:1px solid #d1e7ff;border-radius:50%;width:60px;height:60px;padding:10px;margin-left:12px;overflow:hidden}span.LeagueCoLogo img{max-width:40px!important;max-height:40px;width:auto;height:auto!important;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);border:0!important;padding:0!important;margin:0 -50px 0 auto!important}.EventsTable{display:flex;flex-direction:column-reverse;justify-content:center;border-radius:12px;margin-bottom:12px;border:1px solid #d1e7ff;overflow:hidden}.Event{display:flex;width:100%;height:45px;padding:0 20px;flex-direction:row;align-items:center;justify-content:center;overflow:hidden}.Event.odd{background-color:#eceef2}.Event.even{background-color:#e4eeff}.Event:not(:last-of-type){border-top:1px solid #d1e7ff}.HomeTeamEven,.AwayTeamEven{display:flex;width:45%}.HomeTeamEven{flex-direction:row;align-items:center}.AwayTeamEven{flex-direction:row-reverse;align-items:center}.EventTime{display:flex;width:10%;align-items:center;justify-content:center}.EventTime span{display:flex;position:relative;background-color:#fff;color:#718ba1;font-size:12px;border-radius:50%;width:28px;height:28px;align-items:center;justify-content:center;border:2px solid #718ba1}.EventTime span::before,.EventTime span::after{content:"";position:absolute;bottom:-10px;width:2px;height:10px;background-color:#718ba1}.EventTime span::before{bottom:-10px}.EventTime span::after{top:-10px}.Event:first-of-type .EventTime span::before,.Event:last-of-type .EventTime span::after{display:none!important}.EvenPlayersCo{display:flex;width:100%;align-items:center}.HomeTeamEven .EvenPlayersCo{flex-direction:row}.AwayTeamEven .EvenPlayersCo{flex-direction:row-reverse}.EvenPlayer,.EvenPlayers{display:flex;width:80%;align-items:center;flex-direction:row}.EventType{display:flex;width:20%;flex-direction:column;align-items:center}.EventType img{width:100%;height:auto;max-width:25px;max-height:25px}span.EvenPlayerImg{display:flex;flex-direction:column;align-items:center;justify-content:center;width:30px;height:30px}.EvenPlayer span.EvenPlayerImg{width:60px;float:right}.HomeTeamEven span.EvenPlayerImg{align-items:flex-start}.AwayTeamEven span.EvenPlayerImg{align-items:flex-end}span.EvenPlayerImg img{width:30px;height:30px}.HomeTeamEven span.EvenPlayerImg{margin-left:12px}.AwayTeamEven span.EvenPlayerImg{margin-right:12px}.EvenPlayersName{display:flex;flex-direction:column}.AwayTeamEven .EvenPlayersCo .EvenPlayers,.AwayTeamEven .EvenPlayer{flex-direction:row-reverse}.HomeTeamEven .EvenPlayersCo .EvenPlayers{flex-direction:row}.EvenPlayers .EvenPlayersLogo{display:flex;justify-content:center;align-items:center;overflow:hidden}.HomeTeamEven .EvenPlayers .EvenPlayersLogo{margin-left:12px}.AwayTeamEven .EvenPlayers .EvenPlayersLogo{margin-right:12px}.EvenPlayers .EvenPlayersLogo span.EvenPlayerImg{margin:0!important}span.EvenPlayerName{font-size:12px;line-height:15px;height:15px;color:#718ba1;overflow:hidden}.HomeTeamEven span.EvenPlayerName{text-align:right}.AwayTeamEven span.EvenPlayerName{text-align:left}.HomeTeamEven span.EvenPlayerImg.OutSide{display:block;position:relative;right:-8px}.AwayTeamEven span.EvenPlayerImg.OutSide{display:block;position:relative;left:-8px}span.EvenPlayerImg.OutSide img{border:1px solid #fc4d4d;border-radius:50%}span.EvenPlayerName.OutSide{color:#fc4d4d}span.EvenPlayerImg.InSide img{border:1px solid #5bd286;border-radius:50%}span.EvenPlayerName.InSide{color:#5bd286}.Night .tab-btn,.Night .SecTitle,.Night .Event.even,.Night table.MeetDetailsTable tbody tr,.Night .AnalyticsLine.Line1,.Night .AnalyticsLineTop,.Night table.standings tbody tr.even th:not(.tnt),.Night table.standings tbody tr.odd th:not(.tnt),.Night table.players tbody tr.even,.Night table.players tbody tr.odd{background:#0e1019;color:#fff}.Night .Outlook,.Night .Findings,.Night .TopPlayersLine,.Night .Meetings,.Night .PreviousTable,.Night .MatchIframe,.Night span.AnaNameLineName,.Night .SubPlayer,.Night .LeagueCo,.Night h6.no-data{background:#0e1019;border:1px solid #252c37;color:#fff}.Night span.HomePlayerSection > span,.Night span.NamesSection > span,.Night span.AwayPlayerSection > span{background:#191d2d;border:1px solid #252c37;color:#fff}.Night .Event.odd,.Night .AnalyticsLine.Line2{background-color:#191d2d}.Night .EventsTable,.Night .AnalyticsTable{border:1px solid #252c37}.Night .Event:not(:last-of-type),.Night .AnalyticsLine:not(:first-of-type){border-top:1px solid #252c37}.Night .TopPlayerLoc{border-bottom:1px solid #252c37}.Night span.TopPlayerName,.Night .TopPlayerLoc,.Night .AnaHomeTeam,.Night .AnaAwayTeam{color:#fff}.Night .TieStats{border-right:2px solid #252c37;border-left:2px solid #252c37}.Night .PreviousMatch:not(:last-of-type){border-bottom:2px solid #252c37}.Night .SubNumber span{color:#444!important}@media screen and (max-width:650px){.SquadsButtonsCo{width:100%;font-size:14px}.SubSquad{grid-template-columns:repeat(2,1fr)}.StartSquad{height:350px;max-width:550px}.Player{width:60px;height:60px;margin:0 10px}}@media screen and (max-width:550px){.StartSquad{height:300px;max-width:450px}.Player{width:30px;height:30px}}@media screen and (max-width:450px){.SubSquad{grid-template-columns:repeat(1,1fr)}.StartSquad{height:200px;max-width:350px}.tabs-nav{flex-direction:column}}@media screen and (max-width:400px){.SubSquad{grid-template-columns:repeat(1,1fr)}.EventTeam > div{font-size:12px}.tab-btn{font-size:14px}.PName{display:none}.PNumber{height:5px}.Event{padding:0 10px}}.thumb .bg{overflow:hidden;border-radius:var(--Main-Border-Radius);background-size:cover;background-position:center;height:100%;position:relative;display:flex;justify-content:center;align-items:center}.thumb .bg::before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);z-index:1}.teams{display:flex;align-items:center;gap:var(--Main-Gap);position:relative;z-index:2}.team{flex:1;text-align:center}.team.vs{flex:0;font-weight:bold}.txt{font-size:var(--Font-Size-4);color:var(--White-Color);font-weight:var(--Font-Weight-1)}.logo{width:60px;height:60px;background-size:cover;background-position:center;border-radius:50%;margin:0 auto;border:2px solid #eceef2;box-shadow:var(--Main-Box-Shadow)}
</style>
<?php get_footer(); ?>