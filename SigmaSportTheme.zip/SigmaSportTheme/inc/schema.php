<?php
/**
* Schema Output Pro - Sigma Sport Theme 2025
*
* يحتوي على:
* 1. Articles Carousel → NewsArticle
* 2. Goals Video Carousel → VideoObject
* 3. Matches SportsEvent Carousel → أقوى جدول مباريات في 2025
*
* متوافق تمامًا مع:
* - Rank Math Pro / Yoast SEO
* - Google Rich Results (نوفمبر 2025)
* - Schema.org v29.3
*/
if (!defined('ABSPATH')) {
exit; // Exit if accessed directly
}
/* ==========================================================================
Helper: Output JSON-LD Schema (مع تنظيف ومنع التكرار)
========================================================================== */
function mw_output_schema(array $schema, string $id): void
{
if (empty($schema['itemListElement'] ?? [])) {
return;
}
$schema['@context'] = 'https://schema.org';
echo '<script type="application/ld+json" id="' . esc_attr($id) . '">';
echo json_encode(
$schema,
JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT
);
echo '</script>' . PHP_EOL;
}
/* ==========================================================================
1. Articles Carousel Schema (NewsArticle) – Homepage + Archives
========================================================================== */
add_action('wp_head', 'mw_articles_carousel_schema', 5);
function mw_articles_carousel_schema(): void
{
if (! (is_home() || is_front_page() || is_category() || is_tag() || is_archive())) {
return;
}
if ($GLOBALS['mw_schema_articles_done'] ?? false) {
return;
}
$paged = max(1, (int) get_query_var('paged'));
$args = [
'post_type' => 'post',
'post_status' => 'publish',
'posts_per_page' => 20,
'paged' => $paged,
'ignore_sticky_posts' => true,
];
if (is_category()) {
$args['cat'] = get_queried_object_id();
}
if (is_tag()) {
$args['tag_id'] = get_queried_object_id();
}
$query = new WP_Query($args);
if (!$query->have_posts()) {
wp_reset_postdata();
return;
}
$items = [];
while ($query->have_posts()) {
$query->the_post();
$image = has_post_thumbnail()
? wp_get_attachment_image_url(get_post_thumbnail_id(), 'large')
: get_template_directory_uri() . '/assets/uploads/default.png';
$items[] = [
'@type' => 'ListItem',
'position' => count($items) + 1,
'url' => get_permalink(),
'item' => [
'@type' => 'NewsArticle',
'headline' => wp_strip_all_tags(get_the_title()),
'url' => get_permalink(),
'datePublished' => get_the_date('c'),
'dateModified' => get_the_modified_date('c'),
'image' => $image,
'description' => wp_trim_words(wp_strip_all_tags(get_the_excerpt() ?: get_the_content()), 30, '...'),
'author' => [
'@type' => 'Person',
'name' => get_the_author()
],
'publisher' => [
'@type' => 'Organization',
'name' => get_bloginfo('name'),
'logo' => [
'@type' => 'ImageObject',
'url' => has_custom_logo()
? wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full')
: $image
]
]
]
];
}
wp_reset_postdata();
mw_output_schema(['@type' => 'ItemList', 'itemListElement' => $items], 'mw-articles-carousel');
$GLOBALS['mw_schema_articles_done'] = true;
}
/* ==========================================================================
2. Goals Video Carousel Schema (VideoObject)
========================================================================== */
add_action('wp_head', 'mw_goals_video_carousel_schema', 6);
function mw_goals_video_carousel_schema(): void
{
if (! (is_home() || is_front_page() || is_post_type_archive('goals') || is_singular('goals'))) {
return;
}
if ($GLOBALS['mw_schema_goals_done'] ?? false) {
return;
}
$query = new WP_Query([
'post_type' => 'goals',
'post_status' => 'publish',
'posts_per_page' => 24,
'meta_query' => [
[
'key' => '_summary_link',
'value' => '',
'compare' => '!='
]
]
]);
if (!$query->have_posts()) {
wp_reset_postdata();
return;
}
$items = [];
while ($query->have_posts()) {
$query->the_post();
$video_url = get_post_meta(get_the_ID(), '_summary_link', true);
if (!$video_url || !filter_var($video_url, FILTER_VALIDATE_URL)) {
continue;
}
$thumb = has_post_thumbnail()
? wp_get_attachment_image_url(get_post_thumbnail_id(), 'large')
: get_template_directory_uri() . '/assets/uploads/default.png';
$embed_url = $video_url;
if (preg_match('#(?:youtube\.com|youtu\.be)/([^"&?/ ]{11})#i', $video_url, $m)) {
$embed_url = 'https://www.youtube.com/embed/' . $m[1];
}
$items[] = [
'@type' => 'ListItem',
'position' => count($items) + 1,
'url' => get_permalink(),
'item' => [
'@type' => 'VideoObject',
'name' => wp_strip_all_tags(get_the_title()),
'description' => wp_trim_words(wp_strip_all_tags(get_the_excerpt() ?: get_the_content()), 50, '...'),
'thumbnailUrl' => $thumb,
'uploadDate' => get_the_date('c'),
'contentUrl' => $video_url,
'embedUrl' => $embed_url,
'duration' => 'PT3M',
'publisher' => [
'@type' => 'Organization',
'name' => get_bloginfo('name'),
'logo' => [
'@type' => 'ImageObject',
'url' => has_custom_logo()
? wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full')
: $thumb
]
]
]
];
}
wp_reset_postdata();
mw_output_schema(['@type' => 'ItemList', 'itemListElement' => $items], 'mw-goals-video-carousel');
$GLOBALS['mw_schema_goals_done'] = true;
}
/* ==========================================================================
3. Matches SportsEvent Carousel Schema (الأقوى في 2025)
========================================================================== */
add_action('wp_head', 'mw_matches_sportsevent_schema', 7);
function mw_matches_sportsevent_schema(): void
{
$allowed = is_home() || is_front_page() || is_post_type_archive('matches') || is_singular('matches');
$day_var = get_query_var('match_day');
if (!$allowed && !in_array($day_var, ['today', 'yesterday', 'tomorrow'], true)) {
return;
}
if ($GLOBALS['mw_schema_matches_done'] ?? false) {
return;
}
$query = new WP_Query([
'post_type' => 'matches',
'post_status' => 'publish',
'posts_per_page' => 30,
'meta_query' => [
'relation' => 'AND',
['key' => 'match_date', 'compare' => '!=', 'value' => ''],
['key' => 'match_time', 'compare' => '!=', 'value' => '']
],
'orderby' => 'meta_value',
'meta_key' => 'match_date',
'order' => 'ASC'
]);
if (!$query->have_posts()) {
wp_reset_postdata();
return;
}
$timezone = wp_timezone_string();
$items = [];
while ($query->have_posts()) {
$query->the_post();
$id = get_the_ID();
// Team 1
$team1_name = 'غير معروف';
$team1_logo = get_template_directory_uri() . '/assets/uploads/none-club.png';
$t1 = get_field('team_one', $id);
if ($t1) {
$term = get_term($t1, 'clubs');
if ($term && !is_wp_error($term)) {
$team1_name = $term->name;
$img_id = get_field('club_image', 'clubs_' . $t1);
if ($img_id) {
$team1_logo = wp_get_attachment_image_url($img_id, 'medium') ?: $team1_logo;
}
}
}
// Team 2
$team2_name = 'غير معروف';
$team2_logo = get_template_directory_uri() . '/assets/uploads/none-club.png';
$t2 = get_field('team_two', $id);
if ($t2) {
$term = get_term($t2, 'clubs');
if ($term && !is_wp_error($term)) {
$team2_name = $term->name;
$img_id = get_field('club_image', 'clubs_' . $t2);
if ($img_id) {
$team2_logo = wp_get_attachment_image_url($img_id, 'medium') ?: $team2_logo;
}
}
}
// Start Date
$start_date = null;
$date = get_field('match_date', $id); // Ymd
$time = get_field('match_time', $id); // H:i:s
if ($date && $time) {
$dt = DateTime::createFromFormat('Ymd H:i:s', $date . ' ' . $time, new DateTimeZone($timezone));
if ($dt) {
$dt->setTimezone(new DateTimeZone('UTC'));
$start_date = $dt->format('c');
}
}
// Event Status
$status = get_field('event_status', $id) ?: 'Automatic';
$status_map = [
'Automatic' => 'https://schema.org/EventScheduled',
'Live' => 'https://schema.org/EventMovedOnline',
'Ended' => 'https://schema.org/EventCompleted',
'Postponed' => 'https://schema.org/EventPostponed',
'Canceled' => 'https://schema.org/EventCancelled',
'EndedPenalty' => 'https://schema.org/EventCompleted',
];
$event_status = $status_map[$status] ?? 'https://schema.org/EventScheduled';
$event = [
'@type' => 'SportsEvent',
'name' => $team1_name . ' vs ' . $team2_name,
'startDate' => $start_date,
'eventStatus' => $event_status,
'homeTeam' => ['@type' => 'SportsTeam', 'name' => $team1_name, 'logo' => $team1_logo],
'awayTeam' => ['@type' => 'SportsTeam', 'name' => $team2_name, 'logo' => $team2_logo],
'location' => ['@type' => 'Place', 'name' => get_field('match_stadium', $id) ?: 'ملعب غير محدد'],
'performer' => ['@type' => 'Person', 'name' => get_field('commentator', $id) ?: 'غير محدد'],
'organizer' => ['@type' => 'Organization', 'name' => get_field('channel', $id) ?: get_bloginfo('name')],
'url' => get_permalink(),
'image' => [$team1_logo, $team2_logo]
];
if ($external = get_field('external_link', $id)) {
$event['offers'] = ['@type' => 'Offer', 'url' => $external];
}
if (!$start_date) {
unset($event['startDate']);
}
$items[] = [
'@type' => 'ListItem',
'position' => count($items) + 1,
'item' => $event
];
}
wp_reset_postdata();
mw_output_schema(['@type' => 'ItemList', 'itemListElement' => $items], 'mw-matches-sportsevent');
$GLOBALS['mw_schema_matches_done'] = true;
}