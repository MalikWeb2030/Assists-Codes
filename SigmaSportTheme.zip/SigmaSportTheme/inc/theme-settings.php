<?php
/**
* Theme Settings Page for Sigma Sport Theme
* Standalone admin settings page with enhanced UX using div-based structure
* Version: 1.0.0
* Author: Malik Web Team
*/
/**
* Enqueue Media Library Scripts
*/
function mw_enqueue_media_scripts() {
if (isset($_GET['page']) && $_GET['page'] === 'mw-theme-settings') {
wp_enqueue_media();
wp_enqueue_script('jquery');
}
}
add_action('admin_enqueue_scripts', 'mw_enqueue_media_scripts');
/**
* Register Admin Menu Page
*/
function mw_register_settings_page() {
add_menu_page(
__('إعدادات القالب', 'malik_web'),
__('إعدادات القالب', 'malik_web'),
'manage_options',
'mw-theme-settings',
'mw_render_settings_page',
get_theme_file_uri('/assets/uploads/theme-icons/mw-icon.png'),
60
);
}
add_action('admin_menu', 'mw_register_settings_page');
/**
* Register Settings
*/
function mw_register_settings() {
register_setting('mw_theme_options', 'mw_theme_options', 'mw_sanitize_options');
// Logo Section
add_settings_section('logo_section', __('لوجو الموقع', 'malik_web'), 'mw_logo_section_callback', 'mw-theme-settings-logo');
add_settings_field('site_logo', __('لوجو الموقع المرئي', 'malik_web'), 'mw_site_logo_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_name', __('اسم الموقع', 'malik_web'), 'mw_site_name_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_name_font_size', __('حجم خط اسم الموقع', 'malik_web'), 'mw_site_name_font_size_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_des', __('كنية الموقع', 'malik_web'), 'mw_site_des_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_des_font_size', __('حجم خط كنية الموقع', 'malik_web'), 'mw_site_des_font_size_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_url', __('رابط الموقع', 'malik_web'), 'mw_site_url_callback', 'mw-theme-settings-logo', 'logo_section');
add_settings_field('site_url_font_size', __('حجم خط رابط الموقع', 'malik_web'), 'mw_site_url_font_size_callback', 'mw-theme-settings-logo', 'logo_section');
// Text Boxes Section
add_settings_section('text_boxs_section', __('الحقول النصية', 'malik_web'), null, 'mw-theme-settings-text_boxs');
add_settings_field('site_topdes_toggle', __('تفعيل وصف الموقع أسفل الهيدر', 'malik_web'), 'mw_site_topdes_toggle_callback', 'mw-theme-settings-text_boxs', 'text_boxs_section');
add_settings_field('site_topdes', __('وصف الموقع أسفل الهيدر', 'malik_web'), 'mw_site_topdes_callback', 'mw-theme-settings-text_boxs', 'text_boxs_section');
add_settings_field('site_botdes_toggle', __('تفعيل وصف الموقع أعلى الفوتر', 'malik_web'), 'mw_site_botdes_toggle_callback', 'mw-theme-settings-text_boxs', 'text_boxs_section');
add_settings_field('site_botdes', __('وصف الموقع أعلى الفوتر', 'malik_web'), 'mw_site_botdes_callback', 'mw-theme-settings-text_boxs', 'text_boxs_section');
// Colors Section
add_settings_section('colors_section', __('ألوان القالب', 'malik_web'), null, 'mw-theme-settings-colors');
add_settings_field('primary_color', __('اللون الأساسي', 'malik_web'), 'mw_primary_color_callback', 'mw-theme-settings-colors', 'colors_section');
add_settings_field('secondary_color', __('اللون المساعد', 'malik_web'), 'mw_secondary_color_callback', 'mw-theme-settings-colors', 'colors_section');
add_settings_field('site_body_color', __('لون خلفية الموقع', 'malik_web'), 'mw_site_body_color_callback', 'mw-theme-settings-colors', 'colors_section');
add_settings_field('items_bg_color', __('لون خلفية العناصر', 'malik_web'), 'mw_items_bg_color_callback', 'mw-theme-settings-colors', 'colors_section');
// Social Media Section
add_settings_section('social_media_section', __('روابط السوشيال ميديا', 'malik_web'), null, 'mw-theme-settings-social_media');
$social_media = ['facebook', 'twitter', 'googlenews', 'youtube', 'telegram'];
foreach ($social_media as $platform) {
add_settings_field("{$platform}_visibility", __('تفعيل ' . ucfirst($platform), 'malik_web'), "mw_{$platform}_visibility_callback", 'mw-theme-settings-social_media', 'social_media_section');
add_settings_field("{$platform}_url", __('رابط ' . ucfirst($platform), 'malik_web'), "mw_{$platform}_url_callback", 'mw-theme-settings-social_media', 'social_media_section');
}
// Typography Section
add_settings_section('typography_section', __('إعدادات الخطوط', 'malik_web'), 'mw_typography_section_callback', 'mw-theme-settings-typography');
add_settings_field('font_primary', __('الخط الأساسي للقالب', 'malik_web'), 'mw_font_primary_callback', 'mw-theme-settings-typography', 'typography_section');
// Image Settings Section
add_settings_section('image_settings_section', __('إعدادات الصور', 'malik_web'), null, 'mw-theme-settings-image_settings');
add_settings_field('image_compression_toggle', __('تفعيل ضغط الصور', 'malik_web'), 'mw_image_compression_toggle_callback', 'mw-theme-settings-image_settings', 'image_settings_section');
// Sections Names Section
add_settings_section('sections_names_section', __('تسمية الأقسام', 'malik_web'), null, 'mw-theme-settings-sections_names');
$sections = [
'section_1' => 'قسم جدول مباريات اليوم',
'section_2' => 'قسم جدول مباريات الغد',
'section_3' => 'قسم جدول مباريات الأمس',
'section_4' => 'قسم آخر المقالات',
'section_5' => 'قسم ترتيب الدوريات',
'section_6' => 'قسم نبذة عن موقعك'
];
foreach ($sections as $key => $label) {
add_settings_field($key, $label, "mw_{$key}_callback", 'mw-theme-settings-sections_names', 'sections_names_section');
}
// Homepage Ads Section
add_settings_section('home_ads_section', __('إعلانات الصفحة الرئيسية', 'malik_web'), 'mw_home_ads_section_callback', 'mw-theme-settings-home_ads');
$ad_sections = [
'below_header' => 'أسفل الهيدر',
'matches' => 'أسفل جدول المباريات',
'news_posts' => 'وسط المقالات المخصصة',
'posts' => 'أسفل آخر المقالات',
'footer' => 'أعلى الفوتر'
];
foreach ($ad_sections as $key => $label) {
add_settings_field("home_ads_{$key}_enable", __('تفعيل إعلان ' . $label, 'malik_web'), "mw_home_ads_{$key}_enable_callback", 'mw-theme-settings-home_ads', 'home_ads_section');
add_settings_field("home_ads_{$key}_code", __('كود إعلان ' . $label, 'malik_web'), "mw_home_ads_{$key}_code_callback", 'mw-theme-settings-home_ads', 'home_ads_section');
}
// Post Ads Section
add_settings_section('post_ads_section', __('إعلانات المقالة', 'malik_web'), 'mw_post_ads_section_callback', 'mw-theme-settings-post_ads');
add_settings_field('post_ads_toggle', __('تفعيل إعلانات المقالة', 'malik_web'), 'mw_post_ads_toggle_callback', 'mw-theme-settings-post_ads', 'post_ads_section');
$ads = [
'ad_above_post' => 'أول المقال',
'ad_under_post' => 'أخر المقال',
'ad_under_post_h2_1' => 'h2 الأول',
'ad_under_post_h2_2' => 'h2 الثاني',
'ad_under_post_h2_3' => 'h2 الثالث',
'ad_under_post_h2_4' => 'h2 الرابع',
'ad_under_post_h3_1' => 'h3 الأول',
'ad_under_post_h3_2' => 'h3 الثاني',
'ad_under_post_h3_3' => 'h3 الثالث',
'ad_under_post_h3_4' => 'h3 الرابع',
'ad_under_post_p1' => 'p الأولى',
'ad_under_post_p2' => 'p الثانية',
'ad_under_post_p3' => 'p الثالثة',
'ad_under_post_p4' => 'p الرابعة',
'sticky_ad_post' => 'عائم'
];
foreach ($ads as $key => $label) {
add_settings_field("{$key}_enable", __('تفعيل إعلان ' . $label, 'malik_web'), "mw_{$key}_enable_callback", 'mw-theme-settings-post_ads', 'post_ads_section');
add_settings_field("{$key}_code", __('كود إعلان ' . $label, 'malik_web'), "mw_{$key}_code_callback", 'mw-theme-settings-post_ads', 'post_ads_section');
}
// League Links Section
add_settings_section('league_links_section', __('قسم ترتيب الدوريات', 'malik_web'), 'mw_league_links_section_callback', 'mw-theme-settings-league_links');
add_settings_field('leagues_list_toggle', __('تفعيل قسم ترتيب الدوريات', 'malik_web'), 'mw_leagues_list_toggle_callback', 'mw-theme-settings-league_links', 'league_links_section');
$leagues = [
'league_1' => 'الإنجليزي',
'league_2' => 'الإسباني',
'league_3' => 'الإيطالي',
'league_4' => 'الفرنسي',
'league_5' => 'الألماني',
'league_6' => 'المصري',
'league_7' => 'السعودي',
'league_8' => 'دوري أبطال أوروبا',
'league_9' => 'دوري أبطال أفريقيا',
'league_10' => 'دوري أبطال آسيا',
'league_11' => 'الأوروبي',
'league_12' => 'المغربي',
'league_13' => 'الجزائري',
'league_14' => 'التونسي',
'league_15' => 'التركي'
];
foreach ($leagues as $key => $label) {
add_settings_field("{$key}_url", __('رابط ترتيب الدوري ' . $label, 'malik_web'), "mw_{$key}_url_callback", 'mw-theme-settings-league_links', 'league_links_section');
}
// Timezone Section
add_settings_section('timezone_section', __('قسم جدول المباريات', 'malik_web'), 'mw_timezone_section_callback', 'mw-theme-settings-timezone');
add_settings_field('matches_timezone', __('توقيت الجدول', 'malik_web'), 'mw_matches_timezone_callback', 'mw-theme-settings-timezone', 'timezone_section');
add_settings_field('time_format', __('تنسيق الوقت', 'malik_web'), 'mw_time_format_callback', 'mw-theme-settings-timezone', 'timezone_section');
add_settings_field('open_match_new_tab', __('فتح صفحة المباراة في نافذة جديدة', 'malik_web'), 'mw_open_match_new_tab_callback', 'mw-theme-settings-timezone', 'timezone_section');
add_settings_field('change_days', __('تأخير نقل المباريات', 'malik_web'), 'mw_change_days_callback', 'mw-theme-settings-timezone', 'timezone_section');
// Custom JS Section
add_settings_section('custom_js_section', __('أكواد JavaScript', 'malik_web'), null, 'mw-theme-settings-custom_js');
add_settings_field('custom_js_header_enable', __('تفعيل كود JavaScript في <head>', 'malik_web'), 'mw_custom_js_header_enable_callback', 'mw-theme-settings-custom_js', 'custom_js_section');
add_settings_field('custom_js_header', __('كود JavaScript داخل <head>', 'malik_web'), 'mw_custom_js_header_callback', 'mw-theme-settings-custom_js', 'custom_js_section');
add_settings_field('custom_js_footer_enable', __('تفعيل كود JavaScript قبل </body>', 'malik_web'), 'mw_custom_js_footer_enable_callback', 'mw-theme-settings-custom_js', 'custom_js_section');
add_settings_field('custom_js_footer', __('كود JavaScript قبل </body>', 'malik_web'), 'mw_custom_js_footer_callback', 'mw-theme-settings-custom_js', 'custom_js_section');
// Custom CSS Section
add_settings_section('custom_css_section', __('أكواد CSS مخصصة', 'malik_web'), 'mw_custom_css_section_callback', 'mw-theme-settings-custom_css');
add_settings_field('custom_css_enable', __('تفعيل أكواد CSS مخصصة', 'malik_web'), 'mw_custom_css_enable_callback', 'mw-theme-settings-custom_css', 'custom_css_section');
add_settings_field('custom_css', __('أكواد CSS مخصصة', 'malik_web'), 'mw_custom_css_callback', 'mw-theme-settings-custom_css', 'custom_css_section');
// Google Analytics Section
add_settings_section('google_analytics_section', __('إحصائيات جوجل', 'malik_web'), 'mw_google_analytics_section_callback', 'mw-theme-settings-google_analytics');
add_settings_field('google_analytics_enable', __('تفعيل كود إحصائيات جوجل', 'malik_web'), 'mw_google_analytics_enable_callback', 'mw-theme-settings-google_analytics', 'google_analytics_section');
add_settings_field('google_analytics_code', __('كود إحصائيات جوجل', 'malik_web'), 'mw_google_analytics_code_callback', 'mw-theme-settings-google_analytics', 'google_analytics_section');
// Backup and Reset Section
add_settings_section('backup_reset_section', __('النسخ الاحتياطي وإعادة الضبط', 'malik_web'), 'mw_backup_reset_section_callback', 'mw-theme-settings-backup_reset');
add_settings_field('reset_settings', __('إعادة ضبط إعدادات القالب', 'malik_web'), 'mw_reset_settings_callback', 'mw-theme-settings-backup_reset', 'backup_reset_section');
add_settings_field('export_settings', __('تصدير الإعدادات', 'malik_web'), 'mw_export_settings_callback', 'mw-theme-settings-backup_reset', 'backup_reset_section');
add_settings_field('import_settings', __('استيراد الإعدادات', 'malik_web'), 'mw_import_settings_callback', 'mw-theme-settings-backup_reset', 'backup_reset_section');
// Match Articles Section
add_settings_section('match_articles_section', __('مباريات ذات صلة', 'malik_web'), 'mw_match_articles_section_callback', 'mw-theme-settings-match_articles');
add_settings_field('related_posts_background', __('صورة خلفية المقالات المقترحة', 'malik_web'), 'mw_related_posts_background_callback', 'mw-theme-settings-match_articles', 'match_articles_section');
add_settings_field('related_posts_toggle', __('إظهار/إخفاء مباريات ذات الصلة', 'malik_web'), 'mw_related_posts_toggle_callback', 'mw-theme-settings-match_articles', 'match_articles_section');
}
add_action('admin_init', 'mw_register_settings');
/**
* Sanitization Callback
*/
function mw_sanitize_options($input) {
$output = [];
$output['site_logo'] = absint($input['site_logo'] ?? 0); // Store attachment ID
$output['site_name'] = sanitize_text_field($input['site_name'] ?? 'قالب سيجما سبورت');
$output['site_name_font_size'] = absint($input['site_name_font_size'] ?? 20);
$output['site_des'] = sanitize_text_field($input['site_des'] ?? 'موقع رياضي متكامل');
$output['site_des_font_size'] = absint($input['site_des_font_size'] ?? 20);
$output['site_url'] = sanitize_text_field($input['site_url'] ?? 'sigma-sport.com');
$output['site_url_font_size'] = absint($input['site_url_font_size'] ?? 20);
$output['site_topdes_toggle'] = isset($input['site_topdes_toggle']) ? 1 : 0;
$output['site_topdes'] = sanitize_text_field($input['site_topdes'] ?? 'ضع هنا وصف مختصر عن موقعك');
$output['site_botdes_toggle'] = isset($input['site_botdes_toggle']) ? 1 : 0;
$output['site_botdes'] = wp_kses_post($input['site_botdes'] ?? 'ضع هنا وصف مفصل عن موقعك');
$output['primary_color'] = sanitize_hex_color($input['primary_color'] ?? '#24276e');
$output['secondary_color'] = sanitize_hex_color($input['secondary_color'] ?? '#06b1c3');
$output['site_body_color'] = sanitize_hex_color($input['site_body_color'] ?? '#e4eeff');
$output['items_bg_color'] = sanitize_hex_color($input['items_bg_color'] ?? '#e4eeff');
foreach (['facebook', 'twitter', 'googlenews', 'youtube', 'telegram'] as $platform) {
$output["{$platform}_visibility"] = isset($input["{$platform}_visibility"]) ? 1 : 0;
$output["{$platform}_url"] = esc_url_raw($input["{$platform}_url"] ?? '#');
}
$output['font_primary'] = sanitize_text_field($input['font_primary'] ?? 'NeoSansArabic');
$sections = ['section_1', 'section_2', 'section_3', 'section_4', 'section_5', 'section_6'];
foreach ($sections as $section) {
$output[$section] = sanitize_text_field($input[$section] ?? '');
}
foreach (['below_header', 'matches', 'news_posts', 'posts', 'footer'] as $ad) {
$output["home_ads_{$ad}_enable"] = isset($input["home_ads_{$ad}_enable"]) ? 1 : 0;
$output["home_ads_{$ad}_code"] = $input["home_ads_{$ad}_code"] ?? 'مساحة إعلانية';
}
$output['post_ads_toggle'] = isset($input['post_ads_toggle']) ? 1 : 0;
foreach (['ad_above_post', 'ad_under_post', 'ad_under_post_h2_1', 'ad_under_post_h2_2', 'ad_under_post_h2_3', 'ad_under_post_h2_4', 'ad_under_post_h3_1', 'ad_under_post_h3_2', 'ad_under_post_h3_3', 'ad_under_post_h3_4', 'ad_under_post_p1', 'ad_under_post_p2', 'ad_under_post_p3', 'ad_under_post_p4', 'sticky_ad_post'] as $ad) {
$output["{$ad}_enable"] = isset($input["{$ad}_enable"]) ? 1 : 0;
$output["{$ad}_code"] = $input["{$ad}_code"] ?? 'مساحة إعلانية';
}
$output['leagues_list_toggle'] = isset($input['leagues_list_toggle']) ? 1 : 0;
foreach (['league_1', 'league_2', 'league_3', 'league_4', 'league_5', 'league_6', 'league_7', 'league_8', 'league_9', 'league_10', 'league_11', 'league_12', 'league_13', 'league_14', 'league_15'] as $league) {
$output["{$league}_url"] = esc_url_raw($input["{$league}_url"] ?? '#');
}
// Timezone
$valid_timezones = array_keys([
'Africa/Cairo' => 'القاهرة',
'Asia/Riyadh' => 'الرياض',
'Africa/Casablanca' => 'الدار البيضاء',
'Asia/Baghdad' => 'بغداد',
'Asia/Qatar' => 'الدوحة',
'Asia/Kuwait' => 'الكويت',
'Africa/Tripoli' => 'طرابلس',
'Asia/Beirut' => 'بيروت',
'Asia/Amman' => 'عمان',
'Asia/Dubai' => 'دبي',
'Asia/Muscat' => 'مسقط',
'Europe/Istanbul' => 'إسطنبول',
'UTC' => 'غرينتش',
'Europe/London' => 'لندن',
'Europe/Paris' => 'باريس',
'Europe/Berlin' => 'برلين',
'Europe/Madrid' => 'مدريد',
'Europe/Rome' => 'روما',
'Europe/Amsterdam' => 'أمستردام',
'Europe/Moscow' => 'موسكو',
]);
$output['matches_timezone'] = in_array($input['matches_timezone'] ?? 'Africa/Cairo', $valid_timezones) ? $input['matches_timezone'] : 'Africa/Cairo';
$output['time_format'] = in_array($input['time_format'] ?? '24', ['12', '24']) ? $input['time_format'] : '24';
$output['open_match_new_tab'] = isset($input['open_match_new_tab']) ? 1 : 0;
$output['change_days'] = absint($input['change_days'] ?? 0);
// Custom JS
$output['custom_js_header_enable'] = isset($input['custom_js_header_enable']) ? 1 : 0;
$output['custom_js_header'] = $input['custom_js_header'] ?? '';
$output['custom_js_footer_enable'] = isset($input['custom_js_footer_enable']) ? 1 : 0;
$output['custom_js_footer'] = $input['custom_js_footer'] ?? '';
// Custom CSS
$output['custom_css_enable'] = isset($input['custom_css_enable']) ? 1 : 0;
$output['custom_css'] = wp_kses($input['custom_css'] ?? '', ['style' => []]);
// Google Analytics
$output['google_analytics_enable'] = isset($input['google_analytics_enable']) ? 1 : 0;
$output['google_analytics_code'] = $input['google_analytics_code'] ?? '';
$output['related_posts_background'] = esc_url_raw($input['related_posts_background'] ?? '');
$output['related_posts_toggle'] = isset($input['related_posts_toggle']) ? 1 : 0;
$output['image_compression_toggle'] = isset($input['image_compression_toggle']) ? 1 : 0;
// Handle import settings
if (isset($input['import_settings']) && !empty($input['import_settings'])) {
$import_data = json_decode(stripslashes($input['import_settings']), true);
if (is_array($import_data)) {
foreach ($import_data as $key => $value) {
if (array_key_exists($key, $output)) {
if (in_array($key, ['site_name','site_des', 'site_url', 'site_topdes', 'font_primary', 'matches_timezone', 'time_format']) || strpos($key, 'section_') === 0) {
$output[$key] = sanitize_text_field($value);
} elseif (in_array($key, ['site_name_font_size', 'site_des_font_size', 'site_url_font_size', 'site_logo', 'change_days'])) {
$output[$key] = absint($value);
} elseif (in_array($key, ['site_topdes_toggle', 'site_botdes_toggle', 'leagues_list_toggle', 'custom_js_header_enable', 'custom_js_footer_enable', 'custom_css_enable', 'related_posts_toggle']) || strpos($key, '_visibility') !== false || (strpos($key, 'home_ads_') !== false && strpos($key, '_enable') !== false)) {
$output[$key] = $value ? 1 : 0;
} elseif (in_array($key, ['primary_color', 'secondary_color', 'site_body_color', 'items_bg_color'])) {
$output[$key] = sanitize_hex_color($value);
} elseif (strpos($key, '_url') !== false || $key === 'related_posts_background') {
$output[$key] = esc_url_raw($value);
} elseif (strpos($key, '_code') !== false || in_array($key, ['site_botdes', 'custom_css'])) {
$output[$key] = wp_kses_post($value);
} elseif (in_array($key, ['custom_js_header', 'custom_js_footer', 'google_analytics_code'])) {
$output[$key] = $value; // Preserve raw JavaScript and Google Analytics code
}
}
}
}
}
return $output;
}
/**
* Section Callbacks
*/
function mw_logo_section_callback() {
echo '<p class="section-description">' . __('تخصيص هوية الموقع والشعار', 'malik_web') . '</p>';
}
function mw_typography_section_callback() {
echo '<p class="section-description">' . __('تخصيص نوع الخطوط المستخدمة في القالب', 'malik_web') . '</p>';
}
function mw_home_ads_section_callback() {
echo '<p class="section-description">' . __('إدارة الإعلانات في الصفحة الرئيسية', 'malik_web') . '</p>';
}
function mw_post_ads_section_callback() {
echo '<p class="section-description">' . __('إدارة الإعلانات في المقالة', 'malik_web') . '</p>';
}
function mw_league_links_section_callback() {
echo '<p class="section-description">' . __('إعدادات قسم ترتيب الدوريات', 'malik_web') . '</p>';
}
function mw_timezone_section_callback() {
echo '<p class="section-description">' . __('إعدادات قسم جدول المباريات', 'malik_web') . '</p>';
}
function mw_backup_reset_section_callback() {
echo '<p class="section-description">' . __('إدارة النسخ الاحتياطي وإعادة ضبط إعدادات القالب', 'malik_web') . '</p>';
}
function mw_custom_css_section_callback() {
echo '<p class="section-description">' . __('إضافة أكواد CSS مخصصة لتخصيص أنماط القالب', 'malik_web') . '</p>';
}
function mw_google_analytics_section_callback() {
echo '<p class="section-description">' . __('إدراج كود إحصائيات جوجل لتتبع أداء الموقع', 'malik_web') . '</p>';
}
function mw_match_articles_section_callback() {
echo '<p class="section-description">' . __('إعدادات مباريات ذات صلة', 'malik_web') . '</p>';
}
/**
* Field Callbacks
*/
function mw_site_logo_callback() {
$options = get_option('mw_theme_options');
$logo_id = absint($options['site_logo'] ?? 0);
$logo_url = $logo_id ? wp_get_attachment_url($logo_id) : '';
?>
<div class="input-group">
<input type="hidden" name="mw_theme_options[site_logo]" id="site_logo_id" value="<?php echo esc_attr($logo_id); ?>" />
<div id="site_logo_preview" style="margin-bottom: 10px; <?php echo $logo_url ? '' : 'display: none;'; ?>">
<?php if ($logo_url) : ?>
<img src="<?php echo esc_url($logo_url); ?>" style="max-width: 200px; max-height: 100px;" alt="<?php esc_attr_e('معاينة اللوجو', 'malik_web'); ?>" />
<?php endif; ?>
</div>
<button type="button" class="button upload-logo-button"><?php esc_html_e('رفع لوجو', 'malik_web'); ?></button>
<button type="button" class="button remove-logo-button" style="display: <?php echo $logo_id ? 'inline-block' : 'none'; ?>;"><?php esc_html_e('إزالة اللوجو', 'malik_web'); ?></button>
</div>
<script>
jQuery(document).ready(function($) {
$('.upload-logo-button').on('click', function(e) {
e.preventDefault();
var frame = wp.media({
title: '<?php echo esc_js(__('اختر لوجو الموقع', 'malik_web')); ?>',
button: { text: '<?php echo esc_js(__('استخدام الصورة', 'malik_web')); ?>' },
multiple: false,
library: { type: 'image' }
});
frame.on('select', function() {
var attachment = frame.state().get('selection').first().toJSON();
$('#site_logo_id').val(attachment.id);
$('#site_logo_preview').html('<img src="' + attachment.url + '" style="max-width: 200px; max-height: 100px;" alt="<?php echo esc_js(__('Logo Preview', 'malik_web')); ?>" />').show();
$('.remove-logo-button').show();
});
frame.open();
});
$('.remove-logo-button').on('click', function(e) {
e.preventDefault();
$('#site_logo_id').val('');
$('#site_logo_preview').empty().hide();
$(this).hide();
});
});
</script>
<?php
}
function mw_site_name_callback() {
$options = get_option('mw_theme_options');
echo '<input type="text" name="mw_theme_options[site_name]" value="' . esc_attr($options['site_name'] ?? 'قالب سيجما سبورت') . '" class="regular-text" />';
}
function mw_site_name_font_size_callback() {
$options = get_option('mw_theme_options');
$value = esc_attr($options['site_name_font_size'] ?? 20);
echo '<div class="input-group">';
echo '<input type="range" name="mw_theme_options[site_name_font_size]" value="' . $value . '" min="10" max="100" step="1" class="range-input" oninput="this.nextElementSibling.value=this.value" />';
echo '<input type="number" value="' . $value . '" class="number-input" readonly />';
echo '<span class="unit">px</span>';
echo '</div>';
}
function mw_site_des_callback() {
$options = get_option('mw_theme_options');
echo '<input type="text" name="mw_theme_options[site_des]" value="' . esc_attr($options['site_des'] ?? 'موقع رياضي متكامل') . '" class="regular-text" />';
}
function mw_site_des_font_size_callback() {
$options = get_option('mw_theme_options');
$value = esc_attr($options['site_des_font_size'] ?? 20);
echo '<div class="input-group">';
echo '<input type="range" name="mw_theme_options[site_des_font_size]" value="' . $value . '" min="10" max="100" step="1" class="range-input" oninput="this.nextElementSibling.value=this.value" />';
echo '<input type="number" value="' . $value . '" class="number-input" readonly />';
echo '<span class="unit">px</span>';
echo '</div>';
}
function mw_site_url_callback() {
$options = get_option('mw_theme_options');
echo '<input type="text" name="mw_theme_options[site_url]" value="' . esc_attr($options['site_url'] ?? 'sigma-sport.com') . '" class="regular-text" />';
}
function mw_site_url_font_size_callback() {
$options = get_option('mw_theme_options');
$value = esc_attr($options['site_url_font_size'] ?? 20);
echo '<div class="input-group">';
echo '<input type="range" name="mw_theme_options[site_url_font_size]" value="' . $value . '" min="10" max="50" step="1" class="range-input" oninput="this.nextElementSibling.value=this.value" />';
echo '<input type="number" value="' . $value . '" class="number-input" readonly />';
echo '<span class="unit">px</span>';
echo '</div>';
}
function mw_site_topdes_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[site_topdes_toggle]" value="1" ' . checked(1, $options['site_topdes_toggle'] ?? 1, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_site_topdes_callback() {
$options = get_option('mw_theme_options');
echo '<input type="text" name="mw_theme_options[site_topdes]" value="' . esc_attr($options['site_topdes'] ?? 'ضع هنا وصف مختصر عن موقعك') . '" class="regular-text" />';
}
function mw_site_botdes_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[site_botdes_toggle]" value="1" ' . checked(1, $options['site_botdes_toggle'] ?? 1, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_site_botdes_callback() {
$options = get_option('mw_theme_options');
echo '<textarea name="mw_theme_options[site_botdes]" class="large-text" rows="5">' . esc_textarea($options['site_botdes'] ?? 'ضع هنا وصف مفصل عن موقعك') . '</textarea>';
}
function mw_primary_color_callback() {
$options = get_option('mw_theme_options');
$default = '#24276e';
$value = esc_attr($options['primary_color'] ?? $default);
echo '<div class="input-group">';
echo '<input type="color" name="mw_theme_options[primary_color]" id="mw_primary_color" value="' . $value . '" class="color-input" />';
echo '<button type="button" onclick="document.getElementById(\'mw_primary_color\').value=\'' . $default . '\'" class="reset-button">Default</button>';
echo '</div>';
}
function mw_secondary_color_callback() {
$options = get_option('mw_theme_options');
$default = '#06b1c3';
$value = esc_attr($options['secondary_color'] ?? $default);
echo '<div class="input-group">';
echo '<input type="color" name="mw_theme_options[secondary_color]" id="mw_secondary_color" value="' . $value . '" class="color-input" />';
echo '<button type="button" onclick="document.getElementById(\'mw_secondary_color\').value=\'' . $default . '\'" class="reset-button">Default</button>';
echo '</div>';
}
function mw_site_body_color_callback() {
$options = get_option('mw_theme_options');
$default = '#e4eeff';
$value = esc_attr($options['site_body_color'] ?? $default);
echo '<div class="input-group">';
echo '<input type="color" name="mw_theme_options[site_body_color]" id="mw_site_body_color" value="' . $value . '" class="color-input" />';
echo '<button type="button" onclick="document.getElementById(\'mw_site_body_color\').value=\'' . $default . '\'" class="reset-button">Default</button>';
echo '</div>';
}
function mw_items_bg_color_callback() {
$options = get_option('mw_theme_options');
$default = '#e4eeff';
$value = esc_attr($options['items_bg_color'] ?? $default);
echo '<div class="input-group">';
echo '<input type="color" name="mw_theme_options[items_bg_color]" id="mw_items_bg_color" value="' . $value . '" class="color-input" />';
echo '<button type="button" onclick="document.getElementById(\'mw_items_bg_color\').value=\'' . $default . '\'" class="reset-button">Default</button>';
echo '</div>';
}
// Social Media Visibility and URL Callbacks (generated dynamically)
foreach (['facebook', 'twitter', 'googlenews', 'youtube', 'telegram'] as $platform) {
eval("function mw_{$platform}_visibility_callback() {
\$options = get_option('mw_theme_options');
echo '<label class=\"toggle-switch\">';
echo '<input type=\"checkbox\" name=\"mw_theme_options[{$platform}_visibility]\" value=\"1\" ' . checked(1, \$options['{$platform}_visibility'] ?? 1, false) . '>';
echo '<span class=\"slider\"></span>';
echo '</label>';
}");
eval("function mw_{$platform}_url_callback() {
\$options = get_option('mw_theme_options');
echo '<input type=\"text\" name=\"mw_theme_options[{$platform}_url]\" value=\"' . esc_attr(\$options['{$platform}_url'] ?? '#') . '\" class=\"regular-text\" />';
}");
}
function mw_font_primary_callback() {
$options = get_option('mw_theme_options');
$fonts = [
'NeoSansArabic, sans-serif' => 'NeoSansArabic',
'Somar-Regular, sans-serif' => 'Somar',
'Arial, sans-serif' => 'Arial',
'Tahoma, sans-serif' => 'Tahoma',
'Cairo, sans-serif' => 'Cairo',
'Tajawal, sans-serif' => 'Tajawal',
];
echo '<select name="mw_theme_options[font_primary]" class="select-input">';
foreach ($fonts as $value => $label) {
echo '<option value="' . esc_attr($value) . '" ' . selected($options['font_primary'] ?? 'NeoSansArabic', $value, false) . '>' . esc_html($label) . '</option>';
}
echo '</select>';
}
function mw_image_compression_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[image_compression_toggle]" value="1" ' . checked(1, $options['image_compression_toggle'] ?? 0, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
echo '<p class="field-description" style="margin-top:10px">' . __('يفضل استخدام صور بصيغة jpg للحصول علي أفضل ضغط وسرعة.', 'malik_web') . '</p>';
}
function mw_matches_timezone_callback() {
$options = get_option('mw_theme_options');
$timezones = [
'Africa/Cairo' => 'القاهرة',
'Asia/Riyadh' => 'الرياض',
'Africa/Casablanca' => 'الدار البيضاء',
'Asia/Baghdad' => 'بغداد',
'Asia/Qatar' => 'الدوحة',
'Asia/Kuwait' => 'الكويت',
'Africa/Tripoli' => 'طرابلس',
'Asia/Beirut' => 'بيروت',
'Asia/Amman' => 'عمان',
'Asia/Dubai' => 'دبي',
'Asia/Muscat' => 'مسقط',
'Europe/Istanbul' => 'إسطنبول',
'UTC' => 'غرينتش',
'Europe/London' => 'لندن',
'Europe/Paris' => 'باريس',
'Europe/Berlin' => 'برلين',
'Europe/Madrid' => 'مدريد',
'Europe/Rome' => 'روما',
'Europe/Amsterdam' => 'أمستردام',
'Europe/Moscow' => 'موسكو',
];
echo '<select name="mw_theme_options[matches_timezone]" class="select-input">';
foreach ($timezones as $value => $label) {
echo '<option value="' . esc_attr($value) . '" ' . selected($options['matches_timezone'] ?? 'Africa/Cairo', $value, false) . '>' . esc_html($label) . '</option>';
}
echo '</select>';
}
function mw_time_format_callback() {
$options = get_option('mw_theme_options');
$time_format = esc_attr($options['time_format'] ?? '24');
echo '<div class="controls">';
echo '<div class="formats-control">';
echo '<div class="time-format">';
echo '<input class="of-input of-radio" type="radio" name="mw_theme_options[time_format]" id="mw_time_format_12" value="12" ' . checked('12', $time_format, false) . '>';
echo '<label for="mw_time_format_12">12 ساعة</label>';
echo '</div>';
echo '<div class="time-format">';
echo '<input class="of-input of-radio" type="radio" name="mw_theme_options[time_format]" id="mw_time_format_24" value="24" ' . checked('24', $time_format, false) . '>';
echo '<label for="mw_time_format_24">24 ساعة</label>';
echo '</div>';
echo '</div>';
echo '<div class="field-description"></div>';
echo '</div>';
}
// إضافة حقل تأخير نقل المباريات (مع إصلاح checked للـ radio)
function mw_change_days_callback() {
$options = get_option('mw_theme_options');
$change_days = absint($options['change_days'] ?? 0);
$delays = [
0 => 'بدون تأجيل',
30 => 'تأجيل 30د',
45 => 'تأجيل 45د',
60 => 'تأجيل 60د',
90 => 'تأجيل 90د',
120 => 'تأجيل 120د'
];
echo '<div class="changedays-field changedays-field-radio">';
echo '<div class="changedays-fieldset">';
echo '<ul class="changedays--horizontal-list">';
foreach ($delays as $value => $label) {
echo '<li><label><input type="radio" name="mw_theme_options[change_days]" value="' . esc_attr($value) . '" ' . checked($change_days, $value, false) . '><span class="changedays--text">' . esc_html($label) . '</span></label></li>';
}
echo '</ul></div><div class="clear"></div></div>';
echo '<p class="field-description" style="margin-top:10px">' . __('عند التفعيل، سيتم تأجيل ترحيل المباريات بين الأيام علي حسب أختيارك.', 'malik_web') . '</p>';
}
function mw_open_match_new_tab_callback() {
$options = get_option('mw_theme_options');
$checked = checked(1, $options['open_match_new_tab'] ?? 0, false);
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[open_match_new_tab]" value="1" ' . $checked . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
// Sections Names Callbacks (generated dynamically)
foreach (['section_1', 'section_2', 'section_3', 'section_4', 'section_5', 'section_6'] as $section) {
eval("function mw_{$section}_callback() {
\$options = get_option('mw_theme_options');
\$defaults = [
'section_1' => 'جدول مباريات اليوم',
'section_2' => 'جدول مباريات الغد',
'section_3' => 'جدول مباريات الأمس',
'section_4' => 'آخر المقالات',
'section_5' => 'ترتيب الدوريات',
'section_6' => 'نبذة عن موقعك',
];
echo '<input type=\"text\" name=\"mw_theme_options[{$section}]\" value=\"' . esc_attr(\$options['{$section}'] ?? \$defaults['{$section}']) . '\" class=\"regular-text\" />';
}");
}
// Homepage Ads Callbacks (generated dynamically)
foreach (['below_header', 'matches', 'news_posts', 'posts', 'footer'] as $ad) {
eval("function mw_home_ads_{$ad}_enable_callback() {
\$options = get_option('mw_theme_options');
echo '<label class=\"toggle-switch\">';
echo '<input type=\"checkbox\" name=\"mw_theme_options[home_ads_{$ad}_enable]\" value=\"1\" ' . checked(1, \$options['home_ads_{$ad}_enable'] ?? 1, false) . '>';
echo '<span class=\"slider\"></span>';
echo '</label>';
}");
eval("function mw_home_ads_{$ad}_code_callback() {
\$options = get_option('mw_theme_options');
echo '<textarea name=\"mw_theme_options[home_ads_{$ad}_code]\" class=\"large-text\" rows=\"5\">' . esc_textarea(\$options['home_ads_{$ad}_code'] ?? '') . '</textarea>';
}");
}
function mw_post_ads_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[post_ads_toggle]" value="1" ' . checked(1, $options['post_ads_toggle'] ?? 1, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
// Post Ads Callbacks (generated dynamically)
foreach (['ad_above_post', 'ad_under_post', 'ad_under_post_h2_1', 'ad_under_post_h2_2', 'ad_under_post_h2_3', 'ad_under_post_h2_4', 'ad_under_post_h3_1', 'ad_under_post_h3_2', 'ad_under_post_h3_3', 'ad_under_post_h3_4', 'ad_under_post_p1', 'ad_under_post_p2', 'ad_under_post_p3', 'ad_under_post_p4', 'sticky_ad_post'] as $ad) {
eval("function mw_{$ad}_enable_callback() {
\$options = get_option('mw_theme_options');
echo '<label class=\"toggle-switch\">';
echo '<input type=\"checkbox\" name=\"mw_theme_options[{$ad}_enable]\" value=\"1\" ' . checked(1, \$options['{$ad}_enable'] ?? 1, false) . '>';
echo '<span class=\"slider\"></span>';
echo '</label>';
}");
eval("function mw_{$ad}_code_callback() {
\$options = get_option('mw_theme_options');
echo '<textarea name=\"mw_theme_options[{$ad}_code]\" class=\"large-text\" rows=\"5\">' . esc_textarea(\$options['{$ad}_code'] ?? 'مساحة إعلانية') . '</textarea>';
}");
}
function mw_leagues_list_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[leagues_list_toggle]" value="1" ' . checked(1, $options['leagues_list_toggle'] ?? 1, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
// League Links URL Callbacks (generated dynamically)
foreach (['league_1', 'league_2', 'league_3', 'league_4', 'league_5', 'league_6', 'league_7', 'league_8', 'league_9', 'league_10', 'league_11', 'league_12', 'league_13', 'league_14', 'league_15'] as $league) {
eval("function mw_{$league}_url_callback() {
\$options = get_option('mw_theme_options');
echo '<input type=\"text\" name=\"mw_theme_options[{$league}_url]\" value=\"' . esc_attr(\$options['{$league}_url'] ?? '#') . '\" class=\"regular-text\" />';
}");
}
function mw_custom_js_header_enable_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[custom_js_header_enable]" value="1" ' . checked(1, $options['custom_js_header_enable'] ?? 0, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_custom_js_header_callback() {
$options = get_option('mw_theme_options');
echo '<textarea name="mw_theme_options[custom_js_header]" class="large-text" rows="5">' . esc_textarea($options['custom_js_header'] ?? '') . '</textarea>';
$description = __('يجب وضع الأكواد بدون وسوم &lt;script&gt; أو &lt;/script&gt;.', 'malik_web');
echo '<p class="field-description">' . $description . '</p>';
}
function mw_custom_js_footer_enable_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[custom_js_footer_enable]" value="1" ' . checked(1, $options['custom_js_footer_enable'] ?? 0, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_custom_js_footer_callback() {
$options = get_option('mw_theme_options');
echo '<textarea name="mw_theme_options[custom_js_footer]" class="large-text" rows="5">' . esc_textarea($options['custom_js_footer'] ?? '') . '</textarea>';
$description = __('يجب وضع الأكواد بدون وسوم &lt;script&gt; أو &lt;/script&gt;.', 'malik_web');
echo '<p class="field-description">' . $description . '</p>';
}
function mw_custom_css_enable_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[custom_css_enable]" value="1" ' . checked(1, $options['custom_css_enable'] ?? 0, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_custom_css_callback() {
$options = get_option('mw_theme_options');
echo '<textarea name="mw_theme_options[custom_css]" class="large-text" rows="5">' . esc_textarea($options['custom_css'] ?? '') . '</textarea>';
$description = __('يجب وضع الأكواد بدون وسوم &lt;style&gt; أو &lt;/style&gt;.', 'malik_web');
echo '<p class="field-description">' . $description . '</p>';
}
function mw_google_analytics_enable_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[google_analytics_enable]" value="1" ' . checked(1, $options['google_analytics_enable'] ?? 0, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
function mw_google_analytics_code_callback() {
$options = get_option('mw_theme_options');
echo '<textarea name="mw_theme_options[google_analytics_code]" class="large-text" rows="5">' . esc_textarea($options['google_analytics_code'] ?? '') . '</textarea>';
}
function mw_reset_settings_callback() {
echo '<button type="button" id="mw-reset-settings" class="action-button bg-red-600 text-white hover:bg-red-700">' . __('إعادة ضبط جميع الإعدادات', 'malik_web') . '</button>';
echo '<p class="field-description">' . __('سيؤدي هذا إلى إعادة تعيين جميع إعدادات القالب إلى القيم الافتراضية. هذا الإجراء لا يمكن التراجع عنه.', 'malik_web') . '</p>';
}
function mw_export_settings_callback() {
echo '<button type="button" id="mw-export-settings" class="action-button bg-blue-600 text-white hover:bg-blue-700">' . __('تصدير الإعدادات', 'malik_web') . '</button>';
echo '<p class="field-description">' . __('قم بتنزيل ملف يحتوي على جميع إعدادات القالب الحالية.', 'malik_web') . '</p>';
}
function mw_import_settings_callback() {
echo '<div class="input-group">';
echo '<input type="file" id="mw-import-settings-file" accept=".json" class="file-input" />';
echo '<button type="button" id="mw-import-settings" class="action-button bg-green-600 text-white hover:bg-green-700">' . __('استيراد الإعدادات', 'malik_web') . '</button>';
echo '</div>';
echo '<p class="field-description">' . __('قم برفع ملف الإعدادات لاستعادة إعدادات القالب.', 'malik_web') . '</p>';
}
function mw_related_posts_background_callback() {
$options = get_option('mw_theme_options');
$image = esc_attr($options['related_posts_background'] ?? '');
?>
<div class="input-group">
<input type="text" name="mw_theme_options[related_posts_background]" id="mw_related_posts_background" value="<?php echo $image; ?>" class="regular-text" readonly />
<button type="button" class="button mw-upload-image-button"><?php _e('رفع الصورة', 'malik_web'); ?></button>
</div>
<div id="mw_related_posts_background_preview" class="image-preview" style="margin-top: 10px; <?php echo $image ? '' : 'display: none;'; ?>">
<?php if ($image): ?>
<img src="<?php echo $image; ?>" style="max-width: 250px; margin-left: 7px; margin-right: 1px; border-radius: 8px; height: auto;" alt="معاينة الصورة" />
<?php endif; ?>
<button type="button" class="button mw-remove-image-button" style="<?php echo $image ? '' : 'display: none;'; ?>"><?php _e('إزالة الصورة', 'malik_web'); ?></button>
</div>
<p class="description"><?php _e('اختر صورة لتكون خلفية المقالات المقترحة.', 'malik_web'); ?></p>
<script>
jQuery(document).ready(function($) {
// Check if wp.media is available
if (typeof wp === 'undefined' || typeof wp.media === 'undefined') {
console.error('WordPress media library is not loaded.');
return;
}
// Upload image
$('.mw-upload-image-button').on('click', function(e) {
e.preventDefault();
var button = $(this);
var input = $('#mw_related_posts_background');
var preview = $('#mw_related_posts_background_preview');
var removeButton = preview.find('.mw-remove-image-button');
var mediaFrame = wp.media({
title: '<?php _e('اختر صورة خلفية', 'malik_web'); ?>',
button: { text: '<?php _e('استخدام هذه الصورة', 'malik_web'); ?>' },
multiple: false,
library: { type: 'image' }
});
mediaFrame.on('select', function() {
var attachment = mediaFrame.state().get('selection').first().toJSON();
input.val(attachment.url);
preview.show().html(
'<img src="' + attachment.url + '" style="max-width: 200px; height: auto;" alt="معاينة الصورة" />' +
'<button type="button" class="button mw-remove-image-button"><?php _e('إزالة الصورة', 'malik_web'); ?></button>'
);
});
mediaFrame.open();
});
// Remove image
$(document).on('click', '.mw-remove-image-button', function(e) {
e.preventDefault();
var preview = $('#mw_related_posts_background_preview');
$('#mw_related_posts_background').val('');
preview.hide().empty();
});
});
</script>
<?php
}
function mw_related_posts_toggle_callback() {
$options = get_option('mw_theme_options');
echo '<label class="toggle-switch">';
echo '<input type="checkbox" name="mw_theme_options[related_posts_toggle]" value="1" ' . checked(1, $options['related_posts_toggle'] ?? 1, false) . '>';
echo '<span class="slider"></span>';
echo '</label>';
}
/**
* Render Settings Page
*/
function mw_render_settings_page() {
$sections = [
'logo' => ['id' => 'mw-theme-settings-logo', 'title' => __('لوجو الموقع', 'malik_web'), 'icon' => 'fa-image'],
'timezone' => ['id' => 'mw-theme-settings-timezone', 'title' => __('قسم جدول المباريات', 'malik_web'), 'icon' => 'fa-clock'],
'text_boxs' => ['id' => 'mw-theme-settings-text_boxs', 'title' => __('الحقول النصية', 'malik_web'), 'icon' => 'fa-text-height'],
'colors' => ['id' => 'mw-theme-settings-colors', 'title' => __('ألوان القالب', 'malik_web'), 'icon' => 'fa-palette'],
'social_media' => ['id' => 'mw-theme-settings-social_media', 'title' => __('روابط السوشيال ميديا', 'malik_web'), 'icon' => 'fa-share-alt'],
'typography' => ['id' => 'mw-theme-settings-typography', 'title' => __('إعدادات الخطوط', 'malik_web'), 'icon' => 'fa-font'],
'image_settings' => ['id' => 'mw-theme-settings-image_settings', 'title' => __('إعدادات الصور', 'malik_web'), 'icon' => 'fa-compress'],
'sections_names' => ['id' => 'mw-theme-settings-sections_names', 'title' => __('تسمية الأقسام', 'malik_web'), 'icon' => 'fa-list'],
'home_ads' => ['id' => 'mw-theme-settings-home_ads', 'title' => __('إعلانات الصفحة الرئيسية', 'malik_web'), 'icon' => 'fa-ad'],
'post_ads' => ['id' => 'mw-theme-settings-post_ads', 'title' => __('إعلانات المقالة', 'malik_web'), 'icon' => 'fa-ad'],
'match_articles' => ['id' => 'mw-theme-settings-match_articles', 'title' => __('مباريات ذات صلة', 'malik_web'), 'icon' => 'fa-futbol'],
'league_links' => ['id' => 'mw-theme-settings-league_links', 'title' => __('قسم ترتيب الدوريات', 'malik_web'), 'icon' => 'fa-trophy'],
'custom_js' => ['id' => 'mw-theme-settings-custom_js', 'title' => __('أكواد JavaScript مخصصة', 'malik_web'), 'icon' => 'fa-code'],
'custom_css' => ['id' => 'mw-theme-settings-custom_css', 'title' => __('أكواد CSS مخصصة', 'malik_web'), 'icon' => 'fa-code'],
'google_analytics' => ['id' => 'mw-theme-settings-google_analytics', 'title' => __('Google Analytics', 'malik_web'), 'icon' => 'fa-chart-bar'],
'backup_reset' => ['id' => 'mw-theme-settings-backup_reset', 'title' => __('النسخ الاحتياطي وإعادة الضبط', 'malik_web'), 'icon' => 'fa-undo'],
];
?>
<div class="wrap" dir="rtl">
<div class="box">
<div class="main-box">
<div class="des-logo">
<img src="<?php echo esc_url(get_theme_file_uri('assets/uploads/malik-web-fb-logo.png')); ?>" alt="Malik Web Logo" />
</div>
<h1>Welcome to Sigma Sport Dashboard - Powered by <a href="https://www.malik-web.com/" target="_blank">Malik Web</a></h1>
<p>Thank you for choosing our digital solutions, We are excited to support your success.</p>
</div>
</div>
<div class="mw-settings-form">
<div class="mw-tabs">
<?php foreach ($sections as $key => $section) : ?>
<button class="mw-tab <?php echo $key === 'logo' ? 'active' : ''; ?>" data-section="<?php echo esc_attr($key); ?>">
<i class="fas <?php echo esc_attr($section['icon']); ?>"></i>
<?php echo esc_html($section['title']); ?>
</button>
<?php endforeach; ?>
</div>
<form id="mw-settings-form" method="post" action="options.php" enctype="multipart/form-data">
<?php settings_fields('mw_theme_options'); ?>
<?php foreach ($sections as $key => $section) : ?>
<div id="<?php echo esc_attr($key); ?>" class="mw-section <?php echo $key === 'logo' ? 'active' : ''; ?>">
<h2 class="section-title"><?php echo esc_html($section['title']); ?></h2>
<?php
global $wp_settings_sections, $wp_settings_fields;
if (isset($wp_settings_sections[$section['id']])) {
foreach ($wp_settings_sections[$section['id']] as $sec) {
if ($sec['callback']) {
call_user_func($sec['callback'], $sec);
}
if (isset($wp_settings_fields[$section['id']][$sec['id']])) {
foreach ($wp_settings_fields[$section['id']][$sec['id']] as $field) {
$extra_class = ($section['id'] === 'mw-theme-settings-post_ads' && $field['id'] !== 'post_ads_toggle') ? 'post-ads-controls' : '';
?>
<div class="field-group <?php echo esc_attr($extra_class); ?>">
<label class="field-label" for="<?php echo esc_attr($field['id']); ?>">
<?php echo esc_html($field['title']); ?>
</label>
<div class="field-input">
<?php call_user_func($field['callback'], $field['args']); ?>
</div>
</div>
<?php
}
}
}
}
?>
</div>
<?php endforeach; ?>
<div class="form-actions">
<button type="submit" id="submit-btn" class="submit-btn">
<i class="fas fa-save"></i>
<?php _e('حفظ الإعدادات', 'malik_web'); ?>
</button>
</div>
</form>
</div>
<script>
document.addEventListener('DOMContentLoaded', () => {
const tabs = document.querySelectorAll('.mw-tab');
const sections = document.querySelectorAll('.mw-section');
tabs.forEach(tab => {
tab.addEventListener('click', () => {
tabs.forEach(t => t.classList.remove('active'));
sections.forEach(s => s.classList.remove('active'));
tab.classList.add('active');
document.getElementById(tab.dataset.section).classList.add('active');
});
});
const form = document.querySelector('#mw-settings-form');
const submitBtn = document.querySelector('#submit-btn');
form.addEventListener('submit', (e) => {
e.preventDefault();
submitBtn.disabled = true;
submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>جاري الحفظ...';
setTimeout(() => {
const toast = document.createElement('div');
toast.className = 'mw-toast';
toast.innerHTML = '<i class="fas fa-check-circle"></i>تم حفظ الإعدادات بنجاح';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
submitBtn.disabled = false;
submitBtn.innerHTML = '<i class="fas fa-save"></i>حفظ الإعدادات';
form.submit();
}, 1000);
});
// Reset Settings (مع إصلاح للـ radio groups)
document.getElementById('mw-reset-settings').addEventListener('click', () => {
if (confirm('هل أنت متأكد من إعادة ضبط جميع الإعدادات؟ هذا الإجراء لا يمكن التراجع عنه.')) {
const defaultSettings = {
site_logo: '',
site_name: 'قالب سيجما سبورت',
site_name_font_size: 20,
site_des: 'موقع رياضي متكامل',
site_des_font_size: 20,
site_url: 'sigma-sport.com',
site_url_font_size: 20,
site_topdes_toggle: 1,
site_topdes: 'ضع هنا وصف مختصر عن موقعك',
site_botdes_toggle: 1,
site_botdes: 'ضع هنا وصف مفصل عن موقعك',
primary_color: '#24276e',
secondary_color: '#06b1c3',
site_body_color: '#e4eeff',
items_bg_color: '#e4eeff',
facebook_visibility: 1,
facebook_url: '#',
twitter_visibility: 1,
twitter_url: '#',
googlenews_visibility: 1,
googlenews_url: '#',
youtube_visibility: 1,
youtube_url: '#',
telegram_visibility: 1,
telegram_url: '#',
font_primary: 'NeoSansArabic',
section_1: 'جدول مباريات اليوم',
section_2: 'جدول مباريات الغد',
section_3: 'جدول مباريات الأمس',
section_4: 'آخر المقالات',
section_5: 'ترتيب الدوريات',
section_6: 'نبذة عن موقعك',
home_ads_below_header_enable: 1,
home_ads_below_header_code: 'مساحة إعلانية',
home_ads_matches_enable: 1,
home_ads_matches_code: 'مساحة إعلانية',
home_ads_posts_enable: 1,
home_ads_posts_code: 'مساحة إعلانية',
home_ads_news_posts_enable: 0,
home_ads_news_posts_code: 'مساحة إعلانية',
home_ads_footer_enable: 1,
home_ads_footer_code: 'مساحة إعلانية',
post_ads_toggle: 1,
ad_above_post_enable: 1,
ad_above_post_code: 'مساحة إعلانية',
ad_under_post_enable: 1,
ad_under_post_code: 'مساحة إعلانية',
ad_under_post_h2_1_enable: 1,
ad_under_post_h2_1_code: 'مساحة إعلانية',
ad_under_post_h2_2_enable: 1,
ad_under_post_h2_2_code: 'مساحة إعلانية',
ad_under_post_h2_3_enable: 1,
ad_under_post_h2_3_code: 'مساحة إعلانية',
ad_under_post_h2_4_enable: 1,
ad_under_post_h2_4_code: 'مساحة إعلانية',
ad_under_post_h3_1_enable: 1,
ad_under_post_h3_1_code: 'مساحة إعلانية',
ad_under_post_h3_2_enable: 1,
ad_under_post_h3_2_code: 'مساحة إعلانية',
ad_under_post_h3_3_enable: 1,
ad_under_post_h3_3_code: 'مساحة إعلانية',
ad_under_post_h3_4_enable: 1,
ad_under_post_h3_4_code: 'مساحة إعلانية',
ad_under_post_p1_enable: 1,
ad_under_post_p1_code: 'مساحة إعلانية',
ad_under_post_p2_enable: 1,
ad_under_post_p2_code: 'مساحة إعلانية',
ad_under_post_p3_enable: 1,
ad_under_post_p3_code: 'مساحة إعلانية',
ad_under_post_p4_enable: 1,
ad_under_post_p4_code: 'مساحة إعلانية',
sticky_ad_post_enable: 1,
sticky_ad_post_code: 'مساحة إعلانية',
matches_timezone: 'Africa/Cairo',
time_format: '24',
change_days: 0, // الافتراضي: بدون تأخير
leagues_list_toggle: 1,
league_1_url: '#',
league_2_url: '#',
league_3_url: '#',
league_4_url: '#',
league_5_url: '#',
league_6_url: '#',
league_7_url: '#',
league_8_url: '#',
league_9_url: '#',
league_10_url: '#',
league_11_url: '#',
league_12_url: '#',
league_13_url: '#',
league_14_url: '#',
league_15_url: '#',
custom_js_header_enable: 0,
custom_js_header: '',
custom_js_footer_enable: 0,
custom_js_footer: '',
custom_css_enable: 0,
custom_css: '',
google_analytics_enable: 0,
google_analytics_code: '',
related_posts_background: '',
related_posts_toggle: 1,
image_compression_toggle: 0,
open_match_new_tab: 0,
};
for (const [key, value] of Object.entries(defaultSettings)) {
const inputs = form.querySelectorAll(`[name="mw_theme_options[${key}]"]`);
inputs.forEach(inp => {
if (inp.type === 'checkbox') {
inp.checked = value === 1;
} else if (inp.type === 'radio') {
inp.checked = inp.value == value;
} else {
inp.value = value;
}
});
}
const toast = document.createElement('div');
toast.className = 'mw-toast';
toast.innerHTML = '<i class="fas fa-check-circle"></i>تم إعادة ضبط الإعدادات بنجاح';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
form.submit();
}
});
// Export Settings (مع إصلاح للـ radio)
document.getElementById('mw-export-settings').addEventListener('click', () => {
const form = document.getElementById('mw-settings-form');
const options = {};
const inputs = form.querySelectorAll('[name^="mw_theme_options"]');
inputs.forEach(input => {
const key = input.name.replace('mw_theme_options[', '').replace(']', '');
if (input.type === 'checkbox') {
options[key] = input.checked ? 1 : 0;
} else if (input.type === 'radio' && input.checked) {
options[key] = input.value;
} else if (input.type !== 'radio') {
options[key] = input.value;
}
});
const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(options, null, 2));
const downloadAnchor = document.createElement('a');
downloadAnchor.setAttribute('href', dataStr);
downloadAnchor.setAttribute('download', 'mw_theme_options.json');
document.body.appendChild(downloadAnchor);
downloadAnchor.click();
downloadAnchor.remove();
const toast = document.createElement('div');
toast.className = 'mw-toast';
toast.innerHTML = '<i class="fas fa-check-circle"></i>تم تصدير الإعدادات بنجاح';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
});
// Import Settings (مع إصلاح للـ radio groups)
document.getElementById('mw-import-settings').addEventListener('click', () => {
const fileInput = document.getElementById('mw-import-settings-file');
const file = fileInput.files[0];
if (file) {
const reader = new FileReader();
reader.onload = function(e) {
try {
const settings = JSON.parse(e.target.result);
const form = document.getElementById('mw-settings-form');
for (const [key, value] of Object.entries(settings)) {
const inputs = form.querySelectorAll(`[name="mw_theme_options[${key}]"]`);
inputs.forEach(inp => {
if (inp.type === 'checkbox') {
inp.checked = value === 1;
} else if (inp.type === 'radio') {
inp.checked = inp.value == value;
} else {
inp.value = value;
}
});
}
const toast = document.createElement('div');
toast.className = 'mw-toast';
toast.innerHTML = '<i class="fas fa-check-circle"></i>تم استيراد الإعدادات بنجاح';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
form.submit();
} catch (error) {
const toast = document.createElement('div');
toast.className = 'mw-toast error';
toast.innerHTML = '<i class="fas fa-exclamation-circle"></i>خطأ: ملف الإعدادات غير صالح';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
}
};
reader.readAsText(file);
} else {
const toast = document.createElement('div');
toast.className = 'mw-toast error';
toast.innerHTML = '<i class="fas fa-exclamation-circle"></i>يرجى تحديد ملف للاستيراد';
document.body.appendChild(toast);
setTimeout(() => toast.remove(), 3000);
}
});
});
</script>
</div>
<?php
}
/**
* Initialize default theme settings on first activation
*/
function mw_initialize_theme_settings() {
if (get_option('mw_theme_initialized') === false) {
$default_settings = [
'site_logo' => '',
'site_name' => 'قالب سيجما سبورت',
'site_name_font_size' => 20,
'site_des' => 'موقع رياضي متكامل',
'site_des_font_size' => 20,
'site_url' => 'sigma-sport.com',
'site_url_font_size' => 20,
'site_topdes_toggle' => 1,
'site_topdes' => 'ضع هنا وصف مختصر عن موقعك',
'site_botdes_toggle' => 1,
'site_botdes' => 'ضع هنا وصف مفصل عن موقعك',
'primary_color' => '#24276e',
'secondary_color' => '#06b1c3',
'site_body_color' => '#e4eeff',
'items_bg_color' => '#e4eeff',
'facebook_visibility' => 1,
'facebook_url' => '#',
'twitter_visibility' => 1,
'twitter_url' => '#',
'googlenews_visibility' => 1,
'googlenews_url' => '#',
'youtube_visibility' => 1,
'youtube_url' => '#',
'telegram_visibility' => 1,
'telegram_url' => '#',
'font_primary' => 'NeoSansArabic',
'section_1' => 'جدول مباريات اليوم',
'section_2' => 'جدول مباريات الغد',
'section_3' => 'جدول مباريات الأمس',
'section_4' => 'آخر المقالات',
'section_5' => 'ترتيب الدوريات',
'section_6' => 'نبذة عن موقعك',
'home_ads_below_header_enable' => 1,
'home_ads_below_header_code' => 'مساحة إعلانية',
'home_ads_matches_enable' => 1,
'home_ads_matches_code' => 'مساحة إعلانية',
'home_ads_posts_enable' => 1,
'home_ads_posts_code' => 'مساحة إعلانية',
'home_ads_news_posts_enable' => 0,
'home_ads_news_posts_code' => 'مساحة إعلانية',
'home_ads_footer_enable' => 1,
'home_ads_footer_code' => 'مساحة إعلانية',
'post_ads_toggle' => 1,
'ad_above_post_enable' => 1,
'ad_above_post_code' => 'مساحة إعلانية',
'ad_under_post_enable' => 1,
'ad_under_post_code' => 'مساحة إعلانية',
'ad_under_post_h2_1_enable' => 1,
'ad_under_post_h2_1_code' => 'مساحة إعلانية',
'ad_under_post_h2_2_enable' => 1,
'ad_under_post_h2_2_code' => 'مساحة إعلانية',
'ad_under_post_h2_3_enable' => 1,
'ad_under_post_h2_3_code' => 'مساحة إعلانية',
'ad_under_post_h2_4_enable' => 1,
'ad_under_post_h2_4_code' => 'مساحة إعلانية',
'ad_under_post_h3_1_enable' => 1,
'ad_under_post_h3_1_code' => 'مساحة إعلانية',
'ad_under_post_h3_2_enable' => 1,
'ad_under_post_h3_2_code' => 'مساحة إعلانية',
'ad_under_post_h3_3_enable' => 1,
'ad_under_post_h3_3_code' => 'مساحة إعلانية',
'ad_under_post_h3_4_enable' => 1,
'ad_under_post_h3_4_code' => 'مساحة إعلانية',
'ad_under_post_p1_enable' => 1,
'ad_under_post_p1_code' => 'مساحة إعلانية',
'ad_under_post_p2_enable' => 1,
'ad_under_post_p2_code' => 'مساحة إعلانية',
'ad_under_post_p3_enable' => 1,
'ad_under_post_p3_code' => 'مساحة إعلانية',
'ad_under_post_p4_enable' => 1,
'ad_under_post_p4_code' => 'مساحة إعلانية',
'sticky_ad_post_enable' => 1,
'sticky_ad_post_code' => 'مساحة إعلانية',
'matches_timezone' => 'Africa/Cairo',
'time_format' => '24',
'change_days' => 0, // الافتراضي: بدون تأخير
'leagues_list_toggle' => 1,
'league_1_url' => '#',
'league_2_url' => '#',
'league_3_url' => '#',
'league_4_url' => '#',
'league_5_url' => '#',
'league_6_url' => '#',
'league_7_url' => '#',
'league_8_url' => '#',
'league_9_url' => '#',
'league_10_url' => '#',
'league_11_url' => '#',
'league_12_url' => '#',
'league_13_url' => '#',
'league_14_url' => '#',
'league_15_url' => '#',
'custom_js_header_enable' => 0,
'custom_js_header' => '',
'custom_js_footer_enable' => 0,
'custom_js_footer' => '',
'custom_css_enable' => 0,
'custom_css' => '',
'google_analytics_enable' => 0,
'google_analytics_code' => '',
'related_posts_background' => '',
'related_posts_toggle' => 1,
'image_compression_toggle' => 0,
'open_match_new_tab' => 0,
];
update_option('mw_theme_options', $default_settings);
update_option('mw_theme_initialized', true);
}
}
add_action('after_switch_theme', 'mw_initialize_theme_settings');
function mw_load_image_compression() {
$options = get_option('mw_theme_options');
if (isset($options['image_compression_toggle']) && $options['image_compression_toggle']) {
require_once get_template_directory() . '/inc/compress-image.php';
}
}
add_action('after_setup_theme', 'mw_load_image_compression');
?>