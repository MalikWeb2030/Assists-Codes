<?php
/**
* Schema Single Pro - Sigma Sport Theme 2025
* سكيما غنية ومستقلة تمامًا للمقالات + الصفحات + goals
* لا تعتمد على أي ملف خارجي
*/

if (!defined('ABSPATH')) exit;

/* ==========================================================================
Helper: Output JSON-LD (دالة داخلية مستقلة 100%)
========================================================================== */
function mw_output_schema_local(array $schema, string $id): void
{
if (empty($schema['@graph'] ?? $schema['itemListElement'] ?? [])) return;

$schema['@context'] = 'https://schema.org';

echo '<script type="application/ld+json" id="' . esc_attr($id) . '">';
echo json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
echo '</script>' . PHP_EOL;
}

/* ==========================================================================
Main Single Schema Output
========================================================================== */
add_action('wp_head', 'mw_schema_single_output', 10);
function mw_schema_single_output(): void
{
if (!is_singular()) return;
if ($GLOBALS['mw_schema_single_done'] ?? false) return;

global $post;
$post_id   = get_the_ID();
$post_type = get_post_type();

$image = has_post_thumbnail()
? wp_get_attachment_image_url(get_post_thumbnail_id(), 'full')
: get_template_directory_uri() . '/assets/uploads/default.png';

$author_id   = get_the_author_meta('ID');
$author_name = get_the_author();
$author_url  = get_author_posts_url($author_id);

$published = get_the_date('c');
$modified  = get_the_modified_date('c') ?: $published;

$breadcrumb = mw_generate_breadcrumb_schema_local();

// WebPage
$webpage = [
"@type"              => "WebPage",
"@id"                => get_permalink() . "#webpage",
"url"                => get_permalink(),
"name"               => get_the_title(),
"description"        => wp_trim_words(wp_strip_all_tags(get_the_excerpt() ?: get_the_content()), 160, '...'),
"inLanguage"         => get_bloginfo('language'),
"primaryImageOfPage" => ["@type" => "ImageObject", "url" => $image],
"breadcrumb"         => $breadcrumb
];

// Article
$article_type = ($post_type === 'post') ? 'NewsArticle' : 'Article';
$article = [
"@type"           => $article_type,
"@id"             => get_permalink() . "#article",
"headline"        => wp_strip_all_tags(get_the_title()),
"image"           => $image,
"datePublished"   => $published,
"dateModified"    => $modified,
"author"          => ["@type" => "Person", "name" => $author_name, "url" => $author_url],
"publisher"       => [
"@type" => "Organization",
"name"  => get_bloginfo('name'),
"logo"  => ["@type" => "ImageObject", "url" => has_custom_logo() ? wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full') : $image]
],
"mainEntityOfPage" => get_permalink(),
"speakable"       => ["@type" => "SpeakableSpecification", "cssSelector" => [".PostBody h1", ".PostBody p"]]
];

$graph = [$webpage, $article];

// VideoObject for goals
if ($post_type === 'goals') {
$video_url = get_post_meta($post_id, '_summary_link', true);
if ($video_url && filter_var($video_url, FILTER_VALIDATE_URL)) {
$embed_url = $video_url;
if (preg_match('#(?:youtube\.com|youtu\.be)/([^"&?/ ]{11})#i', $video_url, $m)) {
$embed_url = 'https://www.youtube.com/embed/' . $m[1];
}

$graph[] = [
"@type"        => "VideoObject",
"@id"          => get_permalink() . "#video",
"name"         => get_the_title(),
"description"  => wp_trim_words(wp_strip_all_tags(get_the_content()), 100, '...'),
"thumbnailUrl" => $image,
"uploadDate"   => $published,
"contentUrl"   => $video_url,
"embedUrl"     => $embed_url,
"duration"     => "PT3M",
"publisher"    => [
"@type" => "Organization",
"name"  => get_bloginfo('name'),
"logo"  => ["@type" => "ImageObject", "url" => has_custom_logo() ? wp_get_attachment_image_url(get_theme_mod('custom_logo'), 'full') : $image]
]
];
}
}

mw_output_schema_local(["@graph" => $graph], 'mw-schema-single');
$GLOBALS['mw_schema_single_done'] = true;
}

// Breadcrumb Schema (دالة مستقلة داخل الملف)
function mw_generate_breadcrumb_schema_local(): array
{
$items    = [];
$position = 1;

$items[] = ["@type" => "ListItem", "position" => $position++, "name" => "الرئيسية", "item" => home_url('/')];

if (is_single() && ($cats = get_the_category())) {
$items[] = ["@type" => "ListItem", "position" => $position++, "name" => $cats[0]->name, "item" => get_category_link($cats[0])];
}

$items[] = ["@type" => "ListItem", "position" => $position, "name" => get_the_title()];

return ["@type" => "BreadcrumbList", "@id" => get_permalink() . "#breadcrumb", "itemListElement" => $items];
}