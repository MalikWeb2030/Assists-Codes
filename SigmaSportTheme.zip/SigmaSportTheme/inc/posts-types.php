<?php
/* ----------------------------------- * Register Custom Post Type: Goals * ----------------------------------- */
add_action('after_setup_theme', function() {
add_theme_support('post-thumbnails');
});
function register_goals_post_type() {
$labels = array(
'name'                  => _x('ملخصات', 'Post Type General Name', 'text_domain'),
'singular_name'         => _x('ملخص', 'Post Type Singular Name', 'text_domain'),
'menu_name'             => __('إدارة الملخصات', 'text_domain'),
'name_admin_bar'        => __('ملخص', 'text_domain'),
'archives'              => __('أرشيف الملخصات', 'text_domain'),
'attributes'            => __('خصائص الملخص', 'text_domain'),
'parent_item_colon'     => __('الملخص الأم:', 'text_domain'),
'all_items'             => __('كل الملخصات', 'text_domain'),
'add_new_item'          => __('إضافة ملخص جديد', 'text_domain'),
'add_new'               => __('إضافة جديد', 'text_domain'),
'new_item'              => __('ملخص جديد', 'text_domain'),
'edit_item'             => __('تعديل الملخص', 'text_domain'),
'update_item'           => __('تحديث الملخص', 'text_domain'),
'view_item'             => __('عرض الملخص', 'text_domain'),
'view_items'            => __('عرض الملخصات', 'text_domain'),
'search_items'          => __('البحث في الملخصات', 'text_domain'),
'not_found'             => __('لم يتم العثور على ملخصات', 'text_domain'),
'not_found_in_trash'    => __('لم يتم العثور على ملخصات في سلة المهملات', 'text_domain'),
'featured_image'        => __('الصورة البارزة', 'text_domain'),
'set_featured_image'    => __('تعيين الصورة البارزة', 'text_domain'),
'remove_featured_image' => __('إزالة الصورة البارزة', 'text_domain'),
'use_featured_image'    => __('استخدام كصورة بارزة', 'text_domain'),
'insert_into_item'      => __('إدراج في الملخص', 'text_domain'),
'uploaded_to_this_item' => __('تم الرفع لهذا الملخص', 'text_domain'),
'items_list'            => __('قائمة الملخصات', 'text_domain'),
'items_list_navigation' => __('تصفح الملخصات', 'text_domain'),
'filter_items_list'     => __('تصفية قائمة الملخصات', 'text_domain'),
);

$args = array(
'label'                 => __('ملخص', 'text_domain'),
'description'           => __('نوع مقالات مخصص للملخصات', 'text_domain'),
'labels'                => $labels,
'supports'              => array('title', 'editor', 'thumbnail', 'excerpt', 'comments', 'custom-fields'),
'taxonomies'            => array('category', 'post_tag'),
'hierarchical'          => false,
'public'                => true,
'show_ui'               => true,
'show_in_menu'          => true,
'menu_position'         => 6,
'menu_icon'             => get_theme_file_uri('/assets/uploads/theme-icons/channels-icon.png'),
'show_in_admin_bar'     => true,
'show_in_nav_menus'     => true,
'can_export'            => true,
'has_archive'           => true,
'exclude_from_search'   => false,
'publicly_queryable'    => true,
'capability_type'       => 'post',
'show_in_rest'          => true,
'rewrite'               => array('slug' => 'goals'),
);

register_post_type('goals', $args);
}
add_action('init', 'register_goals_post_type', 0);


/* ----------------------------------- * Add Custom Meta Box for Summary Link * ----------------------------------- */
add_action('add_meta_boxes', 'add_summary_link_meta_box');
function add_summary_link_meta_box() {
add_meta_box(
'summary_link_meta_box',
__('رابط الملخص', 'text_domain'),
'summary_link_meta_box_callback',
'goals',
'normal',
'default'
);
}

function summary_link_meta_box_callback($post) {
wp_nonce_field('save_summary_link_meta_box_data', 'summary_link_meta_box_nonce');
$summary_link = get_post_meta($post->ID, '_summary_link', true);
?>
<p>
<label for="summary_link"><?php _e('رابط الملخص:', 'text_domain'); ?></label>
<input type="url" id="summary_link" name="summary_link" value="<?php echo esc_attr($summary_link); ?>" style="width: 80%;" />
<button type="button" id="clear_summary_link" class="button"><?php _e('حذف', 'text_domain'); ?></button>
</p>
<script>
document.getElementById('clear_summary_link').addEventListener('click', function() {
document.getElementById('summary_link').value = '';
});
</script>
<?php
}

add_action('save_post', 'save_summary_link_meta_box_data');
function save_summary_link_meta_box_data($post_id) {
if (!isset($_POST['summary_link_meta_box_nonce']) || !wp_verify_nonce($_POST['summary_link_meta_box_nonce'], 'save_summary_link_meta_box_data')) {
return;
}
if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
return;
}
if (!current_user_can('edit_post', $post_id) || get_post_type($post_id) !== 'goals') {
return;
}
if (isset($_POST['summary_link'])) {
$summary_link = esc_url_raw($_POST['summary_link']);
if (empty($summary_link)) {
delete_post_meta($post_id, '_summary_link');
} elseif (filter_var($summary_link, FILTER_VALIDATE_URL)) {
update_post_meta($post_id, '_summary_link', $summary_link);
}
}
}


/* ----------------------------------- * Register _summary_link in REST API * ----------------------------------- */
add_action('init', 'register_summary_link_meta');
function register_summary_link_meta() {
register_meta('post', '_summary_link', array(
'object_subtype' => 'goals',
'type'           => 'string',
'single'         => true,
'show_in_rest'   => true,
'sanitize_callback' => 'esc_url_raw'
));
}
?>