<?php
// Enqueue Scripts for Load More AJAX (دعم الرئيسية والأرشيف)
function enqueue_load_more_scripts() {
if (is_home() || is_front_page() || is_page() || is_archive()) {
wp_enqueue_script('jquery');
$js_path = get_template_directory_uri() . '/assets/js/load-more.js';
wp_enqueue_script('load-more-js', $js_path, array('jquery'), '1.0', true);
wp_localize_script('load-more-js', 'ajax_object', array(
'ajax_url' => admin_url('admin-ajax.php'),
'nonce' => wp_create_nonce('load_more_nonce'),
'loading_text' => 'جاري التحميل...',
'no_more_text' => 'لا توجد نتائج أخري',
'load_more_text' => 'تحميل المزيد'
));
}
}
add_action('wp_enqueue_scripts', 'enqueue_load_more_scripts');
// AJAX Handler for Load More Posts (توحيد offset للجميع، مع فلاتر)
function load_more_posts_ajax() {
if (!wp_verify_nonce($_POST['nonce'], 'load_more_nonce')) {
wp_send_json_error('أمان غير صالح');
}
$offset = intval($_POST['offset'] ?? 0);
$posts_per_page = intval($_POST['posts_per_page'] ?? get_option('posts_per_page', 12)); // ديناميكي: من WP settings
$post_types = sanitize_text_field($_POST['post_types'] ?? 'post');
$args = array(
'post_type' => explode(',', $post_types),
'posts_per_page' => $posts_per_page,
'post_status' => 'publish',
'offset' => $offset, // استخدم offset دائمًا للتوحيد
'ignore_sticky_posts' => true,
'no_found_rows' => false,
'update_post_term_cache' => false,
'update_post_meta_cache' => false,
);
// فلاتر للأرشيف (يعمل مع offset)
$cat_id = intval($_POST['cat_id'] ?? 0);
$tag_id = intval($_POST['tag_id'] ?? 0);
if ($cat_id > 0) {
$args['cat'] = $cat_id;
}
if ($tag_id > 0) {
$args['tag_id'] = $tag_id;
}
$query = new WP_Query($args);
$total_posts = $query->found_posts;
$post_count = $query->post_count;
$loaded_so_far = $offset + $post_count;
$has_more_posts = ($post_count > 0) && ($total_posts > $loaded_so_far); // موحد: يعمل للرئيسية والأرشيف
ob_start();
if ($query->have_posts()) :
global $post_index;
$post_index = $offset + 1;
while ($query->have_posts()) : $query->the_post();
// تعديل لدعم template part مخصص بناءً على post_type
$current_post_type = get_post_type();
if ($current_post_type === 'matches') {
get_template_part('template-parts/matches-card'); // استخدم ملف مخصص للمباريات
} else {
get_template_part('template-parts/post-card'); // الافتراضي للأنواع الأخرى
}
$post_index++;
endwhile;
endif;
$html = ob_get_clean();
wp_reset_postdata();
wp_send_json_success(array(
'html' => $html,
'has_more' => $has_more_posts,
'total_posts' => $total_posts,
'post_count' => $post_count,
'next_offset' => $loaded_so_far, // تحديث: استخدم $loaded_so_far بدلاً من + $posts_per_page
));
}
add_action('wp_ajax_load_more_posts', 'load_more_posts_ajax');
add_action('wp_ajax_nopriv_load_more_posts', 'load_more_posts_ajax');
?>