<?php
// تحديد رابط خادم التحديثات
define('THEME_UPDATE_SERVER', 'https://tools2025.malik-web.net/Product-updates/Update-jsons/');
define('THEME_API_KEY', 'k7m9p2r4t8w3x5sigmasport');

// دالة للتحقق من التحديثات
function sigma_sport_check_for_updates($transient) {
if (empty($transient->checked)) {
return $transient;
}

// جلب معلومات القالب الحالي
$theme = wp_get_theme();
$theme_slug = $theme->get_stylesheet();
$current_version = $theme->get('Version');

// طلب HTTP لجلب بيانات التحديث
$response = wp_remote_get(
THEME_UPDATE_SERVER . 'sigma-sport-update.json',
array(
'headers' => array(
'Authorization' => 'Bearer ' . THEME_API_KEY,
),
)
);

if (is_wp_error($response)) {
return $transient;
}

$update_data = json_decode(wp_remote_retrieve_body($response), true);

// التحقق من صحة البيانات
if (!isset($update_data['version']) || !isset($update_data['download_url'])) {
return $transient;
}

// التحقق إذا كان هناك إصدار جديد
if (version_compare($current_version, $update_data['version'], '<')) {
$transient->response[$theme_slug] = array(
'theme'       => $theme_slug,
'new_version' => $update_data['version'],
'url'         => isset($update_data['changelog']) ? $update_data['changelog'] : '',
'package'     => $update_data['download_url'],
);
}

return $transient;
}
add_filter('pre_set_site_transient_update_themes', 'sigma_sport_check_for_updates');

// إضافة مفتاح API لتحميل ملف التحديث
function sigma_sport_secure_update($args, $url) {
if (strpos($url, THEME_UPDATE_SERVER) !== false || strpos($url, 'tools2025.malik-web.net') !== false) {
$args['headers']['Authorization'] = 'Bearer ' . THEME_API_KEY;
}
return $args;
}
add_filter('http_request_args', 'sigma_sport_secure_update', 10, 2);
?>