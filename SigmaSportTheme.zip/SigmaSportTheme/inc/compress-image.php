<?php
// فلتر عام لجودة JPEG في ووردبريس (يطبق على الـ thumbnails)
add_filter('jpeg_quality', function($arg) {
return 60; // جودة 60% لضغط أقوى مع جودة مرئية جيدة
});
// دالة ضغط وتغيير حجم الصور بعد الرفع (دعم شامل وموحد لكل الصيغ)
function compress_and_resize_image_after_upload($data) {
// تحقق من نوع الملف إذا كان صورة
$allowed_types = array('image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp', 'image/bmp');
if (!in_array($data['type'], $allowed_types)) {
return $data;
}
$file_path = $data['file']; // المسار النهائي بعد الرفع
// الحصول على معلومات الصورة (أبعاد ونوع MIME)
$info = getimagesize($file_path);
if (!$info) {
return $data; // لو مش صورة صالحة، نرجع بدون تغيير
}
$width = $info[0];
$height = $info[1];
$mime = $info['mime'];
$max_width = 800; // حد أقصى للعرض
$max_height = 600; // حد أقصى للارتفاع
$quality = 60; // الجودة الموحدة (0-100)
// حساب الأبعاد الجديدة مع الحفاظ على النسبة
if ($width > $max_width || $height > $max_height) {
$ratio = min($max_width / $width, $max_height / $height);
$new_width = intval($width * $ratio);
$new_height = intval($height * $ratio);
} else {
$new_width = $width;
$new_height = $height;
}
// إنشاء مصدر الصورة بناءً على النوع مع الحفاظ على الشفافية
$source = null;
if ($mime == 'image/jpeg') {
$source = imagecreatefromjpeg($file_path);
} elseif ($mime == 'image/png') {
$source = imagecreatefrompng($file_path);
imagealphablending($source, false);
imagesavealpha($source, true);
} elseif ($mime == 'image/gif') {
$source = imagecreatefromgif($file_path);
imagealphablending($source, false);
imagesavealpha($source, true);
} elseif ($mime == 'image/webp') {
if (function_exists('imagecreatefromwebp')) {
$source = imagecreatefromwebp($file_path);
imagealphablending($source, false);
imagesavealpha($source, true);
}
} elseif ($mime == 'image/bmp') {
if (function_exists('imagecreatefrombmp')) {
$source = imagecreatefrombmp($file_path); // نادر، بس لو مدعوم
}
}
if (!$source) {
return $data; // لو فشل الإنشاء، نرجع بدون تغيير
}
// إنشاء صورة جديدة مع دعم الشفافية
$thumb = imagecreatetruecolor($new_width, $new_height);
imagealphablending($thumb, false);
imagesavealpha($thumb, true);
// ملء الخلفية بـ transparent إذا كانت الصورة شفافة
$transparent = imagecolorallocatealpha($thumb, 0, 0, 0, 127);
imagefill($thumb, 0, 0, $transparent);
// نسخ وتغيير الحجم مع الحفاظ على الجودة
imagecopyresampled($thumb, $source, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
// حفظ الصورة بناءً على النوع الأصلي مع الضغط الموحد
if ($mime == 'image/jpeg') {
imagejpeg($thumb, $file_path, $quality); // JPEG: جودة 60%
} elseif ($mime == 'image/png') {
$png_quality = 9 - round(($quality / 100) * 9); // PNG: تحويل إلى مستوى ضغط (مثال: 60% = ~4)
imagepng($thumb, $file_path, $png_quality);
} elseif ($mime == 'image/gif') {
imagegif($thumb, $file_path); // GIF: حفظ بدون ضغط إضافي (للحفاظ على الأنيميشن)
} elseif ($mime == 'image/webp') {
if (function_exists('imagewebp')) {
imagewebp($thumb, $file_path, $quality); // WebP: جودة 60%
} else {
// Fallback إلى PNG
imagepng($thumb, $file_path, 6);
}
} elseif ($mime == 'image/bmp') {
// BMP: fallback إلى PNG (BMP مش شائع)
imagepng($thumb, $file_path, 6);
}
// تحرير الذاكرة
imagedestroy($source);
imagedestroy($thumb);
// تحديث معلومات الملف
clearstatcache();
$data['file'] = $file_path;
return $data;
}
// ربط الدالة بالـ hook (بعد الرفع)
add_filter('wp_handle_upload', 'compress_and_resize_image_after_upload');
?>