<?php
/**
 * Plugin Name: Match Schedules
 * Description: Settings page for match schedules without any sanitization or filtering to preserve the code as is.
 * Version: 1.0.0
 * Author: Malik Web Team
 */

// 1) إضافة صفحة رئيسية في لوحة التحكم
function mw_register_match_schedule_page() {
add_menu_page(
__('أدارة المباريات', 'malik_web'),
__('أدارة المباريات', 'malik_web'),
'manage_options',
'mw-match-schedule',
'mw_render_match_schedule_page',
get_theme_file_uri('/assets/uploads/theme-icons/football-icon.png'),
61
);
}
add_action('admin_menu', 'mw_register_match_schedule_page');

// 2) تسجيل الإعدادات
function mw_register_match_settings() {
register_setting('mw_match_settings_group', 'mw_yesterday_matches');
register_setting('mw_match_settings_group', 'mw_today_matches');
register_setting('mw_match_settings_group', 'mw_tomorrow_matches');
register_setting('mw_mode_settings_group', 'mw_schedule_mode', ['default' => 'manual', 'sanitize_callback' => 'mw_sanitize_schedule_mode']);
}
add_action('admin_init', 'mw_register_match_settings');

// Sanitize schedule mode
function mw_sanitize_schedule_mode($input) {
return in_array($input, ['manual', 'auto']) ? $input : get_option('mw_schedule_mode', 'manual');
}

// 3) عرض صفحة الإعدادات
function mw_render_match_schedule_page() {
$updated = isset($_GET['settings-updated']) && $_GET['settings-updated'] === 'true';
$update_type = isset($_GET['update_type']) ? sanitize_text_field($_GET['update_type']) : '';
$schedule_mode = get_option('mw_schedule_mode', 'manual');
?>
<div class="wrap mw-match-schedule-wrap">
<!-- Notification Area -->
<div id="mw-notification" class="mw-notification" style="display: <?php echo $updated ? 'flex' : 'none'; ?>;">
<span class="mw-notification-icon dashicons dashicons-yes-alt"></span>
<span class="mw-notification-message">
<?php
switch ($update_type) {
case 'mode':
echo esc_html($schedule_mode === 'manual' ? __('تم حفظ النظام اليدوي بنجاح!', 'malik_web') : __('تم حفظ النظام التلقائي بنجاح!', 'malik_web'));
break;
case 'matches':
echo esc_html(__('تم حفظ التغييرات بنجاح!', 'malik_web'));
break;
default:
echo esc_html(__('تم حفظ التغييرات بنجاح!', 'malik_web'));
}
?>
</span>
<button type="button" class="mw-notification-close">×</button>
</div>

<!-- Debug Info for Admin -->
<?php if (current_user_can('manage_options') && isset($_GET['mw_debug'])): ?>
<div class="mw-debug-info">
<h2><?php _e('معلومات التصحيح', 'malik_web'); ?></h2>
<p><strong><?php _e('الوضع الحالي:', 'malik_web'); ?></strong> <?php echo esc_html($schedule_mode); ?></p>
<p><strong><?php _e('مباريات الأمس اليدوية:', 'malik_web'); ?></strong> <?php echo esc_html(get_option('mw_yesterday_matches', '')); ?></p>
<p><strong><?php _e('مباريات اليوم اليدوية:', 'malik_web'); ?></strong> <?php echo esc_html(get_option('mw_today_matches', '')); ?></p>
<p><strong><?php _e('مباريات الغد اليدوية:', 'malik_web'); ?></strong> <?php echo esc_html(get_option('mw_tomorrow_matches', '')); ?></p>
</div>
<?php endif; ?>

<div class="box">
<div class="main-box">
<div class="des-logo">
<img src="<?php echo esc_url(get_theme_file_uri('assets/uploads/malik-web-fb-logo.png')); ?>" alt="Malik Web Logo" />
</div>
<h1>Welcome to Matches Table Dashboard - Powered by <a href="https://www.malik-web.com/" target="_blank">Malik Web</a></h1>
<p>Thank you for choosing our digital solutions, We are excited to support your success.</p>
</div>
</div>

<header class="mw-form-header">
<form method="post" action="options.php" class="mw-mode-form" id="mw-mode-form">
<?php settings_fields('mw_mode_settings_group'); ?>
<div class="mw-form-toggle">
<span class="mw-toggle-label"><?php _e('جدول المباريات بنظام المقالات', 'malik_web'); ?></span>
<label class="mw-toggle-switch">
<input type="checkbox" id="mw-schedule-mode" <?php checked($schedule_mode, 'auto'); ?>>
<span class="mw-toggle-slider"></span>
<input type="hidden" name="mw_schedule_mode" id="mw-schedule-mode-hidden" value="<?php echo esc_attr($schedule_mode); ?>">
</label>
<span class="mw-toggle-label"><?php _e('جدول المباريات بنظام الأكواد الجاهزة', 'malik_web'); ?></span>
</div>
<?php submit_button(__('حفظ النظام', 'malik_web'), 'primary mw-save-mode', 'submit_mode', false); ?>
</form>
</header>

<form method="post" action="options.php" class="mw-form" id="mw-match-form">
<?php settings_fields('mw_match_settings_group'); ?>
<div class="mw-tabs">
<!-- Manual Schedule Section -->
<section id="manual" class="mw-tab-pane" style="display: <?php echo $schedule_mode === 'manual' ? 'block' : 'none'; ?>;">
<nav class="mw-sub-tab-nav">
<button type="button" class="mw-sub-tab-button" data-sub-tab="yesterday"><?php _e('مباريات الأمس', 'malik_web'); ?></button>
<button type="button" class="mw-sub-tab-button active" data-sub-tab="today"><?php _e('مباريات اليوم', 'malik_web'); ?></button>
<button type="button" class="mw-sub-tab-button" data-sub-tab="tomorrow"><?php _e('مباريات الغد', 'malik_web'); ?></button>
</nav>
<div class="mw-sub-tab-content">
<div id="yesterday" class="mw-sub-tab-pane">
<h2><?php _e('أكواد جدول مباريات الأمس', 'malik_web'); ?></h2>
<textarea name="mw_yesterday_matches" rows="15" class="mw-textarea"><?php echo esc_textarea(get_option('mw_yesterday_matches', '')); ?></textarea>
</div>
<div id="today" class="mw-sub-tab-pane active">
<h2><?php _e('أكواد جدول مباريات اليوم', 'malik_web'); ?></h2>
<textarea name="mw_today_matches" rows="15" class="mw-textarea"><?php echo esc_textarea(get_option('mw_today_matches', '')); ?></textarea>
</div>
<div id="tomorrow" class="mw-sub-tab-pane">
<h2><?php _e('أكواد جدول مباريات الغد', 'malik_web'); ?></h2>
<textarea name="mw_tomorrow_matches" rows="15" class="mw-textarea"><?php echo esc_textarea(get_option('mw_tomorrow_matches', '')); ?></textarea>
</div>
</div>
<?php submit_button(__('حفظ التغييرات', 'malik_web'), 'primary mw-submit-button', 'submit_manual', false); ?>
</section>

<!-- Automatic Schedule Section -->
<section id="auto" class="mw-tab-pane" style="display: <?php echo $schedule_mode === 'auto' ? 'block' : 'none'; ?>;">
<!-- JavaScript Files Section -->
<div class="mw-js-scripts-section">
<h2>أنشاء جدول المباريات بنظام المقالات</h2>
<div class="mw-matches-but">
<a class="mw-matches" href="/wp-admin/edit.php?post_type=matches">أذهب لأدارة المباريات</a>
</div>	
</div>
</section>
</div>
</form>

<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/fonts/NeoSansArabic.woff2" as="font" type="font/woff2" crossorigin="anonymous">

<style>
@import url('https://cdn.tailwindcss.com');@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');#wpwrap{background:#ffffff}
@font-face{font-family:'NeoSansArabic';src:local('NeoSansArabic'),url('<?php echo get_template_directory_uri();?>/assets/fonts/NeoSansArabic.woff2') format('woff2'),url('<?php echo get_template_directory_uri();?>/assets/fonts/NeoSansArabic.woff') format('woff');font-weight:normal;font-style:normal;font-display:swap}
html{scroll-behavior:smooth;box-sizing:border-box;-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}
*,*::before,*::after{margin:0;padding:0;list-style:none;box-sizing:inherit}
input,textarea,button{font-family:'NeoSansArabic',sans-serif;direction:rtl;font-optical-sizing:auto;font-style:normal;font-stretch:normal;line-height:35px;font-size:14px;font-weight:500;color:#444;background:#fff}
body{position:relative;margin:0;padding:0;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}
* > *{background-color:transparent;margin:0;padding:0;border:0;box-shadow:none;color:inherit;line-height:inherit;font-family:inherit;font-size:inherit;font-weight:inherit;font-style:inherit;text-decoration:inherit}
button,input,textarea{touch-action:manipulation}
*:focus{outline:none}
a{text-decoration:none;color:#fbc121;transition:color 0.3s ease-in-out}
a:hover{color:#100d48}
ul{list-style-type:none}
.box{display:flex;position:relative;flex-direction:column;margin-bottom:20px;border-radius:8px;text-align:center;justify-content:center;font-size:18px;overflow:hidden}
.box::before{content:"V.1.0.0";font-size:14px;position:absolute;bottom:10px;left:10px;line-height:15px;color:#718ba1;opacity:.7}
.main-box{display:flex;font-family:cursive;background-color:#e4eeff;direction:ltr!important;padding:15px;border-radius:8px;text-align:center;overflow:hidden;border:1px solid #d1e7ff;flex-direction:column;align-items:center;justify-content:center}
.des-logo{display:block;position:relative;width:100px;height:100px;border-radius:50%;overflow:hidden}
.des-logo img{display:table;width:100%;height:auto;max-width:100px;max-height:100px;margin:auto}
.des-logo:before{content:"";position:absolute;height:100%;width:25%;background-color:hsl(0deg 0% 100% / 40%);left:-120%;top:0;bottom:0;transform:skewX(-20deg);animation:flare 3s ease-in-out infinite;z-index:3}
@-webkit-keyframes flare{0%{opacity:0}50%{opacity:1}100%{opacity:0}}
@keyframes flare{0%{opacity:0}50%{opacity:1}100%{opacity:0}}
@keyframes flare{0%{transform:skewX(-30deg) translateX(-300px)}20%{transform:skewX(-30deg) translateX(300px)}to{transform:skewX(-30deg) translateX(300px)}}
.main-box h1{display:block;font-family:cursive;color:#718ba1;text-align:center;font-size:30px;margin-bottom:10px}
.main-box p{font-size:15px;color:#999999;margin-bottom:20px}
.main-box h3{display:block;font-family:cursive;color:#718ba1;text-align:center;font-size:18px}
.mw-match-schedule-wrap{font-family:'NeoSansArabic',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Oxygen,Ubuntu,Cantarell,sans-serif;display:flex;position:relative;margin:25px auto;width:85%;max-width:1200px;flex-direction:column;z-index:999;justify-content:center}
.mw-form-header{display:flex;position:relative;flex-direction:column;align-items:center;gap:20px;margin-bottom:20px;background-color:#e4eeff;padding:20px;border-radius:8px;text-align:center;overflow:hidden;border:1px solid #d1e7ff}
input#submit_mode{position:absolute;left:12px;bottom:20px}
.mw-form-title{font-size:28px;color:#1a1a1a;margin:0}
.mw-form-toggle{display:flex;align-items:center;gap:20px}
.mw-toggle-label{font-size:16px;color:#333}
.mw-toggle-switch{position:relative;display:inline-block;width:60px;height:34px}
.mw-toggle-switch input{opacity:0;width:0;height:0}
.mw-toggle-slider{position:absolute;cursor:pointer;top:0;left:0;right:0;bottom:0;background-color:#2196F3;transition:0.4s;border-radius:34px}
.mw-tabs{animation:fadeIn 0.3s}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:translateY(0)}}
.mw-toggle-slider:before{position:absolute;content:"";height:26px;width:26px;left:4px;bottom:4px;background-color:white;transition:0.4s;border-radius:50%}
.wp-core-ui .button-primary{background:#00af87!important;border:none!important;padding:3px 12px;border-radius:8px!important;color:#fff;text-decoration:none;text-shadow:none}
input#submit_mode:disabled,input#submit_manual:disabled,input#submit_auto:disabled{background:#d5dbe7!important;color:#fff!important;cursor:not-allowed}
input:checked + .mw-toggle-slider:before{transform:translateX(26px)}
.mw-save-mode,.mw-submit-button{background-color:#2196F3;border:none;padding:12px 30px;font-size:16px;border-radius:8px;color:white;transition:background-color 0.3s ease,opacity 0.3s ease;position:relative;cursor:pointer}
.mw-save-mode:hover,.mw-submit-button:hover{background-color:#1976D2}
.mw-save-mode.saving,.mw-submit-button.saving{opacity:0.7;cursor:not-allowed}
.mw-save-mode.saving:after,.mw-submit-button.saving:after{content:'';display:inline-block;width:16px;height:16px;border:2px solid #fff;border-top:2px solid transparent;border-radius:50%;animation:spin 0.8s linear infinite;margin-right:5px;vertical-align:middle}
@keyframes spin{0%{transform:rotate(0deg)}100%{transform:rotate(360deg)}}
.mw-notice{padding:15px;margin-bottom:20px;border-radius:8px;box-shadow:0 2px 8px rgba(0,0,0,0.1)}
.mw-notice-warning{background-color:#fff3cd;border-right:4px solid #ffca2c}
.mw-tabs{background-color:#e4eeff;padding:15px;border-radius:8px;overflow:hidden;border:1px solid #d1e7ff}
.mw-sub-tab-nav{display:flex;gap:12px;flex-direction:row;align-items:center;justify-content:center}
.mw-sub-tab-button{display:flex;padding:4px 15px;background:#007bff;color:#fff;font-size:14px;border-radius:12px 12px 0 0;cursor:pointer;border:1px solid #fff;transition:all 0.3s;font-weight:500;align-items:center;flex-direction:row;justify-content:flex-start}
.mw-sub-tab-button.active,.mw-sub-tab-button:hover{background-color:#00af87}
.mw-sub-tab-pane{display:none}
.mw-sub-tab-pane.active{display:flex;flex-direction:column}
.mw-match-entry input{border:1px solid #d1e7ff!important;background:#f2f4f9!important}
.mw-sub-tab-content{background:#fff;padding:15px;border-radius:8px;box-shadow:0 4px 6px rgba(0,0,0,0.1);margin-bottom:20px;animation:fadeIn 0.3s}
.mw-js-scripts-section{background:#fff;padding:15px;border-radius:8px;box-shadow:0 4px 6px rgba(0,0,0,0.1);animation:fadeIn 0.3s}
.mw-sub-tab-content h2,.mw-js-scripts-section h2{display:flex;line-height:35px;color:#100d48;border-bottom:1px solid #d1e7ff;padding:0;width:100%;font-size:16px;text-align:right;overflow:hidden;align-items:center;justify-content:flex-start;font-family:'NeoSansArabic';flex-direction:row;float:right;margin-bottom:20px;margin-top:0}
.mw-sub-tab-content h2:before,.mw-js-scripts-section h2:before{content:"";display:block;height:25px;width:8px;background:linear-gradient(135deg,#06b1c3,#24276e);border-radius:8px;margin-left:10px}
.mw-toggle-label{background-color:#fff;padding:6px;box-shadow:0 4px 6px rgba(0,0,0,0.1);font-size:14px;border-radius:8px}
input.large-text,textarea.mw-textarea,input.regular-text{direction:ltr!important;line-height:25px;border:1px solid #d1e7ff!important}
.mw-textarea{width:100%;padding:15px;border:1px solid #ddd;border-radius:8px;font-size:14px;resize:vertical;background:#fafafa;transition:border-color 0.3s ease}
.mw-textarea:focus{border-color:#2196F3;outline:none;box-shadow:0 0 5px rgba(33,150,243,0.3)}
button.button.button-secondary.mw-add-match{display:block;float:right;width:max-content}
.mw-auto-matches-list p.mw-no-matches{margin-top:0;margin-bottom:20px}
.mw-match-entry{display:flex;gap:10px;margin-bottom:15px;align-items:center}
.mw-input{flex:1;padding:10px;border:1px solid #ddd;border-radius:8px;font-size:14px;transition:border-color 0.3s ease}
.mw-input:focus{border-color:#2196F3;outline:none;box-shadow:0 0 5px rgba(33,150,243,0.3)}
.mw-add-match,.mw-delete-entry{padding:10px 20px;border-radius:8px;transition:background-color 0.3s ease}
.mw-add-match{background-color:#4CAF50;color:white;border:none}
.mw-add-match:hover{background-color:#45a049}
.mw-delete-entry{background-color:#f44336;color:white;border:none}
.mw-delete-entry:hover{background-color:#d32f2f}
.mw-no-matches{color:#777;font-style:italic}
.mw-notification{position:fixed;bottom:15px;left:15px;display:flex;align-items:center;gap:10px;padding:4px 12px;color:#fff!important;border-radius:8px;background:linear-gradient(to right,#22c55e,#16a34a);animation:slideUp 0.3s ease-out;z-index:1000}
.mw-notification.error{background:#f44336}
.mw-notification-icon{font-size:24px}
.mw-notification-message{font-size:12px}
.mw-notification-close{background:none;border:none;color:white;font-size:20px;cursor:pointer}
@keyframes slideUp{from{transform:translateY(100%)}to{transform:translateY(0)}}
@keyframes slideDown{from{transform:translateY(0)}to{transform:translateY(100%)}}
.mw-matches-but{display:block;width:100%;padding:12px;border:1px solid #d1e7ff;overflow:hidden;border-radius:8px;text-align:center}
.mw-matches-but a.mw-matches{display:block;width:100%;padding:20px 8px;background-color:#e4eeff;border:1px solid #d1e7ff;color:#100d48!important;font-weight:600;overflow:hidden;border-radius:8px;text-align:center;font-size:18px}
</style>
<script>
document.addEventListener('DOMContentLoaded', function() {
const toggleSwitch = document.getElementById('mw-schedule-mode');
const modeHiddenInput = document.getElementById('mw-schedule-mode-hidden');
const manualPane = document.getElementById('manual');
const autoPane = document.getElementById('auto');
const modeForm = document.getElementById('mw-mode-form');
const matchForm = document.getElementById('mw-match-form');
const modeSubmit = document.querySelector('.mw-save-mode');
const submitButtons = document.querySelectorAll('.mw-submit-button');

// Initialize toggle state
if (toggleSwitch && manualPane && autoPane) {
if (toggleSwitch.checked) {
manualPane.style.display = 'none';
autoPane.style.display = 'block';
} else {
manualPane.style.display = 'block';
autoPane.style.display = 'none';
}

toggleSwitch.addEventListener('change', function() {
modeHiddenInput.value = this.checked ? 'auto' : 'manual';
manualPane.style.display = this.checked ? 'none' : 'block';
autoPane.style.display = this.checked ? 'block' : 'none';
});
}

// Mode form submission
if (modeForm && modeSubmit) {
modeSubmit.addEventListener('click', function() {
this.classList.add('saving');
this.disabled = true;
modeForm.action = 'options.php?update_type=mode';
setTimeout(() => {
this.classList.remove('saving');
this.disabled = false;
modeForm.submit();
}, 1000); // Simulate saving delay
});
}

// Match form submission
if (matchForm) {
submitButtons.forEach(btn => {
btn.addEventListener('click', function() {
this.classList.add('saving');
this.disabled = true;
matchForm.action = 'options.php?update_type=matches';
setTimeout(() => {
this.classList.remove('saving');
this.disabled = false;
matchForm.submit();
}, 1000); // Simulate saving delay
});
});
}

// Sub-Tab Switching
const subTabButtons = document.querySelectorAll('.mw-sub-tab-button');
const subTabPanes = document.querySelectorAll('.mw-sub-tab-pane');
subTabButtons.forEach(btn => {
btn.addEventListener('click', function() {
const parentTab = btn.closest('.mw-tab-pane').id;
const buttons = document.querySelectorAll(`#${parentTab} .mw-sub-tab-button`);
const panes = document.querySelectorAll(`#${parentTab} .mw-sub-tab-pane`);
buttons.forEach(b => b.classList.remove('active'));
panes.forEach(p => p.classList.remove('active'));
this.classList.add('active');
document.getElementById(this.dataset.subTab).classList.add('active');
});
});

// Notification Handling
function showNotification(message, type = 'success') {
const notif = document.getElementById('mw-notification');
if (notif) {
notif.querySelector('.mw-notification-message').textContent = message;
notif.className = 'mw-notification' + (type === 'error' ? ' error' : '');
notif.style.display = 'flex';
notif.style.animation = 'slideUp 0.3s ease-out';
setTimeout(() => {
notif.style.animation = 'slideDown 0.3s ease-out';
setTimeout(() => notif.style.display = 'none', 300);
}, 3000);
}
}

const notif = document.getElementById('mw-notification');
if (notif) {
notif.querySelector('.mw-notification-close').addEventListener('click', function() {
notif.style.animation = 'slideDown 0.3s ease-out';
setTimeout(() => notif.style.display = 'none', 300);
});
if (notif.style.display === 'flex') {
setTimeout(() => {
notif.style.animation = 'slideDown 0.3s ease-out';
setTimeout(() => notif.style.display = 'none', 300);
}, 3000);
}
}
});
</script>
</div>
<?php
}

// 4) دوال الاسترجاع
function mw_get_manual_yesterday_matches() {
$schedule_mode = get_option('mw_schedule_mode', 'manual');
if ($schedule_mode !== 'manual') {
return '';
}
$m = get_option('mw_yesterday_matches', '');
return $m !== '' ? $m : __('<div class="Matches-available"><span class="Not-available">لا يتوفر مباريات في الوقت الحالي!</span></div>', 'malik_web');
}

function mw_get_manual_today_matches() {
$schedule_mode = get_option('mw_schedule_mode', 'manual');
if ($schedule_mode !== 'manual') {
return '';
}
$m = get_option('mw_today_matches', '');
return $m !== '' ? $m : __('<div class="Matches-available"><span class="Not-available">لا يتوفر مباريات في الوقت الحالي!</span></div>', 'malik_web');
}

function mw_get_manual_tomorrow_matches() {
$schedule_mode = get_option('mw_schedule_mode', 'manual');
if ($schedule_mode !== 'manual') {
return '';
}
$m = get_option('mw_tomorrow_matches', '');
return $m !== '' ? $m : __('<div class="Matches-available"><span class="Not-available">لا يتوفر مباريات في الوقت الحالي!</span></div>', 'malik_web');
}

function mw_get_automatic_yesterday_matches() {
return '';
}

function mw_get_automatic_today_matches() {
return '';
}

function mw_get_automatic_tomorrow_matches() {
return '';
}

// 5) دالة لمعالجة استدعاء mw_get_today_matches
function mw_get_today_matches() {
$schedule_mode = get_option('mw_schedule_mode', 'manual');
if ($schedule_mode === 'manual') {
return mw_get_manual_today_matches();
} else {
return mw_get_automatic_today_matches();
}
}

// 6) تسجيل الشورتكودات
add_action('init', function() {
add_shortcode('manual_yesterday_matches', 'mw_get_manual_yesterday_matches');
add_shortcode('manual_today_matches', 'mw_get_manual_today_matches');
add_shortcode('manual_tomorrow_matches', 'mw_get_manual_tomorrow_matches');
add_shortcode('automatic_yesterday_matches', 'mw_get_automatic_yesterday_matches');
add_shortcode('automatic_today_matches', 'mw_get_automatic_today_matches');
add_shortcode('automatic_tomorrow_matches', 'mw_get_automatic_tomorrow_matches');
add_shortcode('today_matches', 'mw_get_today_matches');
});
?>