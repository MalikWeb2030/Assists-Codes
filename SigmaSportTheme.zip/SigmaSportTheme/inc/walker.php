<?php
class Custom_Walker_Nav_Menu extends Walker_Nav_Menu {
// Start menu item element
function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
$output .= '<li>';
$output .= '<a href="' . esc_url($item->url) . '" title="' . esc_attr($item->title) . '">';
$output .= '<span>' . esc_html($item->title) . '</span></a>';
$output .= '<span class="dots-table">
<span class="dot-1"></span>
<span class="dot-2 yellow"></span>
<span class="dot-3"></span>
</span>';
$output .= '</li>';
}
}
function custom_nav_walker($args) {
if (!wp_doing_ajax()) {
$args['walker'] = new Custom_Walker_Nav_Menu();
}
return $args;
}
add_filter('wp_nav_menu_args', 'custom_nav_walker');
?>