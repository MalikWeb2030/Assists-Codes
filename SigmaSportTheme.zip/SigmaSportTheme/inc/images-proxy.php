<?php
// =============================================================================
// HYPERSPEED PROXY 4-in-1 (2025) – Teams + Players + National Players + Leagues
// أسرع بروكسي صور رياضية في الوطن العربي
// =============================================================================

add_action('init', 'hyperspeed_sports_images_proxy', 1);
function hyperspeed_sports_images_proxy() {
$uri = $_SERVER['REQUEST_URI'] ?? '';

// الروابط المفعّلة للبروكسي
if (
strpos($uri, '/team-logo') !== false ||
strpos($uri, '/assets/images/team-logo') !== false ||
strpos($uri, '/player-img') !== false ||
strpos($uri, '/assets/images/player-img') !== false ||
strpos($uri, '/national-player-img') !== false ||           // جديد
strpos($uri, '/assets/images/national-player-img') !== false || // جديد
strpos($uri, '/league-logo') !== false ||
strpos($uri, '/assets/images/league-logo') !== false
) {

$type = $id = null;

// 1. صور لاعبي الأندية
if (strpos($uri, '/player-img') !== false) {
$type = 'player';
$id   = get_id_from_uri_or_get($uri);
}
// 2. صور لاعبي المنتخبات الوطنية (جديد)
elseif (strpos($uri, '/national-player-img') !== false) {
$type = 'national-player';
$id   = get_id_from_uri_or_get($uri);
}
// 3. صور الدوريات
elseif (strpos($uri, '/league-logo') !== false) {
$type = 'league';
$id   = get_id_from_uri_or_get($uri);
}
// 4. صور الأندية (افتراضي)
else {
$type = 'team';
$id   = get_id_from_uri_or_get($uri);
$id   = $id ?: 1; // default team id
}

// مفتاح الكاش في الـ RAM (Transients)
$cache_key = "sports_img_{$type}_{$id}";
$cached    = get_transient($cache_key);

if ($cached !== false) {
// أقل من 3 مللي ثانية!
sports_send_image($cached);
}

// =================================================================
// تحديد الرابط البعيد + الفولباك حسب النوع
// =================================================================
if ($type === 'player') {
$remote_url = "https://imagecache.365scores.com/image/upload/f_png,w_34,h_34,c_limit,q_auto:eco,dpr_2,d_Athletes:default.png,r_max,c_thumb,g_face,z_0.65/Athletes/{$id}";
$fallback   = get_template_directory() . '/assets/uploads/none-player.png';
}
elseif ($type === 'national-player') {
// صورة لاعب في المنتخب الوطني
$remote_url = "https://imagecache.365scores.com/image/upload/f_png,w_34,h_34,c_limit,q_auto:eco,dpr_2,d_Athletes:{$id}.png,r_max,c_thumb,g_face,z_0.65/Athletes/NationalTeam/{$id}";	
$fallback   = get_template_directory() . '/assets/uploads/none-player.png'; 
}
elseif ($type === 'league') {
$remote_url = "https://imagecache.365scores.com/image/upload/f_png,w_34,h_34,c_limit,q_auto:eco,dpr_2,d_Countries:Round:122.png/v1/Competitions/{$id}";
$fallback   = get_template_directory() . '/assets/uploads/none-league.png';
}
else { // team
$remote_url = "https://imagecache.365scores.com/image/upload/f_png,w_34,h_34,c_limit,q_auto:eco,dpr_2,d_Competitors:default1.png/v1/Competitors/{$id}";
$fallback   = get_template_directory() . '/assets/uploads/none-club.png';
}

// جلب الصورة
$response = wp_remote_get($remote_url, [
'timeout'     => 8,
'user-agent'  => 'Mozilla/5.0 (compatible; SigmaSportBot/4.0)',
'headers'     => ['Referer' => 'https://www.365scores.com/'],
'sslverify'   => false,
]);

if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
$image_data = file_exists($fallback) ? file_get_contents($fallback) : get_transparent_pixel();
} else {
$image_data = wp_remote_retrieve_body($response);
if (empty($image_data)) {
$image_data = file_exists($fallback) ? file_get_contents($fallback) : get_transparent_pixel();
}
}

// حفظ في الكاش لـ 90 يوم (في الـ Object Cache أو RAM)
set_transient($cache_key, $image_data, 90 * DAY_IN_SECONDS);

sports_send_image($image_data);
}
}

// دالة مساعدة لاستخراج الـ ID من URI أو $_GET
function get_id_from_uri_or_get($uri) {
$id = !empty($_GET['id']) && is_numeric($_GET['id']) ? (int)$_GET['id'] : null;
if (!$id && preg_match('#/(\d+)/?$#', $uri, $m)) {
$id = (int)$m[1];
}
return $id ?: 1;
}

// إرسال الصورة بأقصى سرعة وكاش سنة كاملة
function sports_send_image($data) {
header('Cache-Control: public, max-age=31536000, immutable');
header('Expires: ' . gmdate('D, d M Y H:i:s', time() + 31536000) . ' GMT');
header('Content-Type: image/png');
header('Content-Length: ' . strlen($data));
header('Access-Control-Allow-Origin: *');
echo $data;
exit;
}

// بكسل شفاف 1x1 (أسرع fallback في التاريخ)
function get_transparent_pixel() {
return base64_decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8Xw8AAoMBgD0LhVEAAAAASUVORK5CYII=');
}
?>