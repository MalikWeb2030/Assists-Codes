<!-- Document Head and Body Setup -->
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset=<?php bloginfo( 'charset' ); ?>>
<meta name=viewport content="width=device-width, initial-scale=1.0">
<link rel=profile href=https://gmpg.org/xfn/11>
<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/fonts/NeoSansArabic.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<link rel="preload" href="<?php echo get_template_directory_uri(); ?>/assets/fonts/Somar-Regular.woff2" as="font" type="font/woff2" crossorigin="anonymous">
<?php wp_head();?>
<style>
/* =================
Platform         : WordPress
Theme Name       : Sigma Sport
Theme Version    : 1.0.0 & Last Update : Mar-2025
Development By   : Malik Web Team
Desgin URL       : https://www.malik-web.com
================= */
html{scroll-behavior:smooth;box-sizing:border-box;-webkit-text-size-adjust:100%;-moz-text-size-adjust:100%;-ms-text-size-adjust:100%;text-size-adjust:100%}*,*::before,*::after{margin:0;padding:0;list-style:none;box-sizing:inherit}body,input,textarea,button{font-family:var(--font-primary);direction:rtl;font-optical-sizing:auto;font-style:normal;font-stretch:normal;line-height:var(--Main-Line-Height);font-size:var(--Main-Font-Size);font-weight:var(--Main-Font-Weight);color:var(--Main-Font-Color);background:var(--Body-BG)}body{position:relative;margin:0;padding:0;text-rendering:optimizeSpeed;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}* > *{background-color:transparent;margin:0;padding:0;border:0;box-shadow:none;color:inherit;line-height:inherit;font-family:inherit;font-size:inherit;font-weight:inherit;font-style:inherit;text-decoration:inherit}button,input,textarea{touch-action:manipulation}*:focus{outline:none}*:focus-visible{outline:2px solid var(--Main-Color);outline-offset:2px;border-radius:4px}a{text-decoration:none;color:var(--Main-Font-Color,#444);transition:color 0.3s ease-in-out}a:hover{color:var(--Main-Color,#b51818)}img{max-width:100%;height:auto;display:block}#SiteBody{display:block;position:relative;clear:both;margin:0;padding:0;box-shadow:none}ul{list-style-type:none}.vertical-news-ticker{display:flex;align-items:center;width:var(--Full-width);border-radius:var(--Main-Border-Radius);overflow:hidden;box-shadow:var(--Main-Box-Shadow);margin-bottom:var(--Main-Margin);height:45px}.ticker-label{display:flex;background:var(--Main-Color);padding:0 12px;height:45px;font-weight:var(--Font-Weight-1);text-align:center;align-items:center;flex-direction:column}.ticker-label span.ticker-title{margin:5px 0;color:var(--Yellow-Color)}.ticker-wrap{background-color:var(--Secondary-BG);flex:1;overflow:hidden;position:relative;height:100%}.ticker-wrap:after{content:"";display:block;position:absolute;width:20px;height:100%;top:0;left:0;background:var(--Secondary-BG)}.ticker-list{list-style:none;padding:0;margin:0;height:100%;display:flex;flex-direction:column;align-items:flex-start}.ticker-item{display:none;align-items:center;padding:var(--Main-Padding);white-space:nowrap;opacity:0;transition:var(--Tran-2);width:var(--Full-width);height:100%;line-height:45px;transition:opacity 0.6s ease,transform 0.6s ease!important}.ticker-item a{font-size:var(--Font-Size-2);text-decoration:none;transition:var(--Tran-2)}.ticker-icon{margin-left:var(--Padding-2)}svg.ticker-icon-hide{display:none}@media screen and (max-width:550px){.ticker-label span.ticker-title,.ticker-item .ticker-icon{display:none}.ticker-label svg.ticker-icon-hide{display:block;margin:10px 0;fill:var(--Yellow-Color)}.ticker-item{padding:12px 6px}}.PLHolder{opacity:0.9}.PLHolder img{opacity:0}a.thumb.PLHolder{background-image:linear-gradient(to right,var(--Post-Holder-BG-1) 0,var(--Post-Holder-BG-2) 20%,var(--Post-Holder-BG-1) 40%,var(--Post-Holder-BG-1) 100%);background-color:var(--Post-Holder-BG-1);-webkit-animation-direction:reverse;-moz-animation-direction:reverse;animation-direction:reverse;background-repeat:no-repeat;background-size:1000px 900px;-webkit-animation:bs-lazy-anim 1s infinite linear forwards;-moz-animation:bs-lazy-anim 1s infinite linear forwards;animation:bs-lazy-anim 1.01s infinite linear forwards;animation-direction:normal}@-webkit-keyframes bs-lazy-anim{from{background-position:-800px 0}to{background-position:400px 0}}@keyframes bs-lazy-anim{from{background-position:-800px 0}to{background-position:400px 0}}a.thumb{display:block;position:relative;width:var(--Full-width);height:150px;overflow:hidden}a.thumb:before{content:"";position:absolute;z-index:3;left:0;right:0;bottom:0;height:60%;transition:opacity 0.2s;background-image:linear-gradient(to bottom,transparent,rgba(0,0,0,0.75))}a.thumb:after{content:"";position:absolute;z-index:3;left:0;right:0;bottom:0;height:100%;background:rgb(0 0 0 / 30%);background-image:url('<?php echo get_template_directory_uri();?>/assets/uploads/mw-player-icon.png');background-repeat:no-repeat;background-position:center center;opacity:0;transition:var(--Tran-3)}.PLHolder img.loaded{opacity:1;transition:opacity 0.3s ease-in}.Not-available{display:block;background-color:var(--Items-BG);border-radius:var(--Main-Border-Radius);border:var(--Main-Border);font-size:var(--Font-Size-3);position:relative;text-align:center;overflow:hidden;padding:40px 0;opacity:.8}:root{--Main-Gradient-BG:linear-gradient(135deg,var(--Main-Color),var(--Secondary-Color));--Secondary-BG:#fff;--Main-Font-Color:#444;--Main-Font-Size:16px;--Main-Link-Color:#035dcd;--Hover-Link-Color:var(--Main-Color);--Main-Font-Weight:500;--Main-Line-Height:35px;--Main-Padding:12px;--Main-Margin:15px;--Main-Gap:12px;--Main-Border-Radius:8px;--Main-Border:1px solid #d1e7ff;--Main-Box-Shadow:0 2px 10px 0 rgba(0,0,0,0.15);--Main-RGB-BG:rgb(0 0 0 / 60%);--Main-Fill-Color:#fff;--Max-width:1200px;--Full-width:100%;--Half-width:50%;--StartSide:right;--EndSide:left;--White-Color:#ffffff;--Black-Color:#000000;--Gray-Color:#474747;--Gray-Color-1:#718ba1;--Red-Color:#b51818;--Green-Color:#008d29;--Blue-Color:#4267b2;--Yellow-Color:#fab000;--White-BG:#ffffff;--Black-BG:#000000;--T-RGB-BG:rgb(255 255 255 / 0%);--White-RGB-BG:rgb(255 255 255 / 35%);--Black-RGB-BG:rgb(0 0 0 / 60%);--Font-Size-1:12px;--Font-Size-2:14px;--Font-Size-3:18px;--Font-Size-4:20px;--Font-Size-5:22px;--Font-Size-6:25px;--Margin-1:3px;--Margin-2:6px;--Margin-3:10px;--Margin-4:12px;--Padding-1:4px;--Padding-2:6px;--Padding-3:8px;--Padding-4:10px;--Border-Radius-1:3px;--Border-Radius-2:6px;--Border-Radius-3:12px;--Border-Radius-4:50%;--Border-1:1px solid #ddd;--Font-Weight-1:600;--Gap-1:15px;--Box-Shadow-1:0 0 2px rgba(0,0,0,0.3);--TitleBox-BG:var(--White-BG);--TitleBox-Title-BG:var(--Main-Color);--Taps-BG:var(--Gray-Color);--Post-Holder-BG-1:rgb(233,235,238);--Post-Holder-BG-2:rgb(244,245,246);--Tran-1:0.3s;--Tran-2:all 0.3s linear;--Tran-3:all 0.3s ease-out 0s}:root body.Night{--Main-Color:#0e1019;--Secondary-Color:#191d2d;--Items-BG:#0e1019;--White-Color:#ffffff;--White-BG:#ffffff;--Black-BG:#000000;--Main-Gradient-BG:linear-gradient(135deg,var(--Main-Color),var(--Secondary-Color));--Body-BG:var(--Main-Color);--Main-BG:var(--Main-Color);--Secondary-BG:var(--Secondary-Color);--Main-Font-Color:var(--White-Color);--Main-Border:1px solid #252c37;--Hover-Link-Color:#f80;--TitleBox-BG:var(--Black-BG);--TitleBox-Title-BG:var(--Secondary-Color);--Taps-BG:var(--Main-Color);--Gray-Color:var(--Secondary-Color);--Post-Holder-BG-1:var(--Main-Color);--Post-Holder-BG-2:var(--Secondary-Color);--Main-Dark-Color:#0e1019;--Secondary-Dark-Color:#191d2d;--Main-Dark-Font-Color:#f80}.Site-Body{display:grid;width:var(--Full-width);grid-template-columns:calc(72% - var(--Gap-1)) 28%;grid-gap:var(--Gap-1);align-content:center;justify-content:center;margin:0;padding:0}.LeagueBox{position:sticky;margin-bottom:var(--Main-Margin);top:var(--Main-Margin)}.container{display:block;width:var(--Full-width);max-width:var(--Max-width);padding:0 var(--Main-Padding);margin:0 auto;animation:opaCity .4s 0s ease-in-out backwards;-webkit-animation:opaCity .4s 0s ease-in-out backwards;-moz-animation:opaCity .4s 0s ease-in-out backwards;-ms-animation:opaCity .4s 0s ease-in-out backwards}@keyframes opaCity{0%{opacity:0}100%{opacity:1}}@-webkit-keyframes opaCity{0%{opacity:0}100%{opacity:1}}@-moz-keyframes opaCity{0%{opacity:0}100%{opacity:1}}.MW-Box,.MW-AD,.MW-Match{display:block;position:relative;width:var(--Full-width);background-color:var(--Secondary-BG);border-radius:var(--Main-Border-Radius);margin-bottom:var(--Main-Margin);box-shadow:var(--Main-Box-Shadow);overflow:hidden}.MW-AD,.MW-Match,.MW-SiteDes,.MW-Posts,.available{padding:var(--Main-Padding)}.MW-SiteDes p{display:block;text-align:justify!important;line-height:1.5em}.TitleBox{display:flex;align-items:center;justify-content:space-between;position:relative;gap:var(--Main-Gap);background-color:var(--TitleBox-BG);padding:var(--Main-Padding);border-bottom:var(--Main-Border);overflow:hidden}.TitleBox .Title,.TitleBox a.LoadMore{background:var(--Main-Gradient-BG);color:var(--White-Color);padding:0 var(--Padding-3);border-radius:var(--Main-Border-Radius);text-align:center;font-size:var(--Font-Size-2);flex-shrink:0;float:var(--EndSide)}.TitleBox .line{display:block;background:var(--Main-Gradient-BG);width:var(--Full-width);height:2px;border-radius:var(--Border-Radius-1)}.TitleBox .Title{float:var(--StartSide)}.TitleBox a.LoadMore{float:var(--EndSide)}.TopSiteDes{display:block;position:relative;background-color:RGB(223,240,212);color:RGB(44,118,53);height:40px;padding:3px var(--Main-Padding);margin-bottom:var(--Main-Margin);border-radius:var(--Main-Border-Radius);box-shadow:var(--Main-Box-Shadow);font-size:var(--Font-Size-2);text-align:center;clear:both;border:none;overflow:hidden}svg.icon{fill:var(--Main-Fill-Color);width:24px;height:24px;display:block;font-size:0;margin:5px auto;background-size:100% 100%}.toTop{display:flex;cursor:pointer;align-items:center;justify-content:center;position:fixed;right:30px;bottom:80px;width:45px;height:45px;border-radius:var(--Border-Radius-4);visibility:hidden;opacity:0;z-index:5;transform:scale(0);transition:var(--Tran-1)}.toTop.vsbl{visibility:visible;opacity:1;transform:scale(1)}.toTop svg{height:100%;width:var(--Full-width);-webkit-transform:rotate(-90deg);-ms-transform:rotate(-90deg);transform:rotate(-90deg);stroke-width:2;cursor:pointer}.toTop svg .b{fill:var(--Secondary-BG);stroke:rgb(233,235,238);opacity:.9;stroke-width:2px}.toTop svg .c{fill:none;stroke:var(--Hover-Link-Color);stroke-dasharray:100 100;stroke-dashoffset:100;stroke-linecap:round;stroke-width:2px}svg.line,svg .line{width:20px;height:20px;fill:none!important;stroke:var(--Hover-Link-Color);stroke-linecap:round;stroke-linejoin:round;stroke-width:2}.MW-Loading{font-style:normal;display:flex;height:100vh;align-items:center;justify-content:center;flex-direction:column}.MW-Loading:before{content:"";position:absolute;border-top-color:var(--Main-Color,#24276e);border-right-color:var(--Main-Color,#24276e);width:30px;height:30px;border-width:4px;border-style:solid;border-bottom-color:transparent;border-left-color:transparent;border-radius:100%;animation:spin .5s infinite linear;transform:rotate(0deg)}@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}.HeaderShadow{display:block;content:"";position:absolute;width:var(--Full-width);height:150px;top:0;z-index:2}.SiteHeader{display:block;position:relative;background:url('<?php echo get_template_directory_uri();?>/assets/uploads/sigma-sport-theme-header-cover-ar.png') no-repeat top center;margin-bottom:var(--Main-Margin);box-shadow:var(--Main-Box-Shadow);width:var(--Full-width);height:150px;overflow:hidden;z-index:99}.SiteHeader>div{display:flex}#logo{display:block;position:relative;float:var(--StartSide);margin:20px 0;width:295px;height:110px;padding:0;overflow:hidden;user-select:none;-webkit-user-select:none;-ms-user-select:none;-moz-user-select:none}.SiteHeader .site-logo{display:flex;float:right;width:100px;height:110px;vertical-align:middle;background-color:var(--White-RGB-BG);border-radius:var(--Main-Border-Radius);overflow:hidden;position:relative;flex-direction:column;justify-content:center;align-items:center;padding:5px;margin:0}.site-des{display:flex;position:relative;width:185px;margin-right:var(--Margin-3);height:110px;flex-direction:column;overflow:hidden;float:var(--EndSide);align-items:center;flex-wrap:nowrap;justify-content:center;padding:0}.site-des span.site-name,.site-des span.site-url{display:flex;background-color:var(--White-RGB-BG);color:var(--White-Color);border-radius:var(--Main-Border-Radius);width:var(--Full-width);height:40px;font-size:22px;text-align:center;align-items:center;justify-content:center}span.site-slug{height:30px;line-height:30px;font-size:20px;color:var(--Yellow-Color)}.SiteHeader .site-logo:before{content:"";position:absolute;height:100px;width:25%;background-color:hsla(0,0%,100%,0.2);left:-135%;-webkit-transform:skewX(-20deg);transform:skewX(-20deg);-webkit-animation:flare 3s ease-in-out;animation:flare 3s ease-in-out;-webkit-animation-iteration-count:infinite;animation-iteration-count:infinite}@-webkit-keyframes flare{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes flare{0%{opacity:0}50%{opacity:1}100%{opacity:0}}@keyframes flare{0%{transform:skewX(-30deg) translateX(-300px)}20%{transform:skewX(-30deg) translateX(300px)}to{transform:skewX(-30deg) translateX(300px)}}.nav-menu{width:-webkit-calc(var(--Full-width) - 295px);width:-moz-calc(var(--Full-width) - 295px);width:calc(var(--Full-width) - 295px);margin:55px 0}#btn-menu{position:absolute;visibility:hidden}.nav-menu .nav ul.LinksList-Nav{margin-right:var(--Main-Margin)}.nav-menu .nav ul.LinksList-Nav li{display:block;position:relative;float:var(--StartSide);margin-left:var(--Main-Margin)}.nav-menu .nav ul.LinksList-Nav li:last-child{margin-left:0}.nav-menu .nav ul.LinksList-Nav li a{display:flex;padding:0;height:40px;color:var(--White-Color)!important;-webkit-box-pack:center;justify-content:center;-webkit-box-align:center;align-items:center;white-space:nowrap}.nav-menu .nav ul.LinksList-Nav li .dots-table{position:absolute;width:20px;height:4px;-webkit-transition:all 800ms cubic-bezier(0.23,0.01,0,1);-moz-transition:all 800ms cubic-bezier(0.23,0.01,0,1);-o-transition:all 800ms cubic-bezier(0.23,0.01,0,1);transition:all 800ms cubic-bezier(0.23,0.01,0,1);-webkit-transform:translateY(10px);-moz-transform:translateY(10px);-ms-transform:translateY(10px);-o-transform:translateY(10px);transform:translateY(10px);opacity:0;bottom:-20px;right:50%;margin-right:-10px}.nav-menu .nav ul.LinksList-Nav li .dots-table span{display:block;position:absolute;background-color:var(--Main-Color);border-radius:var(--Border-Radius-2);top:0;width:4px;height:4px}.nav-menu .nav ul.LinksList-Nav li .dots-table span.yellow{background-color:var(--Yellow-Color)}.nav-menu .nav ul.LinksList-Nav li .dots-table .dot-1{right:0}.nav-menu .nav ul.LinksList-Nav li .dots-table .dot-2{right:8px}.nav-menu .nav ul.LinksList-Nav li .dots-table .dot-3{left:0}.nav-menu .nav ul.LinksList-Nav li:hover .dots-table{opacity:1;bottom:0}.nav-menu .nav ul.SocialMedia-Nav{margin:var(--Margin-1) 0;float:var(--EndSide);padding:0}.nav-menu .nav ul.SocialMedia-Nav li{display:grid;float:var(--EndSide);margin-right:var(--Margin-2)}.nav-menu .nav ul.SocialMedia-Nav li:last-child{margin-right:0}.nav-menu .nav ul.SocialMedia-Nav a,.dark-mode label{display:grid;cursor:pointer;background-color:var(--White-RGB-BG);border-radius:var(--Border-Radius-2);height:34px;width:34px;padding:0;float:var(--EndSide);transition:var(--Tran-3)}.SiteHeader h1,.SiteHeader h2{display:none!important}.dark-mode.hide,.menu-label.op,.menu-label.clo{display:none}.menu-label.clo .close-icon{width:20px;margin-left:var(--Margin-3)}.nav-menu .nav .SocialMedia-Nav li:hover a[aria-label="facebook"]{background-color:#1877F2}.nav-menu .nav .SocialMedia-Nav li:hover a[aria-label="twitter"]{background-color:#000000}.nav-menu .nav .SocialMedia-Nav li:hover a[aria-label="youtube"]{background-color:#FF0000}.nav-menu .nav .SocialMedia-Nav li:hover a[aria-label="telegram"]{background-color:#0088CC}.nav-menu .nav .SocialMedia-Nav li:hover a[aria-label="google-news"]{background-color:#4285F4}body.Night g.d2{display:inline}body.Night g.d1{display:none}body g.d2{display:none}body g.d1{display:inline}footer#footer{position:relative;background-color:var(--Secondary-BG);box-shadow:var(--Main-Box-Shadow);padding:0;margin:0;overflow:hidden}.Top-Footer{position:relative;display:grid;grid-gap:var(--Main-Gap);grid-template-columns:repeat(4,1fr);margin:0;padding:0}.Top-Footer ul.Links-List{position:relative;display:grid;grid-gap:var(--Main-Gap);grid-template-columns:repeat(1,1fr);margin:var(--Margin-4) 0}.Bottom-Footer{display:block;position:relative;border-top:1px solid var(--White-Color);padding:var(--Main-Padding) 0;overflow:hidden}.Bottom-Footer ul.Site-Links{display:block;position:relative;float:var(--EndSide);overflow:hidden}ul.Site-Links li{float:var(--EndSide);margin-right:var(--Margin-4)}ul.Site-Links li:last-of-type{margin-right:0!important}ul.Links-List li a,ul.Site-Links li a{display:block;background-color:var(--White-RGB-BG);border-radius:var(--Main-Border-Radius);color:var(--White-Color);width:var(--Full-width);font-size:var(--Font-Size-2);padding:0 var(--Padding-3);text-align:center;overflow:hidden}.Copy-Rights{display:flex;position:relative;background-color:var(--White-RGB-BG);color:var(--White-Color);padding:0 var(--Padding-3);border-radius:var(--Main-Border-Radius);float:var(--StartSide);text-align:center;flex-direction:row;align-items:center;justify-content:center}.Copy-Rights a{color:var(--White-Color)}#Malik-Web a#malikweb:hover{background-position:bottom!important}#Malik-Web a#malikweb:after{font-family:sans-serif;font-size:0.5rem;padding:2px 6px;position:absolute;top:-11px;right:35px;z-index:1;content:"Dev by:Malik Web";background:#fbc121;color:#ffffff;opacity:0;visibility:hidden;transition:all 0.15s ease-in-out;border-radius:var(--Border-Radius-2);line-height:0.8rem;text-transform:uppercase;letter-spacing:2px;white-space:nowrap}#Malik-Web a#malikweb:hover:after{opacity:1;visibility:visible;right:30px}.Site-Name{display:inline-block;position:relative;font-size:var(--Font-Size-2)}.mw-SiteDes p{line-height:1.5em!important;text-align:justify}@media screen and (max-width:1000px){.SiteHeader>div{justify-content:center}.menu-label.op{cursor:pointer;display:block;background-color:var(--White-RGB-BG);border-radius:var(--Border-Radius-2);height:34px;width:34px;position:absolute;right:var(--Main-Padding);top:58px}.menu-label.op .icon{fill:var(--White-Color);width:24px;height:24px;display:block;font-size:0;margin:5px auto;background-size:100% 100%}#btn-menu:checked ~ .overflow-ul{position:fixed;top:0;left:0;right:0;bottom:0;background-color:var(--Black-RGB-BG);z-index:10001;box-shadow:0 1px 15px 5px rgba(32,33,36,0.1);-webkit-box-shadow:0 1px 15px 5px rgba(32,33,36,0.1);transition:opacity 0.3s ease;-webkit-transition:opacity 0.3s ease}#btn-menu:checked ~ .overflow-ul .linkm{right:0;opacity:1;visibility:visible;transform:translateX(0) translateY(0);-webkit-transform:translateX(0) translateY(0)}.nav-menu .linkm{height:100vh;width:275px;position:fixed;top:0;right:-300px;background:var(--Main-Gradient-BG);transition:all 0.3s ease-in-out;-webkit-transition:all 0.3s ease-in-out;padding:var(--Main-Padding);overflow-x:hidden;opacity:0;visibility:hidden;z-index:10000;-webkit-overflow-scrolling:touch;will-change:transform,opacity;-webkit-backface-visibility:hidden}.menu-label.clo .icon-menu{position:absolute;left:25px;top:20px}.dark-mode.hide{display:block;position:absolute;left:var(--Main-Padding);top:58px}.menu-label.clo{display:flex;cursor:pointer;background-color:var(--White-RGB-BG);color:var(--White-Color);border-radius:var(--Main-Border-Radius);padding:0 var(--Main-Padding);margin-bottom:var(--Margin-4);align-items:center;justify-content:flex-start;flex-direction:row}.nav-menu .nav ul.LinksList-Nav{display:block;width:var(--Full-width);margin-right:0!important;margin-bottom:var(--Margin-4);padding:0;overflow:hidden}.nav-menu .nav ul.LinksList-Nav li{float:none;font-size:var(--Font-Size-2);margin-bottom:var(--Margin-4);margin-left:0!important}.nav-menu .nav ul.LinksList-Nav li:last-child{margin-bottom:0}.nav-menu .nav ul.LinksList-Nav li a,.menulabc{display:block;background-color:var(--White-RGB-BG);color:var(--White-Color);border-radius:var(--Main-Border-Radius);padding:0 var(--Main-Padding);margin:0;height:inherit}.nav-menu .nav ul.SocialMedia-Nav{float:none;margin:0!important}.nav-menu .nav ul.SocialMedia-Nav li{margin-bottom:var(--Margin-2)}.nav-menu{width:auto;float:none}.nav-menu .nav li .dots-table{display:none}.Site-Body{display:block}.Night .menu-label.clo,.Night .nav-menu .nav ul.LinksList-Nav li a,.Night .menulabc,.Night .nav-menu .nav ul.SocialMedia-Nav a,.Night .dark-mode:not(.hide) label{background-color:var(--Main-BG)!important}.Night .nav-menu .linkm{background:var(--Secondary-BG)}}@media screen and (max-width:750px){.TitleBox .Title,.TitleBox a.LoadMore{width:var(--Full-width);float:none}.TitleBox a.LoadMore{margin-top:var(--Margin-4)}.Top-Footer{grid-template-columns:repeat(2,1fr);padding:12px 0}.Top-Footer ul.Links-List{margin:0!important}.Copy-Rights{width:100%;float:none;margin-bottom:12px}.Bottom-Footer ul.Site-Links{width:100%;position:relative;display:grid;grid-gap:var(--Main-Gap);grid-template-columns:repeat(1,1fr)}ul.Site-Links li{margin-right:0!important}}@media screen and (max-width:500px){.container{padding:0 var(--Padding-3)}#logo{width:185px}.SiteHeader .site-logo,.news-posts-section{display:none!important}.site-des{margin-right:0!important}.Top-Footer{grid-template-columns:repeat(1,1fr)}}.Night ul.nav-tabs li a,.Night span.item-url a,.Night .TitleBox .Title,.Night .TitleBox a.LoadMore{background:var(--Secondary-Dark-Color)!important}.Night li.item span.item-image{background-color:var(--White-BG)}.Night a:focus,.Night a:hover{color:var(--Main-Dark-Font-Color)!important}.Night #blog-pager a:hover svg.icon{fill:var(--Hover-Link-Color)}
</style>
</head>
<body <?php body_class( (isset($_COOKIE['mode']) && $_COOKIE['mode'] === 'rdmode') ? 'Night' : '' ); ?>>

<!-- Site Header Structure -->
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'site_logo' => '',
'site_name' => 'قالب سيجما سبورت',
'site_name_font_size' => 20,
'site_url' => 'sigma-sport.com',
'site_url_font_size' => 20,
'facebook_visibility' => true,
'facebook_url' => '#',
'twitter_visibility' => true,
'twitter_url' => '#',
'googlenews_visibility' => true,
'googlenews_url' => '#',
'youtube_visibility' => true,
'youtube_url' => '#',
'telegram_visibility' => true,
'telegram_url' => '#',
];
$settings = wp_parse_args($options, $defaults);
?>
<div class="HeaderShadow"></div>
<header class="SiteHeader" id="SiteHeader" role="banner">
<div class="container">
<div id="logo">
<a href="<?php echo esc_url(get_bloginfo('url')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>" aria-label="<?php echo esc_attr(get_bloginfo('name')); ?>">
<?php if ( is_front_page() ) { ?>
<h1><?php echo esc_html(get_bloginfo('blogname')); ?></h1>
<?php } ?>
<div class="site-logo">
<?php
$options = get_option('mw_theme_options');
$default_logo = get_template_directory_uri() . '/assets/uploads/sigma-sport-theme-logo.png';
$site_logo_id = absint($options['site_logo'] ?? 0);
$site_logo = $site_logo_id ? wp_get_attachment_url($site_logo_id) : $default_logo;
$site_description = sanitize_text_field($options['site_topdes'] ?? 'قالب سيجما سبورت الرياضي');
?>
<img alt="<?php echo esc_html(get_bloginfo('name')); ?>"
src="<?php echo esc_url($site_logo); ?>"
title="<?php echo esc_html(get_bloginfo('name')); ?>"
width="100" height="100"
style="width:100%;height:auto;max-height:100px;max-width:90px">
</div>
<div class="site-des">
<span class="site-name" style="font-size:<?php echo esc_attr($settings['site_name_font_size']); ?>px;">
<?php echo esc_html($settings['site_name']); ?>
</span>
<span class="site-slug" style="font-size:<?php echo esc_attr($settings['site_des_font_size']); ?>px;">
<?php echo esc_html($settings['site_des']); ?>
</span>
<span class="site-url" style="font-size:<?php echo esc_attr($settings['site_url_font_size']); ?>px;">
<?php echo esc_html($settings['site_url']); ?>
</span>
</div>
</a>
</div>
<nav class="nav-menu" id="nav-menu" role="navigation" aria-label="القائمة الرئيسية">
<input id="btn-menu" type="checkbox" aria-hidden="true">
<label class="menu-label op" for="btn-menu" aria-label="فتح القائمة">
<svg class="icon" aria-hidden="true"><use href="#ic-menu"></use></svg>
</label>
<div class="overflow-ul">
<div class="nav linkm">
<label class="menu-label clo" for="btn-menu">
<svg aria-hidden="true" class="close-icon" data-prefix="fas" role="img" viewBox="0 0 448 512" xmlns="http://www.w3.org/2000/svg"><path d="M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z" fill="currentColor"></path></svg>
<span>إغلاق</span>
</label>
<div class="LinksList">
<?php
$primary_menu = array(
'theme_location' => 'primary-menu',
'container' => 'nav',
'container_class'=> 'primary-menu',
'menu_class' => 'LinksList-Nav',
'fallback_cb' => 'wp_page_menu',
'items_wrap' => '<ul class="LinksList-Nav">%3$s</ul>',
'walker' => new Custom_Walker_Nav_Menu()
);
wp_nav_menu($primary_menu);
?>
</div>
<div class="SocialMedia">
<ul class="SocialMedia-Nav">
<li class="dark-mode">
<label id="darkModeToggle" aria-label="تبديل الوضع الليلي">
<svg class="icon" aria-hidden="true"><use href="#ic-moon-sun"></use></svg>
</label>
</li>
<?php if ($settings['facebook_visibility']): ?>
<li class="facebook">
<a aria-label="فيسبوك" href="<?php echo esc_url($settings['facebook_url']); ?>" rel="nofollow noopener" target="_blank">
<svg class="icon" aria-hidden="true"><use href="#ic-facebook"></use></svg>
</a>
</li>
<?php endif; ?>
<?php if ($settings['twitter_visibility']): ?>
<li class="twitter">
<a aria-label="تويتر" href="<?php echo esc_url($settings['twitter_url']); ?>" rel="nofollow noopener" target="_blank">
<svg class="icon" aria-hidden="true"><use href="#ic-twitter"></use></svg>
</a>
</li>
<?php endif; ?>
<?php if ($settings['googlenews_visibility']): ?>
<li class="google-news">
<a aria-label="جوجل نيوز" href="<?php echo esc_url($settings['googlenews_url']); ?>" rel="nofollow noopener" target="_blank">
<svg class="icon" aria-hidden="true"><use href="#ic-google-news"></use></svg>
</a>
</li>
<?php endif; ?>
<?php if ($settings['youtube_visibility']): ?>
<li class="youtube">
<a aria-label="يوتيوب" href="<?php echo esc_url($settings['youtube_url']); ?>" rel="nofollow noopener" target="_blank">
<svg class="icon" aria-hidden="true"><use href="#ic-youtube"></use></svg>
</a>
</li>
<?php endif; ?>
<?php if ($settings['telegram_visibility']): ?>
<li class="telegram">
<a aria-label="تليجرام" href="<?php echo esc_url($settings['telegram_url']); ?>" rel="nofollow noopener" target="_blank">
<svg class="icon" aria-hidden="true"><use href="#ic-telegram"></use></svg>
</a>
</li>
<?php endif; ?>
</ul>
</div>
</div>
</div>
<div class="dark-mode hide">
<label id="darkModeToggleHide" aria-label="تبديل الوضع الليلي">
<svg class="icon" aria-hidden="true"><use href="#ic-moon-sun"></use></svg>
</label>
</div>
</nav>
</div>
</header>

<!-- Site Body Section -->
<div id="SiteBody">

<!-- Top Site Description Section -->
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'site_topdes' => esc_html__('ضع هنا وصف مختصر عن موقعك', 'malik_web'),
'site_topdes_toggle' => true,
];
$settings = wp_parse_args($options, $defaults);
if (!empty($settings['site_topdes']) && $settings['site_topdes_toggle']) : ?>
<div class="container Flex">
<div class="TopSiteDes">
<p><?php echo esc_html($settings['site_topdes']); ?></p>
</div>
</div>
<?php endif; ?>