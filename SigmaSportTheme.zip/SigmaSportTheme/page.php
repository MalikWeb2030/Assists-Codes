<!-- Page Template Structure -->
<?php get_header(); ?>
<div class="container">
<main class="BlogBox" role="main">
<?php get_template_part('template-parts/page-title');?>
<div class="PostBody" id="ContentBox">
<?php get_template_part('template-parts/page-content');?>
<footer class="PostFooter">
<?php get_template_part('template-parts/posts-share');?>
</footer>
</div>
</main>
</div>
<?php get_footer(); ?>