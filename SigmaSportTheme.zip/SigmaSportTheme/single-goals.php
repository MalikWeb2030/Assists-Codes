<?php
get_header();
?>
<div class="container Flex">
<main class="BlogBox" role="main">
<header class="postTimestamp">
<div class="PostTitle">
<h1 class="TopicTitle"><?php echo esc_html(get_the_title()); ?></h1>
</div>
</header>
<div class="PostBody" id="ContantBody">
<?php 
// استرجاع رابط الملخص من الحقل المخصص
$summary_link = get_post_meta(get_the_ID(), '_summary_link', true);
?>

<div class="MW-Video">
<?php if (!empty($summary_link)) : ?>
<iframe allowfullscreen frameborder="0" height="500px" scrolling="no"
src="<?php echo esc_url($summary_link); ?>" width="100%" sandbox="allow-same-origin allow-scripts allow-forms"></iframe>
<?php else : ?>
<p><?php _e('لم يتم إضافة رابط الملخص.', 'text_domain'); ?></p>
<?php endif; ?>
</div>
	
<div class="MW-Note">
<strong>إخلاء مسئولية</strong>: هذا المحتوى لم يتم انشائه او استضافته بواسطة موقع بطولات وأي مسئولية قانونية تقع على عاتق الطرف الثالث
</div>
	
<?php 
// عرض المحتوى الأساسي
the_content();
?>

<footer class="PostFooter">
<?php 
get_template_part('template-parts/posts-tags');
get_template_part('template-parts/posts-share'); 
?>
</footer>
</div>
</main>

</div>
<style>
.container.Flex{max-width:1000px}.MW-Video{position:relative;width:100%;height:auto;background:#000;margin:10px 0;border-radius:8px;overflow:hidden}.MW-Video iframe{margin-bottom:0!important}.MW-Note{color:#856404;background-color:#fff3cd;border-color:#ffeeba;padding:20px 12px;border-radius:8px}
</style>
<?php get_footer(); ?>