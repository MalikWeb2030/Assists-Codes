<?php get_header();?>

<!-- Start Error Page -->
<div class="container">
<div id="error-page">
<svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
<path d="M256 32c14.2 0 27.3 7.5 34.5 19.8l216 368c7.3 12.4 7.3 27.7 .2 40.1S486.3 480 472 480H40c-14.3 0-27.6-7.7-34.7-20.1s-7-27.8 .2-40.1l216-368C228.7 39.5 241.8 32 256 32zm0 128c-13.3 0-24 10.7-24 24V296c0 13.3 10.7 24 24 24s24-10.7 24-24V184c0-13.3-10.7-24-24-24zm32 224c0-17.7-14.3-32-32-32s-32 14.3-32 32s14.3 32 32 32s32-14.3 32-32z"></path>
</svg>
<h1 class="errortitle">Error 404</h1>
<span>المعذرة، يبدو أن هذه الصفحة غير موجودة !</span>
<span>نرجو الضغط على الزر أدناه لأستئناف التصفح</span>
<a href="<?php echo esc_url(home_url()); ?>">الصفحة الرئيسية</a>
</div>
</div>
<style>
#error-page{display:flex;background-color:var(--Secondary-BG);padding:var(--Main-Padding);border-radius:var(--Main-Border-Radius);box-shadow:var(--Main-Box-Shadow);margin-bottom:var(--Main-Margin);flex-direction:column;justify-content:center;align-items:center}#error-page svg{fill:var(--Main-Color);width:300px;height:auto;max-width:70%;margin:0 auto}#error-page h1.errortitle{font-size:40px;font-weight:var(--Font-Weight-1);margin:var(--Main-Margin) 0;color:var(--Gray-Color-1)}#error-page span{font-size:var(--Font-Size-4);text-align:center}#error-page a{background-color:var(--Main-Color);color:var(--White-Color);padding:0 var(--Main-Padding);border-radius:var(--Main-Border-Radius);margin-top:var(--Main-Margin);font-size:var(--Font-Size-2)}@media screen and (max-width:1000px){div#error-page{height:auto}}
</style>

<?php get_footer();?>