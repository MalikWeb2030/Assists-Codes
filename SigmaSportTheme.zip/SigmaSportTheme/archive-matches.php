<!-- Matches Archive Structure -->
<?php
get_header();
// Retrieve theme options
$options = get_option('mw_theme_options', []);
$related_posts_background = !empty($options['related_posts_background']) ? esc_url($options['related_posts_background']) : get_template_directory_uri() . '/assets/uploads/stadium.jpg';
$default_team_image = get_template_directory_uri() . '/assets/uploads/none-club.png';
// Set pagination parameters for the main query
$posts_per_page = get_option('posts_per_page', 12);
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
$offset = ($paged - 1) * $posts_per_page;
// Modify the main query for CPT archive with offset and limit
if (!is_admin()) {
add_action('pre_get_posts', function($query) use ($posts_per_page, $offset) {
if ($query->is_main_query() && $query->is_post_type_archive('matches') && !is_admin()) {
$query->set('posts_per_page', $posts_per_page);
$query->set('offset', $offset);
$query->set('ignore_sticky_posts', true);
}
});
}
?>
<div class="container">
<main class="MW-Box">
<header class="TitleBox">
<h2 class="Title"><?php _e('المباريات', 'malik_web'); ?></h2>
</header>
<div class="MW-Posts">
<div class="MW-Posts-Grid"
data-use-offset="true"
data-current-offset="<?php echo esc_attr($offset + $wp_query->post_count); // الآن next_offset ?>"
data-posts-per-page="<?php echo esc_attr($posts_per_page); ?>"
data-post-types="matches"
data-cat="0"
data-tag="0"
data-total-posts="<?php echo esc_attr($wp_query->found_posts); // إضافة للتوافق ?>">
<?php if (have_posts()) : ?>
<?php while (have_posts()) : the_post(); ?>
<?php
// Retrieve team IDs from ACF fields
$team_one_id = get_field('team_one', get_the_ID());
$team_two_id = get_field('team_two', get_the_ID());
// Initialize default values
$team_one_name = 'غير معروف';
$team_one_image = $default_team_image;
$team_two_name = 'غير معروف';
$team_two_image = $default_team_image;
// Team One
if ($team_one_id && !is_wp_error($team_one_id)) {
$team_one_term = get_term($team_one_id, 'clubs');
if ($team_one_term && !is_wp_error($team_one_term)) {
$team_one_name = esc_html($team_one_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_one_id);
if ($image_id) {
$team_one_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_one_image;
}
}
}
// Team Two
if ($team_two_id && !is_wp_error($team_two_id)) {
$team_two_term = get_term($team_two_id, 'clubs');
if ($team_two_term && !is_wp_error($team_two_term)) {
$team_two_name = esc_html($team_two_term->name);
$image_id = get_field('club_image', 'clubs_' . $team_two_id);
if ($image_id) {
$team_two_image = wp_get_attachment_image_url($image_id, 'thumbnail') ?: $team_two_image;
}
}
}
?>
<article class="Post-Item" role="article">
<a class="thumb" href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>">
<div class="bg" style="background-image: url('<?php echo $related_posts_background; ?>');">
<div class="teams fx-cen">
<div class="team">
<div class="logo" style="background-image: url('<?php echo esc_url($team_one_image); ?>');" aria-label="<?php echo esc_attr($team_one_name); ?>"></div>
</div>
<div class="team vs">
<div class="txt">VS</div>
</div>
<div class="team">
<div class="logo lazy loaded" style="background-image: url('<?php echo esc_url($team_two_image); ?>');" aria-label="<?php echo esc_attr($team_two_name); ?>"></div>
</div>
</div>
</div>
</a>
<div class="Post-Cont">
<h3 class="Post-Title">
<a href="<?php echo esc_url(get_permalink()); ?>" title="<?php echo esc_attr(get_the_title()); ?>" aria-label="<?php echo esc_attr(get_the_title()); ?>"><?php echo esc_html(get_the_title()); ?></a>
</h3>
</div>
</article>
<?php endwhile; ?>
<?php else : ?>
<div class="Articles-available">
<span class="Not-available">
<?php _e('لا يتوفر مباريات في الوقت الحالي !', 'malik_web'); ?>
</span>
</div>
<?php endif; ?>
</div>
<?php
// Check if there are more posts for load more button
global $wp_query;
$has_more = $wp_query->found_posts > ($offset + $wp_query->post_count);
if ($has_more) :
?>
<div class="load-more-container">
<button class="load-more-btn" aria-label="تحميل المزيد من المباريات"><?php _e('تحميل المزيد', 'malik_web'); ?></button>
</div>
<?php endif; ?>
</div>
</main>
</div>
<style>
.thumb .bg{overflow:hidden;border-radius:var(--Main-Border-Radius);background-size:cover;background-position:center;height:100%;position:relative;display:flex;justify-content:center;align-items:center}
.thumb .bg::before{content:'';position:absolute;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.3);z-index:1}
.teams{display:flex;align-items:center;gap:var(--Main-Gap);position:relative;z-index:2}
.team{flex:1;text-align:center}
.team.vs{flex:0;font-weight:bold}
.txt{font-size:var(--Font-Size-4);color:var(--White-Color);font-weight:var(--Font-Weight-1)}
.logo{width:60px;height:60px;background-size:cover;background-position:center;border-radius:50%;margin:0 auto;border:2px solid #eceef2;box-shadow:var(--Main-Box-Shadow)}
</style>
<?php
wp_reset_postdata();
get_footer();
?>