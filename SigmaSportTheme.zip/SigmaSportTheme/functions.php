<?php
/**
* Theme Functions
* @package SigmaSportTheme
* @version 1.0.0
* @author Malik Web Team
*/
if (!defined('ABSPATH')) {
exit;
}

/* -----------------------------------
* Constants
* ----------------------------------- */
define('THEME_NAME', 'SigmaSport');
define('THEME_SLUG', 'themesigmasport');
define('THEME_VER', '1.0.0');
define('THEME_TEXTDOMAIN', 'sigma-sport');
define('THEME_DIR', get_template_directory());
define('THEME_URI', get_template_directory_uri());

/* -----------------------------------
* Theme Setup
* ----------------------------------- */
if (!function_exists('malikweb_theme_setup')) {
function malikweb_theme_setup() {
load_theme_textdomain(THEME_TEXTDOMAIN, THEME_DIR . '/languages');

add_theme_support('title-tag');
add_theme_support('post-thumbnails', ['post', 'page']);
add_theme_support('html5', [
'search-form',
'comment-form',
'comment-list',
'gallery',
'caption',
'script',
'style'
]);
add_theme_support('post-formats', [
'aside', 'gallery', 'link', 'image', 'quote', 'status', 'video', 'audio', 'chat'
]);
add_theme_support('automatic-feed-links');
add_theme_support('customize-selective-refresh-widgets');

register_nav_menus([
'primary-menu' => esc_html__('Primary Menu', THEME_TEXTDOMAIN),
'footer-menu' => esc_html__('Footer Menu', THEME_TEXTDOMAIN),
'footer-column-1' => esc_html__('Footer Column 1', THEME_TEXTDOMAIN),
'footer-column-2' => esc_html__('Footer Column 2', THEME_TEXTDOMAIN),
'footer-column-3' => esc_html__('Footer Column 3', THEME_TEXTDOMAIN),
'footer-column-4' => esc_html__('Footer Column 4', THEME_TEXTDOMAIN),
]);

add_image_size('malikweb-featured', 1200, 600, true);
add_image_size('malikweb-thumbnail', 400, 300, true);
}
}
add_action('after_setup_theme', 'malikweb_theme_setup');

/* -----------------------------------
* Enqueue Scripts and Styles
* ----------------------------------- */
add_action('wp_enqueue_scripts', function() {
// Deregister and enqueue jQuery
wp_deregister_script('jquery');
wp_enqueue_script('jquery', THEME_URI . '/assets/js/jquery.min.js', [], '3.6.0', true);

// Enqueue theme scripts
wp_enqueue_script('mt-script', THEME_URI . '/assets/js/mt.js', [], THEME_VER, true);
wp_enqueue_script('main-script', THEME_URI . '/assets/js/main.js', ['jquery', 'mt-script'], THEME_VER, true);

// Flush rewrite rules on init (optimized to run only once if needed)
add_action('init', function() {
if (get_option('malikweb_rewrite_flushed') !== THEME_VER) {
flush_rewrite_rules();
update_option('malikweb_rewrite_flushed', THEME_VER);
}
});
}, 10);

// Enqueue custom styles
if (!function_exists('mw_enqueue_custom_styles')) {
function mw_enqueue_custom_styles() {
wp_enqueue_style('fonts-style', THEME_URI . '/assets/css/fonts.css', [], THEME_VER);
wp_enqueue_style('main-style', THEME_URI . '/assets/css/main.css', [], THEME_VER);
wp_enqueue_style('theme-style', get_stylesheet_uri(), [], THEME_VER);

// Conditional styles
if (is_front_page() || is_page_template(['templates/home.php', 'templates/today-matches.php', 'templates/tomorrow-matches.php', 'templates/yesterday-matches.php'])) {
wp_enqueue_style('matches-style', THEME_URI . '/assets/css/matches.css', [], THEME_VER);
}
if (is_page_template(['templates/standings.php', 'templates/league.php', 'templates/teams.php', 'templates/team.php', 'templates/player.php'])) {
wp_enqueue_style('standings-style', THEME_URI . '/assets/css/standings.css', [], THEME_VER);
}
if (!is_front_page()) {
wp_enqueue_style('page-style', THEME_URI . '/assets/css/page.css', [], THEME_VER);
}
}
add_action('wp_enqueue_scripts', 'mw_enqueue_custom_styles', 15);
}

// Admin styles for theme settings
function enqueue_admin_theme_settings_css($hook) {
$current_screen = get_current_screen();
if ($current_screen && $current_screen->id === 'toplevel_page_mw-theme-settings') {
wp_enqueue_style('admin-theme-settings', THEME_URI . '/assets/css/admin-theme-settings.css', [], '1.0.0');
}
}
add_action('admin_enqueue_scripts', 'enqueue_admin_theme_settings_css');

/* -----------------------------------
* SEO Meta Tags
* ----------------------------------- */
if (!function_exists('malikweb_seo_meta_tags')) {
function malikweb_seo_meta_tags() {
if (is_single()) {
$tags = get_the_tags();
if ($tags && !is_wp_error($tags)) {
$tag_list = wp_list_pluck($tags, 'name');
printf('<meta name="keywords" content="%s" />' . "\n", esc_attr(implode(', ', $tag_list)));
}
}
}
}
add_action('wp_head', 'malikweb_seo_meta_tags', 5);

/* -----------------------------------
* Excerpt Customization
* ----------------------------------- */
add_filter('excerpt_length', function() {
return 25;
}, 999);

add_filter('excerpt_more', function() {
return sprintf('… <a class="read-more" href="%s">%s</a>', esc_url(get_permalink()), esc_html__('Read More', THEME_TEXTDOMAIN));
});

/* -----------------------------------
* Debugging Utility
* ----------------------------------- */
if (!function_exists('malikweb_debug')) {
function malikweb_debug($data, $die = false) {
if (defined('WP_DEBUG') && WP_DEBUG) {
echo '<pre>';
var_dump($data);
echo '</pre>';
if ($die) {
wp_die();
}
}
}
}

/* -----------------------------------
* Include Theme Files
* ----------------------------------- */
$theme_includes = [
'/inc/images-proxy.php',
'/inc/walker.php',
'/inc/filters.php',
'/inc/theme-settings.php',
'/inc/match-schedule-settings.php',
'/inc/theme-update.php',
'/inc/posts-types.php',
'/inc/load-more-handler.php',
'/inc/schema.php',
'/inc/schema-single.php',
];
foreach ($theme_includes as $file) {
$file_path = THEME_DIR . $file;
if (file_exists($file_path)) {
require_once $file_path;
}
}

/* -----------------------------------
* Customizer Root CSS
* ----------------------------------- */
function malikweb_customize_root() {
$options = get_option('mw_theme_options', []);
$defaults = [
'font_primary' => 'NeoSansArabic, sans-serif',
'primary_color' => '#24276e',
'secondary_color' => '#06b1c3',
'site_body_color' => '#ffffff',
'items_bg_color' => '#f1f1f1',
];
$settings = wp_parse_args($options, $defaults);

// Sanitize settings
$settings['font_primary'] = sanitize_text_field($settings['font_primary']);
$settings['primary_color'] = sanitize_hex_color($settings['primary_color']) ?: $defaults['primary_color'];
$settings['secondary_color'] = sanitize_hex_color($settings['secondary_color']) ?: $defaults['secondary_color'];
$settings['site_body_color'] = sanitize_hex_color($settings['site_body_color']) ?: $defaults['site_body_color'];
$settings['items_bg_color'] = sanitize_hex_color($settings['items_bg_color']) ?: $defaults['items_bg_color'];
?>
<style>
.HeaderShadow,footer#footer{background:linear-gradient(135deg,<?php echo esc_attr($settings['primary_color']);?>,<?php echo esc_attr($settings['secondary_color']);?>)}:root{--font-primary:<?php echo esc_attr($settings['font_primary']);?>;--Main-Color:<?php echo esc_attr($settings['primary_color']);?>;--Secondary-Color:<?php echo esc_attr($settings['secondary_color']);?>;--Post-Title-Color:linear-gradient(135deg,<?php echo esc_attr($settings['secondary_color']);?>,<?php echo esc_attr($settings['primary_color']);?>);--Body-BG:<?php echo esc_attr($settings['site_body_color']);?>;--Items-BG:<?php echo esc_attr($settings['items_bg_color']);?>;--Half-width:50%}body:before,body:after{content:'';position:absolute;height:150px;width:50%;top:0;z-index:1}body:before{right:0;background-color:<?php echo esc_attr($settings['secondary_color']);?>}body:after{left:0;background-color:<?php echo esc_attr($settings['primary_color']);?>}::-webkit-scrollbar{background:#fff;width:12px}::-webkit-scrollbar-thumb{background:<?php echo esc_attr($settings['primary_color']);?>}::-moz-scrollbar{background:#fff;width:12px}::-moz-scrollbar-thumb{background:<?php echo esc_attr($settings['primary_color']);?>}::-o-scrollbar{background:#fff;width:12px}::-o-scrollbar-thumb{background:<?php echo esc_attr($settings['primary_color']);?>}
</style>
<?php
}
add_action('wp_head', 'malikweb_customize_root', 10);

/* -----------------------------------
* Create Standard Pages
* ----------------------------------- */
if (!function_exists('check_and_publish_mw_standard_pages')) {
function check_and_publish_mw_standard_pages() {
// منع التكرار: نستخدم option عشان الكود يشتغل مرة واحدة فقط
if (get_option('mw_standard_pages_created_v2') === 'yes') {
return;
}

$pages = [
[
'title'    => __('جدول مباريات اليوم', THEME_TEXTDOMAIN),
'slug'     => 'today-matches',
'status'   => 'publish',
'template' => 'templates/today-matches.php',
],
[
'title'    => __('جدول مباريات الغد', THEME_TEXTDOMAIN),
'slug'     => 'tomorrow-matches',
'status'   => 'publish',
'template' => 'templates/tomorrow-matches.php',
],
[
'title'    => __('جدول مباريات الأمس', THEME_TEXTDOMAIN),
'slug'     => 'yesterday-matches',
'status'   => 'publish',
'template' => 'templates/yesterday-matches.php',
],
[
'title'    => __('ترتيب الفرق والهدافين لأهم الدرويات والبطولات العربية والأوروبية', THEME_TEXTDOMAIN),
'slug'     => 'standings',
'status'   => 'publish',
'template' => 'templates/standings.php',
],
[
'title'    => __('league', THEME_TEXTDOMAIN),
'slug'     => 'league',
'status'   => 'publish',
'template' => 'templates/league.php',
],
[
'title'    => __('teams', THEME_TEXTDOMAIN),
'slug'     => 'teams',
'status'   => 'publish',
'template' => 'templates/teams.php',
],
[
'title'    => __('team', THEME_TEXTDOMAIN),
'slug'     => 'team',
'status'   => 'publish',
'template' => 'templates/team.php',
],
[
'title'    => __('player', THEME_TEXTDOMAIN),
'slug'     => 'player',
'status'   => 'publish',
'template' => 'templates/player.php',
],
// صفحة Home نحولها لـ front page بعدين لو عايز (نخليها draft دلوقتي)
[
'title'    => 'Home',
'slug'     => 'home-front',
'status'   => 'draft',
'template' => 'home.php',
],
[
'title'    => __('سياسة الخصوصية', THEME_TEXTDOMAIN),
'slug'     => 'privacy-policy',
'status'   => 'publish',
],
[
'title'    => __('أتفاقية الإستخدام', THEME_TEXTDOMAIN),
'slug'     => 'terms-of-use',
'status'   => 'publish',
],
[
'title'    => __('أتصل بنا', THEME_TEXTDOMAIN),
'slug'     => 'contact-us',
'status'   => 'publish',
],
[
'title'    => __('من نحن', THEME_TEXTDOMAIN),
'slug'     => 'about-us',
'status'   => 'publish',
],
[
'title'    => __('DMCA', THEME_TEXTDOMAIN),
'slug'     => 'dmca',
'status'   => 'publish',
],
];

foreach ($pages as $page) {
// تحقق من وجود الصفحة بالـ slug (الطريقة الصحيحة والآمنة)
$exists = get_page_by_path($page['slug'], OBJECT, 'page');

if (!$exists) {
$page_id = wp_insert_post([
'post_title'   => $page['title'],
'post_name'    => $page['slug'],
'post_status'  => $page['status'],
'post_type'    => 'page',
'post_author'  => get_current_user_id() ?: 1,
'comment_status' => 'closed',
'ping_status'   => 'closed',
]);

if ($page_id && !is_wp_error($page_id)) {
// لو في تمبليت → نطبقه
if (!empty($page['template'])) {
update_post_meta($page_id, '_wp_page_template', $page['template']);
}
}
} else {
// لو الصفحة موجودة بس مالهاش تمبليت → نضيفه (لو عايز)
if (!empty($page['template'])) {
$current_template = get_post_meta($exists->ID, '_wp_page_template', true);
if (!$current_template || $current_template !== $page['template']) {
update_post_meta($exists->ID, '_wp_page_template', $page['template']);
}
}
}
}

// نحدد إن الصفحات اتعملت خلاص → مش هتتعمل تاني أبدًا
update_option('mw_standard_pages_created_v2', 'yes');
}
add_action('after_switch_theme', 'check_and_publish_mw_standard_pages');
}

/* -----------------------------------
* Disable Gutenberg Styles
* ----------------------------------- */
if (!function_exists('mw_remove_global_styles')) {
function mw_remove_global_styles() {
wp_dequeue_style('wp-block-library');
wp_dequeue_style('wp-block-library-rtl');
wp_deregister_style('wp-block-library');
wp_deregister_style('wp-block-library-rtl');
wp_dequeue_style('global-styles');
wp_deregister_style('global-styles');
wp_dequeue_style('classic-theme-styles');
wp_deregister_style('classic-theme-styles');
}
}
add_action('wp_enqueue_scripts', 'mw_remove_global_styles', 100);
add_filter('should_load_block_editor_assets', '__return_false');
add_filter('wp_enqueue_global_styles', '__return_false');
add_filter('wp_should_load_global_styles', '__return_false');
add_filter('wp_should_load_classic_theme_styles', '__return_false');

/* -----------------------------------
* Custom Header and Footer Scripts
* ----------------------------------- */
$options = get_option('mw_theme_options', []);
$defaults = [
'custom_js_header_enable' => true,
'custom_js_header' => '',
'custom_js_footer_enable' => true,
'custom_js_footer' => '',
];
$settings = wp_parse_args($options, $defaults);

// قائمة الوسوم المسموحة (نفس اللي استخدمناها قبل كده)
$allowed_tags = wp_kses_allowed_html('post'); // ابدأ بقائمة الـ post الافتراضية
$allowed_tags['script'] = array(  // أضف script كامل للـ JS
'async' => true,
'src' => true,
'type' => true,
);

// Header JS
add_action('wp_head', function() use ($settings, $allowed_tags) {
if (!empty($settings['custom_js_header_enable']) && $settings['custom_js_header_enable']) {
$code = !empty($settings['custom_js_header']) ? $settings['custom_js_header'] : '';
if (!empty($code)) {
echo "\n<!-- Custom JS Head -->\n" . wp_kses($code, $allowed_tags) . "\n";
}
}
}, 99);

// Footer JS
add_action('wp_footer', function() use ($settings, $allowed_tags) {
if (!empty($settings['custom_js_footer_enable']) && $settings['custom_js_footer_enable']) {
$code = !empty($settings['custom_js_footer']) ? $settings['custom_js_footer'] : '';
if (!empty($code)) {
echo "\n<!-- Custom JS Footer -->\n" . wp_kses($code, $allowed_tags) . "\n";
}
}
}, 99);

/* -----------------------------------
* Google Analytics
* ----------------------------------- */
function mw_add_google_analytics_code() {
$options = get_option('mw_theme_options', []);
if (!empty($options['google_analytics_enable']) && !empty($options['google_analytics_code'])) {
add_action('wp_head', function() use ($options) {
$allowed_tags = wp_kses_allowed_html('post'); // ابدأ بقائمة الـ post الافتراضية
$allowed_tags['script'] = array(  // أضف script كامل
'async' => true,
'src' => true,
'type' => true,
);
echo "\n<!-- Google Analytics Code -->\n" . wp_kses($options['google_analytics_code'], $allowed_tags) . "\n";
}, 99);
}
}
add_action('wp_enqueue_scripts', 'mw_add_google_analytics_code');

/* -----------------------------------
* Custom CSS from Theme Settings
* ----------------------------------- */
function mw_enqueue_custom_css() {
$options = get_option('mw_theme_options', []);
if (!empty($options['custom_css_enable']) && !empty($options['custom_css'])) {
add_action('wp_head', function() use ($options) {
echo "\n<!-- Custom CSS -->\n<style type=\"text/css\">\n" . wp_kses_post($options['custom_css']) . "\n</style>\n";
});
}
}
add_action('wp_enqueue_scripts', 'mw_enqueue_custom_css');

/* -----------------------------------
* Archive Title Customization
* ----------------------------------- */
add_filter('get_the_archive_title', function($title) {
if (is_category()) {
$title = single_cat_title('', false);
} elseif (is_tag()) {
$title = single_tag_title('', false);
} elseif (is_tax()) {
$title = single_term_title('', false);
}
return $title;
});

/* -----------------------------------
* Custom Post Type: Matches
* ----------------------------------- */
function register_matches_post_type() {
$labels = [
'name' => 'مركز المباريات',
'singular_name' => 'مباراة',
'menu_name' => 'مركز المباريات',
'name_admin_bar' => 'مباراة',
'add_new' => 'إضافة مباراة',
'add_new_item' => 'إضافة مباراة جديدة',
'new_item' => 'مباراة جديدة',
'edit_item' => 'تعديل المباراة',
'view_item' => 'عرض المباراة',
'all_items' => 'كل المباريات',
'search_items' => 'البحث في المباريات',
'not_found' => 'لم يتم العثور على مباريات',
'not_found_in_trash' => 'لم يتم العثور على مباريات في المهملات',
];

$args = [
'labels' => $labels,
'public' => true,
'publicly_queryable' => true,
'show_ui' => true,
'show_in_menu' => true,
'query_var' => true,
'rewrite' => ['slug' => 'matches'],
'capability_type' => 'post',
'has_archive' => true,
'hierarchical' => false,
'menu_position' => 5,
'menu_icon' => THEME_URI . '/assets/uploads/theme-icons/stadium-icon.png',
'supports' => ['title', 'editor', 'thumbnail', 'excerpt'],
'taxonomies' => ['clubs', 'tournaments'],
];

register_post_type('matches', $args);
}
add_action('init', 'register_matches_post_type', 0);

/* -----------------------------------
* Video Servers Meta Box
* ----------------------------------- */
function register_video_servers_meta_box() {
add_meta_box(
'video_servers_box',
'سيرفرات المشاهدة',
'display_video_servers_meta_box',
'matches',
'normal',
'high'
);
}
add_action('add_meta_boxes', 'register_video_servers_meta_box');

function display_video_servers_meta_box($post) {
wp_nonce_field('save_video_servers', 'video_servers_nonce');
$servers = get_post_meta($post->ID, '_video_servers', true) ?: [];
$position = get_post_meta($post->ID, '_video_servers_position', true) ?: 'after';

// Inline styles for better organization
echo '<style>
#video-servers-wrapper .video-server-row { margin-bottom: 10px; display: flex; gap: 10px; align-items: center; }
#video-servers-wrapper input[type="text"] { padding: 5px; border: 1px solid #ccc; border-radius: 4px; }
.server-position-options { display: flex; gap: 20px; justify-content: center; margin: 15px 0; padding: 10px; background: #f9f9f9; border-radius: 8px; border: 1px solid #ddd; }
.server-position-options label { font-weight: 500; }
#add-server-btn { margin-top: 10px; }
</style>';

// Position options
echo '<div class="server-position-options">';
echo '<label><input type="radio" name="video_servers_position" value="before" ' . checked($position, 'before', false) . '> قبل المحتوى</label>';
echo '<label><input type="radio" name="video_servers_position" value="after" ' . checked($position, 'after', false) . '> بعد المحتوى</label>';
echo '</div>';

// Servers list
echo '<div id="video-servers-wrapper">';
foreach ($servers as $index => $server) {
$name = esc_attr($server['name'] ?? '');
$url = esc_url($server['url'] ?? '');
echo '<div class="video-server-row">';
echo '<input type="text" name="video_servers[' . $index . '][name]" value="' . $name . '" placeholder="اسم السيرفر" style="width: 30%;" />';
echo '<input type="text" name="video_servers[' . $index . '][url]" value="' . $url . '" placeholder="رابط السيرفر" style="width: 60%;" />';
echo '<button type="button" class="button remove-server">حذف</button>';
echo '</div>';
}
echo '</div>';
echo '<button id="add-server-btn" type="button" class="button">إضافة سيرفر</button>';

// Inline JS for dynamic fields
?>
<script>
function addVideoServerField() {
const wrapper = document.getElementById('video-servers-wrapper');
const index = wrapper.querySelectorAll('.video-server-row').length;
const row = document.createElement('div');
row.className = 'video-server-row';
row.innerHTML = `
<input type="text" name="video_servers[${index}][name]" placeholder="اسم السيرفر" style="width:30%;" />
<input type="text" name="video_servers[${index}][url]" placeholder="رابط السيرفر" style="width:60%;" />
<button type="button" class="button remove-server">حذف</button>
`;
wrapper.appendChild(row);
}
document.addEventListener('DOMContentLoaded', function() {
document.getElementById('video-servers-wrapper').addEventListener('click', function(e) {
if (e.target.classList.contains('remove-server')) {
if (confirm('هل أنت متأكد من حذف هذا السيرفر؟')) {
e.target.closest('.video-server-row').remove();
}
}
});
document.getElementById('add-server-btn').addEventListener('click', addVideoServerField);
});
</script>
<?php
}

// Prevent saving if external link and channel post are both set
function prevent_match_post_save($data, $postarr) {
if ($data['post_type'] !== 'matches') {
return $data;
}

if (!isset($_POST['video_servers_nonce']) || !wp_verify_nonce($_POST['video_servers_nonce'], 'save_video_servers')) {
return $data;
}

if (!current_user_can('edit_post', $postarr['ID'])) {
return $data;
}

$external_link = isset($_POST['acf']['field_external_link']) ? sanitize_text_field($_POST['acf']['field_external_link']) : '';
$channel_post = isset($_POST['acf']['field_channel_post']) ? absint($_POST['acf']['field_channel_post']) : 0;

if (!empty($external_link) && !empty($channel_post)) {
set_transient('custom_admin_error_notice_' . $postarr['ID'], 'لا يمكن إدخال رابط خارجي واختيار قناة معًا. يرجى اختيار أحدهما فقط.', 30);
wp_safe_redirect(add_query_arg('post', $postarr['ID'], admin_url('post.php?action=edit')));
exit;
}

return $data;
}
add_filter('wp_insert_post_data', 'prevent_match_post_save', 10, 2);

// Save video servers meta
function save_video_servers_meta_box($post_id) {
if (!isset($_POST['video_servers_nonce']) || !wp_verify_nonce($_POST['video_servers_nonce'], 'save_video_servers')) {
return;
}

if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
return;
}

if (!current_user_can('edit_post', $post_id)) {
return;
}

// Save position
if (isset($_POST['video_servers_position'])) {
update_post_meta($post_id, '_video_servers_position', sanitize_text_field($_POST['video_servers_position']));
}

// Save servers
if (isset($_POST['video_servers']) && is_array($_POST['video_servers'])) {
$servers = [];
foreach ($_POST['video_servers'] as $server) {
$name = !empty(trim($server['name'])) ? sanitize_text_field($server['name']) : 'سيرفر';
$url = esc_url_raw($server['url'] ?? '');
if (!empty($url)) {
$servers[] = ['name' => $name, 'url' => $url];
}
}
update_post_meta($post_id, '_video_servers', $servers);
} else {
delete_post_meta($post_id, '_video_servers');
}
}
add_action('save_post', 'save_video_servers_meta_box');

// Display admin error notice
function display_custom_admin_error_notice() {
global $post;
if (isset($post->ID) && $error_message = get_transient('custom_admin_error_notice_' . $post->ID)) {
?>
<div class="notice notice-error is-dismissible">
<p><strong>خطأ:</strong> <?php echo esc_html($error_message); ?></p>
</div>
<?php
delete_transient('custom_admin_error_notice_' . $post->ID);
}
}
add_action('admin_notices', 'display_custom_admin_error_notice');

/* -----------------------------------
* Custom Taxonomies
* ----------------------------------- */
// Clubs
function register_clubs_taxonomy() {
$labels = [
'name' => 'أندية',
'singular_name' => 'نادي',
'search_items' => 'البحث في الأندية',
'all_items' => 'كل الأندية',
'edit_item' => 'تعديل النادي',
'update_item' => 'تحديث النادي',
'add_new_item' => 'إضافة نادي جديد',
'new_item_name' => 'اسم النادي الجديد',
'menu_name' => 'أندية',
];

$args = [
'hierarchical' => false,
'labels' => $labels,
'show_ui' => true,
'show_admin_column' => true,
'query_var' => true,
'rewrite' => ['slug' => 'clubs'],
];

register_taxonomy('clubs', ['matches'], $args);
}
add_action('init', 'register_clubs_taxonomy', 0);

// Tournaments
function register_tournaments_taxonomy() {
$labels = [
'name' => 'بطولات',
'singular_name' => 'بطولة',
'search_items' => 'البحث في البطولات',
'all_items' => 'كل البطولات',
'edit_item' => 'تعديل البطولة',
'update_item' => 'تحديث البطولة',
'add_new_item' => 'إضافة بطولة جديدة',
'new_item_name' => 'اسم البطولة الجديدة',
'menu_name' => 'بطولات',
];

$args = [
'hierarchical' => false,
'labels' => $labels,
'show_ui' => true,
'show_admin_column' => true,
'query_var' => true,
'rewrite' => ['slug' => 'tournaments'],
];

register_taxonomy('tournaments', ['matches'], $args);
}
add_action('init', 'register_tournaments_taxonomy', 0);

/* -----------------------------------
* ACF Local Fields
* ----------------------------------- */
if (function_exists('acf_add_local_field_group')) {
// Matches Fields
acf_add_local_field_group([
'key' => 'group_match_details',
'title' => 'تفاصيل المباراة',
'fields' => [
// Row 1: Teams
[
'key' => 'field_team_one',
'label' => 'الفريق الأول',
'name' => 'team_one',
'type' => 'taxonomy',
'taxonomy' => 'clubs',
'field_type' => 'select',
'wrapper' => ['width' => '50'],
'required' => 1,
'return_format' => 'id',
],
[
'key' => 'field_team_two',
'label' => 'الفريق الثاني',
'name' => 'team_two',
'type' => 'taxonomy',
'taxonomy' => 'clubs',
'field_type' => 'select',
'wrapper' => ['width' => '50'],
'required' => 1,
'return_format' => 'id',
],
// Row 2: Scores
[
'key' => 'field_team_one_score',
'label' => 'نتيجة الفريق الأول',
'name' => 'team_one_score',
'type' => 'number',
'min' => 0,
'step' => 1,
'wrapper' => ['width' => '50'],
],
[
'key' => 'field_team_two_score',
'label' => 'نتيجة الفريق الثاني',
'name' => 'team_two_score',
'type' => 'number',
'min' => 0,
'step' => 1,
'wrapper' => ['width' => '50'],
],
// Row 3: Date, Time, Status
[
'key' => 'field_match_date',
'label' => 'تاريخ المباراة',
'name' => 'match_date',
'type' => 'date_picker',
'display_format' => 'd/m/Y',
'return_format' => 'Ymd',
'required' => 1,
'wrapper' => ['width' => '33.333'],
],
[
'key' => 'field_match_time',
'label' => 'وقت المباراة',
'name' => 'match_time',
'type' => 'time_picker',
'display_format' => 'g:i a',
'return_format' => 'H:i:s',
'required' => 1,
'wrapper' => ['width' => '33.333'],
],
[
'key' => 'field_event_status',
'label' => 'حالة المباراة',
'name' => 'event_status',
'type' => 'select',
'choices' => [
'Automatic' => 'تلقائي',
'Live' => 'جارية الآن',
'CommingSoon' => 'بعد قليل',
'NotStarted' => 'لم تبدأ بعد',
'Ended' => 'انتهت',
'Postponed' => 'تأجلت',
'Canceled' => 'ألغيت',
'EndedPenalty' => 'أنتهت بركلات ترجيح',
],
'default_value' => 'Automatic',
'wrapper' => ['width' => '33.333'],
'required' => 1,
],
// Row 4: Penalty Scores (Conditional)
[
'key' => 'field_team_one_penalty_score',
'label' => 'ركلات ترجيح الفريق الأول',
'name' => 'team_one_penalty_score',
'type' => 'number',
'min' => 0,
'step' => 1,
'wrapper' => ['width' => '50'],
'conditional_logic' => [[
['field' => 'field_event_status', 'operator' => '==', 'value' => 'EndedPenalty'],
]],
],
[
'key' => 'field_team_two_penalty_score',
'label' => 'ركلات ترجيح الفريق الثاني',
'name' => 'team_two_penalty_score',
'type' => 'number',
'min' => 0,
'step' => 1,
'wrapper' => ['width' => '50'],
'conditional_logic' => [[
['field' => 'field_event_status', 'operator' => '==', 'value' => 'EndedPenalty'],
]],
],
// Row 5: Additional Info
[
'key' => 'field_commentator',
'label' => 'المعلق',
'name' => 'commentator',
'type' => 'text',
'placeholder' => 'أدخل اسم المعلق',
'wrapper' => ['width' => '33.3333'],
],
[
'key' => 'field_channel',
'label' => 'القناة',
'name' => 'channel',
'type' => 'text',
'placeholder' => 'أدخل اسم القناة',
'wrapper' => ['width' => '33.3333'],
],
[
'key' => 'field_match_stadium',
'label' => 'ملعب المباراة',
'name' => 'match_stadium',
'type' => 'text',
'placeholder' => 'أدخل اسم الملعب',
'wrapper' => ['width' => '33.3333'],
],
// Row 6: External Link
[
'key' => 'field_external_link',
'label' => 'رابط خارجي',
'name' => 'external_link',
'type' => 'url',
'placeholder' => 'https://example.com',
'wrapper' => ['width' => '100'],
],
// Row 7: Internal Channel Post
[
'key' => 'field_channel_post',
'label' => 'الربط بقناة داخلية',
'name' => 'channel_post',
'type' => 'post_object',
'post_type' => ['channels'],
'allow_null' => 1,
'multiple' => 0,
'return_format' => 'id',
'ui' => 1,
'wrapper' => ['width' => '100'],
],
],
'location' => [[
['param' => 'post_type', 'operator' => '==', 'value' => 'matches'],
]],
]);

// Clubs Fields
acf_add_local_field_group([
'key' => 'group_club_details',
'title' => 'تفاصيل النادي',
'fields' => [
[
'key' => 'field_club_image',
'label' => 'صورة النادي',
'name' => 'club_image',
'type' => 'image',
'return_format' => 'id',
'preview_size' => 'thumbnail',
'library' => 'all',
'wrapper' => ['width' => '100'],
],
],
'location' => [[
['param' => 'taxonomy', 'operator' => '==', 'value' => 'clubs'],
]],
]);
}

/* -----------------------------------
* Match Details Retrieval
* ----------------------------------- */
function get_match_details($post_id = null) {
if (!$post_id) {
$post_id = get_the_ID();
}
if (!$post_id || !function_exists('get_field')) {
return null;
}

$default_image = THEME_URI . '/assets/uploads/none-club.png';
$match_details = [
'team_one_name' => '',
'team_one_image' => $default_image,
'team_one_score' => 0,
'team_one_penalty_score' => 0,
'match_date' => '',
'match_time' => '',
'timezone' => 'Africa/Cairo',
'team_two_name' => '',
'team_two_image' => $default_image,
'team_two_score' => 0,
'team_two_penalty_score' => 0,
'tournament_name' => '',
'commentator_name' => '',
'channel_name' => '',
'event_status' => 'automatic',
'external_link' => '',
'match_stadium' => '',
'post_date' => '',
'channel_post_permalink' => '',
];

// Team One
$team_one_id = get_field('team_one', $post_id);
if ($team_one_id && !is_wp_error($team_one_id)) {
$team_one = get_term($team_one_id, 'clubs');
if ($team_one && !is_wp_error($team_one)) {
$match_details['team_one_name'] = $team_one->name;
$image_id = get_field('club_image', 'clubs_' . $team_one_id);
$match_details['team_one_image'] = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : $default_image;
}
}

// Team Two
$team_two_id = get_field('team_two', $post_id);
if ($team_two_id && !is_wp_error($team_two_id)) {
$team_two = get_term($team_two_id, 'clubs');
if ($team_two && !is_wp_error($team_two)) {
$match_details['team_two_name'] = $team_two->name;
$image_id = get_field('club_image', 'clubs_' . $team_two_id);
$match_details['team_two_image'] = $image_id ? wp_get_attachment_image_url($image_id, 'thumbnail') : $default_image;
}
}

// Other fields with defaults
$match_details['team_one_score'] = (int) (get_field('team_one_score', $post_id) ?? 0);
$match_details['team_one_penalty_score'] = (int) (get_field('team_one_penalty_score', $post_id) ?? 0);
$match_details['match_date'] = get_field('match_date', $post_id) ?? '';
$match_details['match_time'] = get_field('match_time', $post_id) ?? '';
$match_details['timezone'] = get_field('timezone', $post_id) ?? 'Africa/Cairo';
$match_details['team_two_score'] = (int) (get_field('team_two_score', $post_id) ?? 0);
$match_details['team_two_penalty_score'] = (int) (get_field('team_two_penalty_score', $post_id) ?? 0);
$match_details['commentator_name'] = get_field('commentator', $post_id) ?? '';
$match_details['channel_name'] = get_field('channel', $post_id) ?? '';
$match_details['event_status'] = get_field('event_status', $post_id) ?? 'automatic';
$match_details['external_link'] = get_field('external_link', $post_id) ?? '';
$match_details['match_stadium'] = get_field('match_stadium', $post_id) ?? '';
$match_details['channel_post_permalink'] = get_field('channel_post', $post_id) ? get_permalink(get_field('channel_post', $post_id)) : '';

// Tournament
$tournaments = get_the_terms($post_id, 'tournaments');
if ($tournaments && !is_wp_error($tournaments)) {
$tournament = reset($tournaments);
$match_details['tournament_name'] = $tournament->name;
}

// Post Date
$post = get_post($post_id);
if ($post) {
$match_details['post_date'] = $post->post_date;
}

return $match_details;
}

/* -----------------------------------
* ACF Custom CSS
* ----------------------------------- */
add_action('acf/input/admin_head', 'custom_acf_css');
function custom_acf_css() {
?>
<style>
.acf-fields.-left > .acf-field { margin: 0 !important; padding: 0 !important; }
.acf-fields.-left { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; direction: rtl; }
.acf-field { background: #fff; }
.inside.acf-fields.-top { padding: 12px !important; }
.acf-field { border: 1px solid #e2e8f0; padding: 15px 20px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); transition: all 0.3s ease; }
.acf-field:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.1); transform: translateY(-1px); }
.acf-label label { font-weight: 600; font-size: 15px; color: #333; margin-bottom: 6px; display: block; }
.acf-input input[type="text"], .acf-input input[type="url"], .acf-input input[type="number"], .acf-input select, .acf-input .acf-date-picker input, .acf-input .acf-time-picker input {
width: 100%; padding: 10px 12px; font-size: 14px; border-radius: 6px; border: 1px solid #ccc; transition: 0.3s ease-in-out; background: #fff;
}
.acf-input input:focus, .acf-input select:focus { border-color: #2271b1; box-shadow: 0 0 0 2px rgba(34,113,177,0.2); outline: none; }
.acf-field .acf-input select[multiple] { height: auto; }
.acf-field[data-name="external_link"], .acf-field[data-name="timezone"] { grid-column: span 2; }
#acf-term-fields { padding-left: 5% !important; padding-right: 0 !important; }
.acf-field.acf-field-image.acf-field-club-image.-r0 { padding: 12px; }
body.rtl .acf-fields.-left { direction: rtl; }
.column-match { width: 300px !important; }
</style>
<?php
}

/* -----------------------------------
* Admin Columns for Matches
* ----------------------------------- */
add_filter('manage_matches_posts_columns', 'custom_matches_columns');
function custom_matches_columns($columns) {
return [
'cb' => $columns['cb'],
'title' => 'عنوان المقالة',
'match' => 'مباراة',
'tournament' => 'البطولة',
'match_time' => 'توقيت المباراة',
'match_date' => 'تاريخ النشر',
'post_id' => 'ID',
];
}

add_action('manage_matches_posts_custom_column', 'custom_matches_column_content', 10, 2);
function custom_matches_column_content($column, $post_id) {
$match_details = get_match_details($post_id) ?? [];

switch ($column) {
case 'match':
$team_one_name = esc_html($match_details['team_one_name'] ?? 'غير معروف');
$team_one_image = esc_url($match_details['team_one_image'] ?? THEME_URI . '/assets/uploads/none-club.png');
$team_one_score = esc_html($match_details['team_one_score'] ?? 0);
$team_two_name = esc_html($match_details['team_two_name'] ?? 'غير معروف');
$team_two_image = esc_url($match_details['team_two_image'] ?? THEME_URI . '/assets/uploads/none-club.png');
$team_two_score = esc_html($match_details['team_two_score'] ?? 0);
?>
<div style="display: flex; align-items: center; justify-content: center; border: 1px solid #ddd; padding: 12px; border-radius: 12px; flex-direction: row;">
<span style="display: flex; gap: 5px; align-items: center; justify-content: center; width: 33.3333%; height: 60px; flex-direction: column;">
<span style="height: 40px;">
<img src="<?php echo $team_one_image; ?>" width="30" height="30" style="padding: 5px; width: 30px; height: 30px; border-radius: 100%; background: #fff; box-shadow: 0 0 2px rgb(0 0 0 / 60%); vertical-align: middle;">
</span>
<span style="font-size: 10px; height: 15px; overflow: hidden"><?php echo $team_one_name; ?></span>
</span>
<span style="display: flex; color: green; font-weight: bold; width: 33.3333%; font-size: 20px; flex-direction: column; align-items: center;">
<?php echo "$team_one_score : $team_two_score"; ?>
</span>
<span style="display: flex; gap: 5px; align-items: center; justify-content: center; width: 33.3333%; height: 60px; flex-direction: column;">
<span style="height: 40px;">
<img src="<?php echo $team_two_image; ?>" width="30" height="30" style="padding: 5px; width: 30px; height: 30px; border-radius: 100%; background: #fff; box-shadow: 0 0 2px rgb(0 0 0 / 60%); vertical-align: middle;">
</span>
<span style="font-size: 10px; height: 15px; overflow: hidden"><?php echo $team_two_name; ?></span>
</span>
</div>
<style>
td.title.column-title.has-row-actions.column-primary.page-title, td.match.column-match, td.tournament.column-tournament, td.match_time.column-match_time, td.match_date.column-match_date, td.post_id.column-post_id { vertical-align: middle; }
.margin-bottom-10.brown.font-large { color: #af0000; font-size: 16px; }
.column-match { width: 280px !important; }
</style>
<?php
break;

case 'tournament':
echo esc_html($match_details['tournament_name'] ?? 'غير معروف');
break;

case 'match_time':
$match_date = esc_html($match_details['match_date'] ? date('d-m-Y', strtotime($match_details['match_date'])) : 'غير معروف');
$match_time = esc_html($match_details['match_time'] ? date('H:i', strtotime($match_details['match_time'])) : 'غير معروف');
echo '<div class="margin-bottom-10">' . $match_date . '</div>';
echo '<div class="margin-bottom-10 brown font-large">' . $match_time . '</div>';
break;

case 'match_date':
$post_date = esc_html($match_details['post_date'] ? date_i18n('Y/m/d', strtotime($match_details['post_date'])) : 'غير معروف');
$post_time = esc_html($match_details['post_date'] ? date_i18n('g:i ص', strtotime($match_details['post_date'])) : 'غير معروف');
echo "منشور<br>$post_date الساعة $post_time";
break;

case 'post_id':
echo esc_html($post_id);
break;
}
}

/* -----------------------------------
* Sort Matches by Post Date
* ----------------------------------- */
add_action('pre_get_posts', 'sort_matches_by_post_date');
function sort_matches_by_post_date($query) {
if (!is_admin() || !$query->is_main_query() || $query->get('post_type') !== 'matches') {
return;
}
$query->set('orderby', 'post_date');
$query->set('order', 'DESC');
}

/* -----------------------------------
* Admin Filters for Matches
* ----------------------------------- */
add_action('restrict_manage_posts', 'add_custom_filters_to_matches');
function add_custom_filters_to_matches() {
global $typenow;
if ($typenow !== 'matches') {
return;
}

// Date Filter
$current_date = date('Ymd', current_time('timestamp'));
$yesterday = date('Ymd', strtotime('-1 day', current_time('timestamp')));
$tomorrow = date('Ymd', strtotime('+1 day', current_time('timestamp')));
?>
<select name="event_date">
<option value="">-- تصفية المباريات --</option>
<option value="<?php echo esc_attr($yesterday); ?>" <?php selected(isset($_GET['event_date']) && $_GET['event_date'] === $yesterday); ?>>الأمس</option>
<option value="<?php echo esc_attr($current_date); ?>" <?php selected(isset($_GET['event_date']) && $_GET['event_date'] === $current_date); ?>>اليوم</option>
<option value="<?php echo esc_attr($tomorrow); ?>" <?php selected(isset($_GET['event_date']) && $_GET['event_date'] === $tomorrow); ?>>الغد</option>
</select>
<?php

// Tournament Filter
$tournaments = get_terms(['taxonomy' => 'tournaments', 'hide_empty' => false]);
?>
<select name="current_league" id="aspwp_league_filter" class="postform">
<option value="">-- البطولات --</option>
<?php foreach ($tournaments as $tournament) : ?>
<option value="<?php echo esc_attr($tournament->term_id); ?>" <?php selected(isset($_GET['current_league']) && $_GET['current_league'] == $tournament->term_id); ?>>
<?php echo esc_html($tournament->name) . ' (' . $tournament->count . ')'; ?>
</option>
<?php endforeach; ?>
</select>
<?php
}

add_filter('parse_query', 'filter_matches_query');
function filter_matches_query($query) {
global $pagenow;
$post_type = $query->query['post_type'] ?? '';
if (!is_admin() || $pagenow !== 'edit.php' || $post_type !== 'matches') {
return;
}

$meta_query = [];

// Date Filter
if (!empty($_GET['event_date'])) {
$event_date = sanitize_text_field($_GET['event_date']);
if (preg_match('/^\d{8}$/', $event_date)) {
$meta_query[] = [
'key' => 'match_date',
'value' => $event_date,
'compare' => '=',
'type' => 'CHAR',
];
}
}

// Tournament Filter
if (!empty($_GET['current_league'])) {
$query->query_vars['tax_query'] = [[
'taxonomy' => 'tournaments',
'field' => 'term_id',
'terms' => absint($_GET['current_league']),
'include_children' => false,
]];
}

// Apply Meta Query
if (!empty($meta_query)) {
$query->query_vars['meta_query'] = [
'relation' => 'AND',
...$meta_query,
];
}
}

/* ----------------------------------- * Delete Old Matches Posts * ----------------------------------- */
function delete_old_matches_yalla_specific() {
global $pagenow;
if ($pagenow !== 'edit.php' || !isset($_GET['post_type']) || $_GET['post_type'] !== 'matches') {
if (!isset($_GET['delete_old_matches_manual']) || !current_user_can('manage_options')) {
return;
}
}
if (!function_exists('wp_delete_post')) {
error_log('delete_old_matches_yalla_specific: wp_delete_post غير موجود');
return;
}
$args = [
'post_type'      => 'matches',
'post_status'    => ['publish', 'draft', 'pending', 'future'],
'posts_per_page' => -1,
'no_found_rows'  => true,
'date_query'     => [
[
'before' => date('Y-m-d H:i:s', strtotime('-96 hours')),
'compare' => '<',
'column'  => 'post_date_gmt',
],
],
];
$query = new WP_Query($args);
$count = $query->post_count;
error_log('delete_old_matches_yalla_specific: تم العثور على ' . $count . ' مقالة مطابقة');
if ($query->have_posts()) {
while ($query->have_posts()) {
$query->the_post();
$post_id = get_the_ID();
wp_delete_post($post_id, true);
error_log('delete_old_matches_yalla_specific: تم حذف المقالة ID: ' . $post_id);
}
wp_reset_postdata();
}
if (isset($_GET['delete_old_matches_manual']) && current_user_can('manage_options')) {
wp_die('تم تشغيل الحذف يدويًا: ' . $count . ' مقالة تم العثور عليها وحذفها');
}
}
add_action('admin_init', 'delete_old_matches_yalla_specific');

function setup_theme_features() {
add_theme_support('post-thumbnails');
}
add_action('after_setup_theme', 'setup_theme_features');

/* --------------------- Related Articles After Second Paragraph --------------------- */
function insert_related_after_second_paragraph($content) {
if (!is_single() || is_admin()) {
return $content;
}
$categories = get_the_category();
$child_category = null;
foreach ($categories as $cat) {
if ($cat->slug !== 'news') {
$child_category = $cat;
break;
}
}
if ($child_category) {
$related_posts = new WP_Query([
'category__in' => [$child_category->term_id],
'post__not_in' => [get_the_ID()],
'posts_per_page' => 2,
'orderby' => 'date',
'order' => 'DESC',
'no_found_rows' => true, // Optimize query
]);
if ($related_posts->have_posts()) {
$related_html = '<div class="related-articles-box" style="margin-bottom:15px">';
$related_html .= '<h3 class="related-title">' . esc_html__('اقرأ أيضًا', THEME_TEXTDOMAIN) . '</h3>';
$related_html .= '<div class="related-articles-grid">';
while ($related_posts->have_posts()) {
$related_posts->the_post();
$related_html .= '<div class="related-article-item">';
$related_html .= '<div class="related-article-img">';
$related_html .= '<a href="' . esc_url(get_the_permalink()) . '" title="' . esc_attr(get_the_title()) . '">';
if (has_post_thumbnail()) {
$related_html .= get_the_post_thumbnail(null, 'medium', ['alt' => esc_attr(get_the_title()), 'loading' => 'lazy']);
}
$related_html .= '</a></div>';
$related_html .= '<div class="article-title"><p class="related-article-title">';
$related_html .= '<a href="' . esc_url(get_the_permalink()) . '" title="' . esc_attr(get_the_title()) . '">';
$related_html .= esc_html(get_the_title());
$related_html .= '</a></p></div></div>';
}
wp_reset_postdata();
$related_html .= '</div></div>';
$paragraphs = explode('</p>', $content);
if (count($paragraphs) >= 2) {
$paragraphs[1] .= '</p>' . $related_html;
$content = implode('</p>', array_filter($paragraphs));
} else {
$content .= $related_html;
}
}
}
return $content;
}
add_filter('the_content', 'insert_related_after_second_paragraph', 10);





// === 1. إضافة الـ query vars اللي هنحتاجها (مستقلة الآن) ===
add_filter('query_vars', 'sport_flat_query_vars');
function sport_flat_query_vars($vars) {
$vars[] = 'league_slug'; // premier-league-7
$vars[] = 'team_slug';   // arsenal-104
$vars[] = 'player_slug'; // gabriel-magalhaes-42068
return $vars;
}

// === 2. الـ Rewrite Rules الفلات (مستقلة وبسيطة) ===
add_action('init', 'sport_flat_rewrites');
function sport_flat_rewrites() {
// 1. صفحة الدوري (فلات)
add_rewrite_rule(
'^league/([^/]+)/?$',
'index.php?pagename=league&league_slug=$matches[1]',
'top'
);

// 2. صفحة الفريق (فلات ومستقلة)
add_rewrite_rule(
'^team/([^/]+)/?$',
'index.php?pagename=team&team_slug=$matches[1]',
'top'
);

// 3. صفحة اللاعب (فلات ومستقلة)
add_rewrite_rule(
'^player/([^/]+)/?$',
'index.php?pagename=player&player_slug=$matches[1]',
'top'
);
}

// === 3. فلش الروابط مع تحذير للـ redirects (اختياري - مرة واحدة بس) ===
add_action('admin_menu', function() {
add_submenu_page(
'tools.php',
'Flush Rewrites (Flat)',
'Flush Rewrites (Flat)',
'manage_options',
'flush-flat-rewrites',
function() {
if (isset($_GET['flush'])) {
flush_rewrite_rules();
echo '<div class="updated"><p>Rewrite Rules Flushed! تذكر: أضف 301 redirects من الروابط الهرمية القديمة إلى الفلات في .htaccess أو plugin.</p></div>';
}
echo '<h3>Flush Flat Rewrites</h3>';
echo '<p>هذا سيطبق الروابط الفلات. تأكد من إضافة redirects للروابط القديمة للحفاظ على SEO.</p>';
echo '<a href="'.admin_url('tools.php?page=flush-flat-rewrites&flush=1').'" class="button button-primary">Flush Now</a>';
}
);
});
?>