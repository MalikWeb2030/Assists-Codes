<!-- Single Post Template Structure -->
<?php get_header(); ?>
<div class="container Flex">
<main class="BlogBox" role="main">
<?php get_template_part('template-parts/post-title'); ?>
<div class="PostBody" id="ContentBox">
<?php get_template_part('template-parts/post-content'); ?>
<footer class="PostFooter">
<?php
get_template_part('template-parts/posts-tags');
get_template_part('template-parts/posts-share');
?>
</footer>
</div>
</main>
<?php get_template_part('template-parts/related-posts'); ?>
<!-- إعلانات المقالة -->
<?php
$options = get_option('mw_theme_options', []);
$defaults = [
'post_ads_toggle' => 1,
'ad_under_post_h2_1_enable' => 1,
'ad_under_post_h2_1_code' => 'مساحة إعلانية',
'ad_under_post_h2_2_enable' => 1,
'ad_under_post_h2_2_code' => 'مساحة إعلانية',
'ad_under_post_h2_3_enable' => 1,
'ad_under_post_h2_3_code' => 'مساحة إعلانية',
'ad_under_post_h2_4_enable' => 1,
'ad_under_post_h2_4_code' => 'مساحة إعلانية',
'ad_under_post_h3_1_enable' => 1,
'ad_under_post_h3_1_code' => 'مساحة إعلانية',
'ad_under_post_h3_2_enable' => 1,
'ad_under_post_h3_2_code' => 'مساحة إعلانية',
'ad_under_post_h3_3_enable' => 1,
'ad_under_post_h3_3_code' => 'مساحة إعلانية',
'ad_under_post_h3_4_enable' => 1,
'ad_under_post_h3_4_code' => 'مساحة إعلانية',
'ad_under_post_p1_enable' => 1,
'ad_under_post_p1_code' => 'مساحة إعلانية',
'ad_under_post_p2_enable' => 1,
'ad_under_post_p2_code' => 'مساحة إعلانية',
'ad_under_post_p3_enable' => 1,
'ad_under_post_p3_code' => 'مساحة إعلانية',
'ad_under_post_p4_enable' => 1,
'ad_under_post_p4_code' => 'مساحة إعلانية',
];
$settings = wp_parse_args($options, $defaults);
// تعريف مصفوفة الإعلانات
$ads = [
'postad1' => ['enable' => 'ad_under_post_h2_1_enable', 'code' => 'ad_under_post_h2_1_code'],
'postad2' => ['enable' => 'ad_under_post_h2_2_enable', 'code' => 'ad_under_post_h2_2_code'],
'postad3' => ['enable' => 'ad_under_post_h2_3_enable', 'code' => 'ad_under_post_h2_3_code'],
'postad4' => ['enable' => 'ad_under_post_h2_4_enable', 'code' => 'ad_under_post_h2_4_code'],
'postad5' => ['enable' => 'ad_under_post_h3_1_enable', 'code' => 'ad_under_post_h3_1_code'],
'postad6' => ['enable' => 'ad_under_post_h3_2_enable', 'code' => 'ad_under_post_h3_2_code'],
'postad7' => ['enable' => 'ad_under_post_h3_3_enable', 'code' => 'ad_under_post_h3_3_code'],
'postad8' => ['enable' => 'ad_under_post_h3_4_enable', 'code' => 'ad_under_post_h3_4_code'],
'postad9' => ['enable' => 'ad_under_post_p1_enable', 'code' => 'ad_under_post_p1_code'],
'postad10' => ['enable' => 'ad_under_post_p2_enable', 'code' => 'ad_under_post_p2_code'],
'postad11' => ['enable' => 'ad_under_post_p3_enable', 'code' => 'ad_under_post_p3_code'],
'postad12' => ['enable' => 'ad_under_post_p4_enable', 'code' => 'ad_under_post_p4_code'],
];
if (is_single() && !empty($settings['post_ads_toggle'])) {
foreach ($ads as $id => $ad) {
if (!empty($settings[$ad['enable']]) && !empty($settings[$ad['code']])) {
echo '<div class="Post-ads" id="' . esc_attr($id) . '" aria-label="إعلان">' . $settings[$ad['code']] . '</div>';
}
}
}
?>
</div>
<style>.container.Flex{max-width:1000px}</style>
<?php get_footer(); ?>